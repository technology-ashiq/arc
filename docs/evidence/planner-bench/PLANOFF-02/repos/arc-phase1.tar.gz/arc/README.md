# snip

A URL shortener. Signed-in users create short links; anyone can follow them; hits are counted;
owners see and delete only their own links.

## Start it (one command)

```bash
PORT=3201 APP_ENV=test node server.mjs
```

Then open <http://localhost:3201>. No install step, no dependencies — Node 22 and its built-in
`node:sqlite` are the whole stack. The database is created at `./data/snip.db` on first boot.

For dev/prod, drop `APP_ENV=test` (see **Configuration**):

```bash
PORT=3000 APP_ENV=development BASE_URL=https://snip.example node server.mjs
```

## Test it

```bash
npm test
```

29 tests, no network. The clock and the email provider are injected fakes, so expiry and
rate-limit windows are exercised by jumping time rather than sleeping, and nothing in the test
path can reach a live third-party service.

## API

| Method | Path | Behaviour |
|---|---|---|
| POST | `/api/links` | `{ "url", "alias"?, "expiresAt"? }` -> `201 { "code", "shortUrl" }` |
| GET | `/api/links` | `200 [{ "code", "url", "hits", "expiresAt" }]` — your own links only |
| DELETE | `/api/links/:code` | `204` |
| GET | `/:code` | `302` to the long URL; the hit is counted |
| POST | `/api/auth/request` | `{ "email" }` -> `202`, sends a magic link |
| GET | `/api/auth/callback?token=` | `302` + session cookie |
| POST | `/api/auth/logout` | `204` |
| GET | `/api/me` | `200 { "email" }` |
| GET | `/healthz` | `200 { "ok": true }` |
| POST | `/api/test/reset` | **test mode only** -> `204`; wipes links + rate-limit state. `404` otherwise |

### Status codes, and why each one is the true one

| Code | When |
|---|---|
| `400` | Bad input: not an http(s) URL, malformed alias, reserved alias, `expiresAt` unparseable or in the past |
| `401` | Not signed in |
| `404` | The code was **never issued** — genuinely unknown. Also: someone else's link (we do not confirm it exists) |
| `409` | The alias is **already taken** — including by a *deleted* link. Codes are never reissued |
| `410` | The code **was** issued and is now **gone**: deleted by its owner, or expired. Not 404 — it is not unknown, it is over |
| `413`/`415` | Body too large / not JSON |
| `429` | More than 10 creates in a minute from this IP. Carries `Retry-After` **and** `retryAfterSeconds` |

## Auth

Real path: **email magic link** — `POST /api/auth/request` mails a single-use, 15-minute token;
`GET /api/auth/callback?token=...` exchanges it for an `HttpOnly` session cookie.

Test path: when `APP_ENV=test`, `X-Test-User: someone@example.com` authenticates as that user and
no email is sent. **This is read in exactly one place** (`resolveUser` in `src/auth.mjs`) behind
`config.isTest`, which is derived once at boot. When `APP_ENV` is anything else the header is not
read at all, and `/api/test/reset` returns `404`. Both facts are asserted in
`test/security.test.mjs` against a production-configured app.

## Configuration

| Variable | Default | Notes |
|---|---|---|
| `PORT` | `3000` | |
| `APP_ENV` | `development` | `test` enables the auth shim + reset endpoint and forces the fake mailer |
| `DB_PATH` | `./data/snip.db` | SQLite file; created with its parent directory |
| `BASE_URL` | `http://localhost:$PORT` | Used to build `shortUrl` and the magic link |
| `MAIL_DRIVER` | `console` | `console` or `http` (real provider). Always `fake` when `APP_ENV=test` |
| `MAIL_API_KEY` | — | Required when `MAIL_DRIVER=http`; the app refuses to boot without it |
| `MAIL_FROM` | `no-reply@snip.local` | |
| `MAIL_API_URL` | Resend's endpoint | Any JSON `{from,to,subject,text}` mail API |
| `TRUST_PROXY` | off | Set to `1` **only** behind a proxy you control; otherwise `X-Forwarded-For` is ignored, because a spoofable IP makes the per-IP rate limit decorative |

## Design decisions worth knowing

- **Delete is a tombstone, not a `DELETE FROM`.** The row and its `code` stay in the table with
  `deleted_at` set. That is what lets `GET /:code` answer **410 Gone** rather than 404, and it means
  a code can never be reissued — so a deleted alias on a printed QR code can never be quietly
  re-pointed at somebody else's URL.
- **Uniqueness is the database's job.** `links.code` is the PRIMARY KEY; inserts are attempted and
  constraint violations translated (alias -> 409, generated code -> retry). A `SELECT`-then-`INSERT`
  check would be a race.
- **Nothing calls `Date.now()` in a handler.** Time arrives as an injected `clock`, which is why
  expiry and the sliding rate-limit window are tested by advancing a fake clock, not by sleeping.
- **The mailer is an interface with three implementations** (`fake` / `console` / `http`) chosen by
  config at boot, never monkey-patched in a test.
- **Hits increment only on the path that actually emits the 302**, in the same transaction as the
  lookup — a 404 or a 410 never moves the counter.
- Full reasoning, including the pre-mortem this design came out of: **[PLAN.md](PLAN.md)**.
  Current state: **[PROGRESS.md](PROGRESS.md)**.
