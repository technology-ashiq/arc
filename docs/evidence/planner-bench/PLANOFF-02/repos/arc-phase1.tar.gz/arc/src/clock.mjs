// Time is an external dependency like any other: interface + fake + real, selected by the caller.
// Handlers never call Date.now() directly, so expiry and rate-limit windows are testable
// without sleeping (PLAN.md pre-mortem #3).

export const systemClock = Object.freeze({
  now: () => Date.now()
});

export function createFakeClock(startMs = Date.parse('2026-01-01T00:00:00.000Z')) {
  let current = startMs;
  return {
    now: () => current,
    advance(ms) { current += ms; return current; },
    set(ms) { current = ms; return current; }
  };
}
