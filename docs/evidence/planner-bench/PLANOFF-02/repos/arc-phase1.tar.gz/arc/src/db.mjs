import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

// Times are INTEGER epoch-ms everywhere. Never ISO strings in the DB: string comparison of
// timestamps is a classic silent-wrong (PLAN.md pre-mortem #3).
//
// links.code is the PRIMARY KEY and tombstoned rows keep it. That is deliberate:
//   - uniqueness of codes/aliases is enforced by the DB, not by a check-then-insert race (#4)
//   - a deleted code can never be reissued, so GET /:code can honestly answer 410 Gone (#2)
const MIGRATIONS = [
  `CREATE TABLE IF NOT EXISTS users (
     id         INTEGER PRIMARY KEY AUTOINCREMENT,
     email      TEXT NOT NULL UNIQUE,
     created_at INTEGER NOT NULL
   );
   CREATE TABLE IF NOT EXISTS links (
     code       TEXT PRIMARY KEY,
     url        TEXT NOT NULL,
     user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     hits       INTEGER NOT NULL DEFAULT 0,
     expires_at INTEGER,
     created_at INTEGER NOT NULL,
     deleted_at INTEGER
   );
   CREATE INDEX IF NOT EXISTS idx_links_user ON links(user_id);
   CREATE TABLE IF NOT EXISTS magic_tokens (
     token      TEXT PRIMARY KEY,
     email      TEXT NOT NULL,
     expires_at INTEGER NOT NULL,
     used_at    INTEGER,
     created_at INTEGER NOT NULL
   );
   CREATE TABLE IF NOT EXISTS sessions (
     id         TEXT PRIMARY KEY,
     user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
     expires_at INTEGER NOT NULL,
     created_at INTEGER NOT NULL
   );`
];

export function openDatabase(dbPath) {
  if (dbPath !== ':memory:') mkdirSync(dirname(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');

  const [{ user_version: version }] = db.prepare('PRAGMA user_version').all();
  for (let i = version; i < MIGRATIONS.length; i++) {
    db.exec('BEGIN');
    try {
      db.exec(MIGRATIONS[i]);
      db.exec(`PRAGMA user_version = ${i + 1}`);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }
  return db;
}
