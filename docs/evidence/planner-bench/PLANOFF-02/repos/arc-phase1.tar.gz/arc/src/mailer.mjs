// Mailer: one interface, three implementations, chosen by config.
//   send({ to, subject, text }) -> Promise<void>   (throws on failure)
//
// fake    - in-memory outbox. Used by every test. No network, ever.
// console - dev: prints the magic link so you can click it locally.
// http    - real provider (Resend-shaped JSON API) via fetch.

export function createMailer(mailConfig) {
  switch (mailConfig.driver) {
    case 'fake': return createFakeMailer();
    case 'console': return createConsoleMailer(mailConfig);
    case 'http': return createHttpMailer(mailConfig);
    default: throw new Error(`Unknown MAIL_DRIVER: ${mailConfig.driver}`);
  }
}

export function createFakeMailer() {
  const sent = [];
  return {
    driver: 'fake',
    sent,
    async send(message) { sent.push({ ...message, at: new Date().toISOString() }); },
    clear() { sent.length = 0; }
  };
}

function createConsoleMailer(cfg) {
  return {
    driver: 'console',
    async send({ to, subject, text }) {
      console.log(`[mail:console] from=${cfg.from} to=${to} subject=${subject}\n${text}`);
    }
  };
}

function createHttpMailer(cfg) {
  return {
    driver: 'http',
    async send({ to, subject, text }) {
      const res = await fetch(cfg.endpoint, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${cfg.apiKey}`
        },
        body: JSON.stringify({ from: cfg.from, to: [to], subject, text }),
        signal: AbortSignal.timeout(10_000)
      });
      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error(`mail provider rejected the message: ${res.status} ${body.slice(0, 200)}`);
      }
    }
  };
}
