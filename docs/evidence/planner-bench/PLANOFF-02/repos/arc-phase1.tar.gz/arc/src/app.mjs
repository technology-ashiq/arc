import http from 'node:http';
import { randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import {
  findOrCreateUser, createMagicToken, consumeMagicToken, createSession, deleteSession,
  insertLink, listLinksForUser, softDeleteLink, takeRedirect, resetAll, isUniqueViolation
} from './repo.mjs';
import {
  resolveUser, isValidEmail, normalizeEmail, newToken, parseCookies,
  sessionCookie, clearedSessionCookie, SESSION_COOKIE
} from './auth.mjs';
import { createRateLimiter } from './ratelimit.mjs';

const MAX_BODY_BYTES = 64 * 1024;
const MAX_URL_LENGTH = 2048;
const ALIAS_RE = /^[A-Za-z0-9_-]{3,32}$/;
const CODE_ALPHABET = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/l/I
// A code lives in the same namespace as the app's own routes, so these can never be handed out.
const RESERVED_CODES = new Set(['api', 'dashboard', 'healthz', 'favicon.ico', 'robots.txt', 'static', 'public']);

const INDEX_HTML = readFileSync(fileURLToPath(new URL('./public/index.html', import.meta.url)), 'utf8');

/* ------------------------------ small http helpers ------------------------------ */

function sendJson(res, status, payload, headers = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    ...headers
  });
  res.end(body);
}

function sendError(res, status, code, message, headers = {}) {
  sendJson(res, status, { error: code, message }, headers);
}

function sendNoContent(res, headers = {}) {
  res.writeHead(204, headers);
  res.end();
}

class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

async function readJsonBody(req) {
  const type = String(req.headers['content-type'] ?? '');
  if (!type.includes('application/json')) {
    throw new HttpError(415, 'unsupported_media_type', 'Content-Type must be application/json.');
  }
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new HttpError(413, 'payload_too_large', 'Request body is too large.');
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString('utf8').trim();
  if (raw === '') throw new HttpError(400, 'invalid_body', 'A JSON body is required.');
  try {
    const parsed = JSON.parse(raw);
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error('not an object');
    }
    return parsed;
  } catch {
    throw new HttpError(400, 'invalid_body', 'Request body must be a JSON object.');
  }
}

function clientIp(req, config) {
  if (config.trustProxy) {
    // Only trusted behind a proxy we control -- otherwise anyone spoofs this header and the
    // per-IP rate limit is decorative (PLAN.md pre-mortem #5).
    const fwd = req.headers['x-forwarded-for'];
    if (typeof fwd === 'string' && fwd.length > 0) return fwd.split(',')[0].trim();
  }
  return req.socket.remoteAddress ?? 'unknown';
}

/* ------------------------------ validation ------------------------------ */

function validateUrl(raw) {
  if (typeof raw !== 'string' || raw.trim() === '') {
    throw new HttpError(400, 'invalid_url', '"url" is required.');
  }
  const value = raw.trim();
  if (value.length > MAX_URL_LENGTH) {
    throw new HttpError(400, 'invalid_url', `"url" must be at most ${MAX_URL_LENGTH} characters.`);
  }
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    throw new HttpError(400, 'invalid_url', '"url" must be an absolute URL.');
  }
  // Anything but http/https turns the shortener into an XSS / phishing delivery service.
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new HttpError(400, 'invalid_url', '"url" must use http or https.');
  }
  return parsed.toString();
}

function validateAlias(raw) {
  if (raw === undefined || raw === null || raw === '') return null;
  if (typeof raw !== 'string' || !ALIAS_RE.test(raw)) {
    throw new HttpError(400, 'invalid_alias', '"alias" must be 3-32 characters of A-Z, a-z, 0-9, - or _.');
  }
  if (RESERVED_CODES.has(raw.toLowerCase())) {
    // Malformed request, not a conflict: this alias is not something anyone could ever hold.
    throw new HttpError(400, 'reserved_alias', `"${raw}" is a reserved word and cannot be used as an alias.`);
  }
  return raw;
}

function validateExpiresAt(raw, nowMs) {
  if (raw === undefined || raw === null || raw === '') return null;
  if (typeof raw !== 'string') {
    throw new HttpError(400, 'invalid_expires_at', '"expiresAt" must be an ISO-8601 string.');
  }
  const ms = Date.parse(raw);
  if (Number.isNaN(ms)) {
    throw new HttpError(400, 'invalid_expires_at', '"expiresAt" must be a valid ISO-8601 timestamp.');
  }
  if (ms <= nowMs) {
    throw new HttpError(400, 'invalid_expires_at', '"expiresAt" must be in the future.');
  }
  return ms;
}

function generateCode(length) {
  const bytes = randomBytes(length);
  let out = '';
  for (let i = 0; i < length; i++) out += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  return out;
}

function toIso(ms) {
  return ms === null || ms === undefined ? null : new Date(ms).toISOString();
}

/* ------------------------------ the app ------------------------------ */

export function createApp({ config, db, clock, mailer }) {
  const rateLimiter = createRateLimiter({ ...config.rateLimit, clock });

  function requireUser(req) {
    const user = resolveUser(req, { db, config, clock });
    if (!user) throw new HttpError(401, 'unauthorized', 'Sign in to use this endpoint.');
    return user;
  }

  /* ---- POST /api/links ---- */
  async function createLink(req, res) {
    const user = requireUser(req); // a 401 is not a "create", so it does not spend rate budget
    const ip = clientIp(req, config);
    const verdict = rateLimiter.check(ip);
    if (!verdict.allowed) {
      // Tell the caller exactly how long to wait -- in the header AND in the body.
      return sendJson(res, 429, {
        error: 'rate_limited',
        message: `Too many links created. Retry in ${verdict.retryAfterSeconds}s.`,
        retryAfterSeconds: verdict.retryAfterSeconds
      }, { 'retry-after': String(verdict.retryAfterSeconds) });
    }

    const body = await readJsonBody(req);
    const nowMs = clock.now();
    const url = validateUrl(body.url);
    const alias = validateAlias(body.alias);
    const expiresAt = validateExpiresAt(body.expiresAt, nowMs);

    if (alias) {
      try {
        insertLink(db, { code: alias, url, userId: user.id, expiresAt, nowMs });
      } catch (err) {
        // The DB is the arbiter of uniqueness -- no check-then-insert race, and tombstoned
        // codes still occupy the namespace, so a deleted alias cannot be re-registered.
        if (isUniqueViolation(err)) {
          throw new HttpError(409, 'alias_taken', `The alias "${alias}" is already in use.`);
        }
        throw err;
      }
      return sendJson(res, 201, { code: alias, shortUrl: `${config.baseUrl}/${alias}` });
    }

    for (let attempt = 0; attempt < 5; attempt++) {
      const code = generateCode(config.codeLength);
      try {
        insertLink(db, { code, url, userId: user.id, expiresAt, nowMs });
        return sendJson(res, 201, { code, shortUrl: `${config.baseUrl}/${code}` });
      } catch (err) {
        if (isUniqueViolation(err)) continue; // astronomically unlikely; retry anyway
        throw err;
      }
    }
    throw new HttpError(500, 'code_generation_failed', 'Could not allocate a unique short code.');
  }

  /* ---- GET /api/links ---- */
  function listLinks(req, res) {
    const user = requireUser(req);
    const rows = listLinksForUser(db, user.id).map((row) => ({
      code: row.code,
      url: row.url,
      hits: row.hits,
      expiresAt: toIso(row.expires_at)
    }));
    sendJson(res, 200, rows);
  }

  /* ---- DELETE /api/links/:code ---- */
  function removeLink(req, res, code) {
    const user = requireUser(req);
    const outcome = softDeleteLink(db, code, user.id, clock.now());
    if (outcome === 'not-found') {
      // Also covers "belongs to someone else": we never confirm another user's code exists.
      throw new HttpError(404, 'not_found', 'No such link.');
    }
    sendNoContent(res); // 'already-deleted' -> 204 as well: deleting twice is idempotent
  }

  /* ---- GET /:code ---- */
  function redirect(req, res, code) {
    const outcome = takeRedirect(db, code, clock.now());
    switch (outcome.status) {
      case 'ok':
        res.writeHead(302, { location: outcome.url, 'cache-control': 'no-store' });
        return res.end();
      case 'deleted':
        // Gone, not unknown. The code existed; the owner destroyed it; it is never coming back.
        return sendError(res, 410, 'gone', 'This link has been deleted.');
      case 'expired':
        return sendError(res, 410, 'gone', 'This link has expired.');
      default:
        return sendError(res, 404, 'not_found', 'No such link.');
    }
  }

  /* ---- auth: the real magic-link path (dev/prod), exercised in test via the fake mailer ---- */
  async function requestMagicLink(req, res) {
    const body = await readJsonBody(req);
    const email = normalizeEmail(body.email ?? '');
    if (!isValidEmail(email)) throw new HttpError(400, 'invalid_email', 'A valid "email" is required.');

    const nowMs = clock.now();
    const token = newToken();
    createMagicToken(db, { token, email, expiresAt: nowMs + config.magicLinkTtlMs, nowMs });
    const link = `${config.baseUrl}/api/auth/callback?token=${encodeURIComponent(token)}`;

    try {
      await mailer.send({
        to: email,
        subject: 'Your snip sign-in link',
        text: `Click to sign in to snip (valid for 15 minutes):\n\n${link}\n`
      });
    } catch (err) {
      throw new HttpError(502, 'mail_failed', `Could not send the sign-in email: ${err.message}`);
    }
    sendJson(res, 202, { ok: true, message: 'Check your email for a sign-in link.' });
  }

  function magicLinkCallback(req, res, url) {
    const token = url.searchParams.get('token') ?? '';
    const nowMs = clock.now();
    const email = consumeMagicToken(db, token, nowMs);
    if (!email) throw new HttpError(400, 'invalid_token', 'This sign-in link is invalid, used, or expired.');

    const user = findOrCreateUser(db, email, nowMs);
    const sid = newToken();
    createSession(db, { id: sid, userId: user.id, expiresAt: nowMs + config.sessionTtlMs, nowMs });
    res.writeHead(302, {
      location: '/',
      'set-cookie': sessionCookie(sid, {
        maxAgeSeconds: Math.floor(config.sessionTtlMs / 1000),
        secure: config.baseUrl.startsWith('https://')
      })
    });
    res.end();
  }

  function logout(req, res) {
    const sid = parseCookies(req.headers.cookie)[SESSION_COOKIE];
    if (sid) deleteSession(db, sid);
    sendNoContent(res, { 'set-cookie': clearedSessionCookie() });
  }

  function whoami(req, res) {
    const user = resolveUser(req, { db, config, clock });
    if (!user) throw new HttpError(401, 'unauthorized', 'Not signed in.');
    sendJson(res, 200, { email: user.email });
  }

  /* ---- router ---- */
  async function route(req, res) {
    const url = new URL(req.url, `http://${req.headers.host ?? 'localhost'}`);
    const path = url.pathname;
    const method = req.method ?? 'GET';

    if (path === '/healthz') return sendJson(res, 200, { ok: true, appEnv: config.appEnv });
    if (path === '/' || path === '/dashboard') {
      if (method !== 'GET') throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      return res.end(INDEX_HTML);
    }

    if (path === '/api/auth/request') {
      if (method !== 'POST') throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
      return requestMagicLink(req, res);
    }
    if (path === '/api/auth/callback') {
      if (method !== 'GET') throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
      return magicLinkCallback(req, res, url);
    }
    if (path === '/api/auth/logout') {
      if (method !== 'POST') throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
      return logout(req, res);
    }
    if (path === '/api/me') {
      if (method !== 'GET') throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
      return whoami(req, res);
    }

    if (path === '/api/links') {
      if (method === 'POST') return createLink(req, res);
      if (method === 'GET') return listLinks(req, res);
      throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
    }

    const linkMatch = /^\/api\/links\/([^/]+)$/.exec(path);
    if (linkMatch) {
      if (method !== 'DELETE') throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
      return removeLink(req, res, decodeURIComponent(linkMatch[1]));
    }

    if (path === '/api/test/reset') {
      // In any non-test environment this endpoint does not exist. Not 403 -- it is genuinely absent.
      if (!config.isTest) throw new HttpError(404, 'not_found', 'Not found.');
      if (method !== 'POST') throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
      resetAll(db);
      rateLimiter.reset();
      mailer.clear?.();
      return sendNoContent(res);
    }

    if (path.startsWith('/api/')) throw new HttpError(404, 'not_found', 'No such endpoint.');

    const codeMatch = /^\/([^/]+)$/.exec(path);
    if (codeMatch) {
      if (method !== 'GET') throw new HttpError(405, 'method_not_allowed', `${method} is not allowed here.`);
      return redirect(req, res, decodeURIComponent(codeMatch[1]));
    }

    throw new HttpError(404, 'not_found', 'Not found.');
  }

  const server = http.createServer((req, res) => {
    Promise.resolve()
      .then(() => route(req, res))
      .catch((err) => {
        if (res.headersSent) return res.destroy();
        if (err instanceof HttpError) {
          return sendError(res, err.status, err.code, err.message);
        }
        console.error('[snip] unhandled error', err);
        sendError(res, 500, 'internal_error', 'Something went wrong on our end.');
      });
  });

  server.on('clientError', (err, socket) => {
    if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
  });

  return server;
}
