import { randomBytes, timingSafeEqual } from 'node:crypto';
import { findOrCreateUser, findSessionUser } from './repo.mjs';

export const SESSION_COOKIE = 'snip_session';
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function isValidEmail(value) {
  return typeof value === 'string' && value.length <= 254 && EMAIL_RE.test(value);
}

export function normalizeEmail(value) {
  return String(value).trim().toLowerCase();
}

export function newToken(bytes = 32) {
  return randomBytes(bytes).toString('base64url');
}

export function parseCookies(header) {
  const out = Object.create(null);
  if (!header) return out;
  for (const part of header.split(';')) {
    const eq = part.indexOf('=');
    if (eq < 1) continue;
    const key = part.slice(0, eq).trim();
    if (!key) continue;
    out[key] = decodeURIComponent(part.slice(eq + 1).trim());
  }
  return out;
}

export function sessionCookie(id, { maxAgeSeconds, secure }) {
  const parts = [
    `${SESSION_COOKIE}=${id}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${maxAgeSeconds}`
  ];
  if (secure) parts.push('Secure');
  return parts.join('; ');
}

export function clearedSessionCookie() {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}

/**
 * THE ONLY PLACE the request is turned into a user.
 *
 * The X-Test-User shim is gated on config.isTest, which was derived once at boot from
 * APP_ENV === 'test'. Outside test mode the header is not read at all -- it cannot be, the
 * branch is not entered -- so it cannot become an authentication bypass in production.
 */
export function resolveUser(req, { db, config, clock }) {
  if (config.isTest) {
    const header = req.headers['x-test-user'];
    if (typeof header === 'string' && header.length > 0) {
      const email = normalizeEmail(header);
      if (!isValidEmail(email)) return null;
      return findOrCreateUser(db, email, clock.now());
    }
  }
  const cookies = parseCookies(req.headers.cookie);
  const sid = cookies[SESSION_COOKIE];
  if (!sid) return null;
  return findSessionUser(db, sid, clock.now());
}

export function constantTimeEquals(a, b) {
  const bufA = Buffer.from(String(a));
  const bufB = Buffer.from(String(b));
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}
