// Single source of truth for "are we in test mode?".
// Read ONCE at boot. Nothing downstream may look at process.env again -- that is how a
// test-only auth shim leaks into production (see PLAN.md pre-mortem #1).

const DEFAULT_PORT = 3000;

export function loadConfig(env = process.env) {
  const appEnv = env.APP_ENV || 'development';
  const isTest = appEnv === 'test';
  const port = Number.parseInt(env.PORT ?? String(DEFAULT_PORT), 10);
  if (!Number.isInteger(port) || port < 0 || port > 65535) {
    throw new Error(`Invalid PORT: ${env.PORT}`);
  }

  const baseUrl = (env.BASE_URL || `http://localhost:${port}`).replace(/\/+$/, '');

  // In test the mailer is ALWAYS the fake. The test path must never open a socket to a
  // third-party service, and that guarantee must not depend on a test remembering to opt in.
  const mailDriver = isTest ? 'fake' : (env.MAIL_DRIVER || 'console');

  const config = {
    appEnv,
    isTest,
    port,
    baseUrl,
    dbPath: env.DB_PATH || './data/snip.db',
    trustProxy: env.TRUST_PROXY === '1',
    mailer: {
      driver: mailDriver,
      from: env.MAIL_FROM || 'no-reply@snip.local',
      endpoint: env.MAIL_API_URL || 'https://api.resend.com/emails',
      apiKey: env.MAIL_API_KEY || ''
    },
    magicLinkTtlMs: 15 * 60 * 1000,
    sessionTtlMs: 30 * 24 * 60 * 60 * 1000,
    rateLimit: { limit: 10, windowMs: 60 * 1000 },
    codeLength: 7
  };

  // Fail at boot, not on the first user who tries to sign in.
  if (config.mailer.driver === 'http' && !config.mailer.apiKey) {
    throw new Error('MAIL_DRIVER=http requires MAIL_API_KEY');
  }
  return config;
}
