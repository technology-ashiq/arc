// Sliding-window limiter, keyed by client IP (the brief says per IP, not per user).
// Clock-injected so tests can jump the window instead of sleeping for a minute.

export function createRateLimiter({ limit, windowMs, clock }) {
  const hits = new Map(); // key -> epoch-ms timestamps, oldest first
  let checksSinceSweep = 0;

  function prune(key, now) {
    const stamps = hits.get(key);
    if (!stamps) return [];
    const cutoff = now - windowMs;
    while (stamps.length > 0 && stamps[0] <= cutoff) stamps.shift();
    if (stamps.length === 0) hits.delete(key);
    return stamps;
  }

  // Unbounded IP keys would be a slow memory leak on a public endpoint.
  function sweep(now) {
    for (const key of [...hits.keys()]) prune(key, now);
  }

  return {
    // Consumes one token when allowed. Returns { allowed, retryAfterSeconds, remaining }.
    check(key) {
      const now = clock.now();
      if (++checksSinceSweep >= 1000) { checksSinceSweep = 0; sweep(now); }

      const stamps = prune(key, now);
      if (stamps.length >= limit) {
        const waitMs = stamps[0] + windowMs - now;
        return {
          allowed: false,
          remaining: 0,
          retryAfterSeconds: Math.max(1, Math.ceil(waitMs / 1000))
        };
      }
      if (stamps.length === 0) hits.set(key, stamps);
      stamps.push(now);
      return { allowed: true, remaining: limit - stamps.length, retryAfterSeconds: 0 };
    },
    reset() { hits.clear(); checksSinceSweep = 0; }
  };
}
