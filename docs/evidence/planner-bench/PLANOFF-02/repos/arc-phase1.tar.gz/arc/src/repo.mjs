// Every SQL statement in the app lives here. Callers pass epoch-ms; nothing here reads a clock.

// node:sqlite surfaces constraint failures as generic errors; identify them structurally so a
// duplicate alias becomes a 409 instead of a 500.
export function isUniqueViolation(err) {
  return err?.errcode === 1555 || err?.errcode === 2067 ||
    /UNIQUE constraint failed|PRIMARY KEY/i.test(String(err?.message ?? ''));
}

/* ---------- users ---------- */

export function findOrCreateUser(db, email, nowMs) {
  const existing = db.prepare('SELECT id, email FROM users WHERE email = ?').get(email);
  if (existing) return existing;
  try {
    db.prepare('INSERT INTO users (email, created_at) VALUES (?, ?)').run(email, nowMs);
  } catch (err) {
    if (!isUniqueViolation(err)) throw err; // lost a race: fall through and read it back
  }
  return db.prepare('SELECT id, email FROM users WHERE email = ?').get(email);
}

/* ---------- magic tokens (single use, time limited) ---------- */

export function createMagicToken(db, { token, email, expiresAt, nowMs }) {
  db.prepare(
    'INSERT INTO magic_tokens (token, email, expires_at, created_at) VALUES (?, ?, ?, ?)'
  ).run(token, email, expiresAt, nowMs);
}

// Returns the email, or null if the token is unknown, already used, or expired.
export function consumeMagicToken(db, token, nowMs) {
  const row = db.prepare('SELECT token, email, expires_at, used_at FROM magic_tokens WHERE token = ?').get(token);
  if (!row || row.used_at !== null || row.expires_at <= nowMs) return null;
  const res = db.prepare('UPDATE magic_tokens SET used_at = ? WHERE token = ? AND used_at IS NULL').run(nowMs, token);
  if (res.changes !== 1) return null; // concurrent consumer won
  return row.email;
}

/* ---------- sessions ---------- */

export function createSession(db, { id, userId, expiresAt, nowMs }) {
  db.prepare('INSERT INTO sessions (id, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)')
    .run(id, userId, expiresAt, nowMs);
}

export function findSessionUser(db, sessionId, nowMs) {
  return db.prepare(
    `SELECT u.id, u.email FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.id = ? AND s.expires_at > ?`
  ).get(sessionId, nowMs) ?? null;
}

export function deleteSession(db, sessionId) {
  db.prepare('DELETE FROM sessions WHERE id = ?').run(sessionId);
}

/* ---------- links ---------- */

// Throws on duplicate code/alias -- uniqueness is the database's job, not a pre-check (race).
export function insertLink(db, { code, url, userId, expiresAt, nowMs }) {
  db.prepare(
    'INSERT INTO links (code, url, user_id, hits, expires_at, created_at) VALUES (?, ?, ?, 0, ?, ?)'
  ).run(code, url, userId, expiresAt ?? null, nowMs);
}

export function listLinksForUser(db, userId) {
  return db.prepare(
    `SELECT code, url, hits, expires_at FROM links
     WHERE user_id = ? AND deleted_at IS NULL
     ORDER BY created_at DESC, code ASC`
  ).all(userId);
}

// Soft delete: the row (and its code) survives forever so the code reads as GONE, not UNKNOWN.
// Returns 'deleted' | 'already-deleted' | 'not-found'. Someone else's link is 'not-found':
// we do not confirm the existence of another user's code.
export function softDeleteLink(db, code, userId, nowMs) {
  const row = db.prepare('SELECT code, user_id, deleted_at FROM links WHERE code = ?').get(code);
  if (!row || row.user_id !== userId) return 'not-found';
  if (row.deleted_at !== null) return 'already-deleted';
  db.prepare('UPDATE links SET deleted_at = ? WHERE code = ? AND deleted_at IS NULL').run(nowMs, code);
  return 'deleted';
}

// Resolve a code for redirection AND count the hit atomically, so the counter can never drift
// from the redirects actually served, and a hit is never counted for a request that 404s/410s.
export function takeRedirect(db, code, nowMs) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const row = db.prepare('SELECT code, url, expires_at, deleted_at FROM links WHERE code = ?').get(code);
    let result;
    if (!row) {
      result = { status: 'not-found' };
    } else if (row.deleted_at !== null) {
      result = { status: 'deleted' };
    } else if (row.expires_at !== null && row.expires_at <= nowMs) {
      result = { status: 'expired' };
    } else {
      db.prepare('UPDATE links SET hits = hits + 1 WHERE code = ?').run(code);
      result = { status: 'ok', url: row.url };
    }
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

/* ---------- test-mode reset ---------- */

export function resetAll(db) {
  db.exec('DELETE FROM links; DELETE FROM sessions; DELETE FROM magic_tokens; DELETE FROM users;');
}
