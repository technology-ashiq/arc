# PROGRESS — snip

Cold-reader summary: **snip is done and shipped.** All 5 phases from [PLAN.md](PLAN.md) are closed,
each against its Definition of Done, with `npm test` run and seen green (29/29) and the app
demonstrated live on the exact required start command.

## Now
Nothing in flight. The build is complete. Next work would come off the *Not built* list below.

## Phases

| Phase | Scope | State | Evidence |
|---|---|---|---|
| 0 | Seams: config, clock (real+fake), mailer (fake/console/http), SQLite schema | **Done** | Migrations run on a real file DB in every test; `test/security.test.mjs` asserts `APP_ENV=test` => fake mailer |
| 1 | Auth & tenancy: magic link, sessions, `X-Test-User` shim | **Done** | `test/security.test.mjs` — shim **ignored** in prod (401), reset endpoint 404 in prod, single-use tokens, cross-user isolation |
| 2 | Links: create, redirect, count, list, delete | **Done** | `test/links.test.mjs` — 201/302/hit-count/409 on duplicate alias/**410 vs 404**/405/415 |
| 3 | Expiry | **Done** | `test/expiry.test.mjs` — fake clock advanced past `expiresAt` => 410; exact-boundary test; past expiry => 400 |
| 4 | Rate limiting, 10/min/IP | **Done** | `test/ratelimit.test.mjs` — 11th => 429 with `Retry-After`; waiting the advertised time works; per-IP not per-user |
| 5 | Persistence, entry point, dashboard, README | **Done** | `test/persistence.test.mjs` — restart from the same DB file; child-process boot of the real `server.mjs` |

## Definition of Done — checked, not assumed
- [x] `PORT=3201 APP_ENV=test node server.mjs` starts and serves — run live: create (auto + alias),
      redirect, hit count, cross-user isolation, delete => 410, unknown => 404, restart => data
      survives, 12 creates => `201 x10, 429, 429` with `retry-after: 60`.
- [x] `npm test` green: **29 passed, 0 failed**.
- [x] No network on the test path: the mailer is the in-memory fake in `APP_ENV=test` (asserted),
      the only sockets opened are to `127.0.0.1`.
- [x] `README.md` starts the app in one command.

## Decisions recorded along the way
1. **Delete = tombstone.** `deleted_at` on a row whose `code` stays in the PRIMARY KEY index.
   Gives an honest **410 Gone**, and permanently retires the code. A hard delete would have made a
   deleted link indistinguishable from one that never existed, and would let an alias be re-pointed.
2. **Expired => 410, not 404.** Same reasoning: the code was issued; it is over, not unknown.
3. **Someone else's code => 404 on DELETE**, not 403. A 403 would confirm the code exists to a
   stranger. The owner's own repeat delete is **204** (idempotent).
4. **A rejected create still spends rate-limit budget.** Otherwise a flood of malformed bodies is a
   free way to probe the service.
5. **401 does not spend budget** — an unauthenticated request is not a "create".
6. **`X-Forwarded-For` ignored unless `TRUST_PROXY=1`.** A spoofable IP makes a per-IP limit theatre.
7. **Reserved aliases (`api`, `dashboard`, `healthz`, ...) => 400, not 409.** They are not "taken" by
   anyone; they are not grantable.
8. **`npm test` uses `test/*.test.mjs`, not `test/`** — Node 22.22 rejects a bare directory path
   (`Cannot find module '.../test'`). Found by running it, not by assuming.

## Not built (deliberately out of scope, no stubs left behind)
- No password auth, no OAuth: magic link only, per the brief.
- No admin/global view of links; every read is scoped to the owner.
- No click analytics beyond a hit counter (no referrer, no geo, no per-hit rows).
- Rate-limit state is in-process memory, so it is per-instance. Fine for one node; a multi-instance
  deploy would need shared state (Redis) — the limiter is already behind a small interface in
  `src/ratelimit.mjs`, so that swap is local.
