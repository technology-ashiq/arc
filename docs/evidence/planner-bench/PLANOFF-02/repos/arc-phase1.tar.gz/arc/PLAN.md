# snip — PLAN

A URL shortener. Signed-in users create short links; anyone can follow them; hits are counted;
owners see and delete only their own links.

Stack (fixed by the brief): Node 22 ESM · `node:http` · `node:sqlite` (`DatabaseSync`) at `./data/snip.db`.
Entry point: `server.mjs`, started with `PORT=3201 APP_ENV=test node server.mjs`.

---

## Pre-mortem — it is two weeks later and snip shipped broken. What went wrong?

Each item is a specific way *this* spec gets got wrong, plus the decision I am making now.

1. **The test auth shim became a production auth bypass.**
   Somebody sends `X-Test-User: victim@example.com` to prod and owns every account.
   → **Decision:** the shim is read in exactly one place (`resolveUser` in `src/auth.mjs`) and is
   gated on `config.isTest`, which is derived once at boot from `APP_ENV === 'test'`. Not a
   per-request env read, not a `NODE_ENV` check. A test asserts that a production-config app
   returns **401** for a request carrying `X-Test-User`, and that `/api/test/reset` is **404**
   there. Both are in `test/security.test.mjs`.

2. **Delete was implemented as `DELETE FROM links` — so a deleted code answers 404, "never existed".**
   The brief explicitly says the code must be *gone*, not *unknown*. A hard delete also frees the
   code for re-registration, which silently re-points somebody's printed QR code at a new URL.
   → **Decision:** delete is a **tombstone** (`deleted_at`). The row and its `code` stay in the
   table forever. `GET /:code` on a deleted link → **410 Gone**. Unknown code → **404**.
   The `code` PRIMARY KEY covers tombstones, so a deleted code can never be reissued.

3. **Expiry compared strings, or compared against the wrong clock, so links expired a timezone away.**
   → **Decision:** `expires_at` is stored as an **INTEGER epoch-ms**, parsed once from ISO-8601 at
   the boundary. All time comes from an injected `clock` (`src/clock.mjs`), never a bare
   `Date.now()` inside a handler. Tests use a **fake clock** and advance it — no `setTimeout`, no
   flakiness. Expired link → **410 Gone** (it existed; it is over), not 404.

4. **Race on code/alias uniqueness: two concurrent creates check-then-insert and both "win".**
   A `SELECT ... WHERE code = ?` followed by an `INSERT` is not atomic.
   → **Decision:** uniqueness is enforced by the **database** (`code TEXT PRIMARY KEY`), never by a
   pre-check. The insert is attempted and a `SQLITE_CONSTRAINT_PRIMARYKEY` error is translated:
   user-supplied alias → **409 Conflict**; auto-generated code → retry with a new random code
   (up to 5 attempts, then 500). This is also why the tombstone matters: the constraint sees it.

5. **Rate limiting counted per-user, or returned 429 with no way to know when to come back.**
   The brief says **per IP**, and says the caller must be told how long to wait.
   → **Decision:** sliding window, 10 creates / 60s, keyed on the client IP. The 429 carries a
   `Retry-After` header **and** `retryAfterSeconds` in the body. `X-Forwarded-For` is only trusted
   when `TRUST_PROXY=1`, otherwise an attacker spoofs the header and the limit is decorative.

6. **The test suite hit the real email provider** — CI is offline, tests fail; or worse, they pass
   and we spam a real inbox.
   → **Decision:** the mailer is an **interface with three implementations** selected by config —
   `fake` (in-memory outbox), `console` (dev), `http` (real provider via `fetch`).
   `APP_ENV=test` forces `fake`, and the mailer is constructed at boot from config, never
   monkey-patched in a test. A test asserts the test-env mailer driver is `fake`. Nothing on the
   test path opens a socket to anything but localhost.

7. **Open redirect / stored javascript: URL.** `POST /api/links {"url":"javascript:alert(1)"}` and
   the shortener becomes an XSS delivery service.
   → **Decision:** the URL is parsed with `new URL()` and the protocol must be `http:` or `https:`.
   Anything else → 400.

8. **The alias collided with a real route** — someone registers the alias `api` and the dashboard
   breaks, or registers `1` and it shadows nothing but looks broken.
   → **Decision:** a reserved-word list (`api`, `dashboard`, `healthz`, `favicon.ico`, `robots.txt`)
   and a strict alias charset `[A-Za-z0-9_-]{3,32}`. Rejected → 400 (it is a bad request, not a
   conflict).

9. **Hits were counted on requests that did not redirect** (expired, deleted, 404), so the numbers
   are meaningless.
   → **Decision:** the counter increments **only** on the path that actually emits the 302.

10. **"Survives a restart" was never actually tested** — the DB was in-memory the whole time and
    nobody noticed until deploy.
    → **Decision:** `test/persistence.test.mjs` writes to a real file, closes the DB and the HTTP
    server, reopens from the same path, and follows the link. Plus a smoke test that spawns the
    real `server.mjs` as a child process, because the entry point is a thing that can break on its
    own.

11. **Errors were whatever was convenient** (200 with `{ok:false}`, or 500 for a bad request).
    → **Decision:** the status codes above are asserted in tests, one assertion per case.
    401 unauth · 400 bad input · 404 unknown · 409 taken · 410 gone/expired · 429 rate-limited.

---

## Phases — ordered by what could kill the build, riskiest first

Riskiest = the things that are hardest to retrofit, or that are silently wrong if I get them wrong.

**Phase 0 — Skeleton + seams.** `config` (env→config, incl. `isTest`), `clock` (system + fake),
`mailer` (interface + fake/console/http), `db` (open + migrate). No HTTP yet.
*DoD:* migrations run against a temp file DB; config test proves `APP_ENV=test` ⇒ fake mailer.

**Phase 1 — Auth & tenancy.** Riskiest: a leak here means every other feature is wrong.
Magic-link request/callback + session cookie, plus the `X-Test-User` shim gated on `isTest`.
*DoD:* `test/security.test.mjs` green — shim works in test, is **ignored** in prod (401), reset
endpoint 404 in prod; magic link round-trip works using the **fake** mailer only.

**Phase 2 — Links core: create, redirect, count, list, delete.** Includes the two semantics that
are easy to get wrong and hard to fix later: **tombstone ⇒ 410** and **DB-enforced uniqueness**.
*DoD:* `test/links.test.mjs` green — 201/302/hit-count/list-is-own-only/404 vs 410/409 on alias.

**Phase 3 — Expiry.** Needs the fake clock from Phase 0.
*DoD:* create +1h, advance clock 2h, redirect → 410; past `expiresAt` → 400.

**Phase 4 — Rate limiting.** Last of the behavioural phases: it is additive and does not change
data shape, so it cannot invalidate earlier work.
*DoD:* 10 ok, 11th → 429 with `Retry-After` ≥ 1; advance clock 60s ⇒ allowed again.

**Phase 5 — Persistence + entry point + dashboard + README.**
*DoD:* restart test green; child-process smoke test on `node server.mjs` green; `npm test` all
green; the exact required start command demonstrated live.

## Layout
```
server.mjs              # entry: config → db → deps → http.listen(PORT)
src/config.mjs          # env → config (single source of isTest)
src/clock.mjs           # systemClock | createFakeClock
src/mailer.mjs          # createMailer(cfg): fake | console | http
src/db.mjs              # openDatabase + migrations
src/repo.mjs            # users, links, sessions, magic tokens (all SQL lives here)
src/ratelimit.mjs       # sliding window, clock-injected
src/auth.mjs            # resolveUser (test shim + session cookie)
src/app.mjs             # createApp(deps) → http.Server; routing + status codes
src/public/index.html   # minimal dashboard
test/                   # node:test, fake clock + fake mailer, no network
```
