// snip -- entry point.
//   PORT=3201 APP_ENV=test node server.mjs
//
// Composition root: this is the ONLY file that reads process.env or picks real implementations.
// Everything below it receives its dependencies (clock, mailer, db) as arguments, which is what
// makes the test suite able to run offline with a fake clock and a fake mailer.
import { loadConfig } from './src/config.mjs';
import { openDatabase } from './src/db.mjs';
import { createMailer } from './src/mailer.mjs';
import { systemClock } from './src/clock.mjs';
import { createApp } from './src/app.mjs';

const config = loadConfig(process.env);
const db = openDatabase(config.dbPath);
const mailer = createMailer(config.mailer);
const server = createApp({ config, db, clock: systemClock, mailer });

server.listen(config.port, () => {
  const { port } = server.address();
  console.log(`[snip] listening on http://localhost:${port}  (APP_ENV=${config.appEnv}, db=${config.dbPath}, mail=${mailer.driver})`);
  if (config.isTest) console.log('[snip] TEST MODE: X-Test-User header is honoured and /api/test/reset is enabled.');
});

function shutdown(signal) {
  console.log(`[snip] ${signal} -- shutting down`);
  server.close(() => {
    try { db.close(); } catch { /* already closed */ }
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 5000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
