import test, { before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startHarness, createLink } from './helpers.mjs';

const USER = 'ada@example.com';
let app;

before(async () => { app = await startHarness(); });
after(async () => { await app.stop(); });
beforeEach(async () => { await app.reset(); });

test('10 creates per minute per IP; the 11th is 429 and says how long to wait', async () => {
  for (let i = 0; i < 10; i++) {
    const { status } = await createLink(app, USER, { url: `https://example.com/${i}` });
    assert.equal(status, 201, `create #${i + 1} should be allowed`);
  }

  const blocked = await createLink(app, USER, { url: 'https://example.com/11' });
  assert.equal(blocked.status, 429);
  assert.equal(blocked.body.error, 'rate_limited');

  // The caller must be TOLD how long to wait -- in the header and in the body.
  const retryAfterHeader = Number(blocked.res.headers.get('retry-after'));
  assert.ok(Number.isInteger(retryAfterHeader) && retryAfterHeader >= 1 && retryAfterHeader <= 60,
    `Retry-After should be a sane number of seconds, got ${retryAfterHeader}`);
  assert.equal(blocked.body.retryAfterSeconds, retryAfterHeader);
});

test('waiting the advertised time actually works (sliding window)', async () => {
  for (let i = 0; i < 10; i++) await createLink(app, USER, { url: `https://example.com/${i}` });

  const blocked = await createLink(app, USER, { url: 'https://example.com/x' });
  assert.equal(blocked.status, 429);

  app.clock.advance(blocked.body.retryAfterSeconds * 1000);

  const allowed = await createLink(app, USER, { url: 'https://example.com/after-wait' });
  assert.equal(allowed.status, 201, 'after the advertised wait the caller must get through');
});

test('rate limiting is per IP, not per user: a second identity does not reset the budget', async () => {
  for (let i = 0; i < 10; i++) await createLink(app, USER, { url: `https://example.com/${i}` });

  const otherUser = await createLink(app, 'bob@example.com', { url: 'https://example.com/bob' });
  assert.equal(otherUser.status, 429, 'the limit is keyed on the IP, and both users share this one');
});

test('the limit counts attempts, so garbage payloads cannot be used to probe for free', async () => {
  for (let i = 0; i < 10; i++) {
    const { status } = await createLink(app, USER, { url: 'nonsense' });
    assert.equal(status, 400);
  }
  const blocked = await createLink(app, USER, { url: 'https://example.com/valid' });
  assert.equal(blocked.status, 429);
});

test('/api/test/reset clears rate-limit state as well as links', async () => {
  for (let i = 0; i < 10; i++) await createLink(app, USER, { url: `https://example.com/${i}` });
  assert.equal((await createLink(app, USER, { url: 'https://example.com/x' })).status, 429);

  await app.reset();

  // Links are wiped...
  assert.deepEqual(await (await app.fetch('/api/links', { as: USER })).json(), []);
  // ...and so is the rate-limit budget: an 11th create in the same minute now succeeds.
  assert.equal((await createLink(app, USER, { url: 'https://example.com/fresh' })).status, 201);
});
