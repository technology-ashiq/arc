import test, { before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startHarness, createLink } from './helpers.mjs';

let app;          // APP_ENV=test
let prod;         // APP_ENV=production -- same code, different config

before(async () => {
  app = await startHarness();
  prod = await startHarness({ env: { APP_ENV: 'production', MAIL_DRIVER: 'console' } });
});
after(async () => { await app.stop(); await prod.stop(); });
beforeEach(async () => { await app.reset(); });

test('test mode uses the FAKE mailer -- the test path can never call a live email provider', () => {
  assert.equal(app.config.mailer.driver, 'fake');
  assert.equal(app.mailer.driver, 'fake');
});

test('X-Test-User authenticates in test mode', async () => {
  const { status, body } = await createLink(app, 'ada@example.com', { url: 'https://example.com/' });
  assert.equal(status, 201);
  assert.match(body.code, /^[A-Za-z0-9]{7}$/);
  assert.equal(body.shortUrl, `${app.config.baseUrl}/${body.code}`);
});

test('no credentials at all -> 401, not 500 and not a silent success', async () => {
  const res = await app.fetch('/api/links', { method: 'POST', json: { url: 'https://example.com/' } });
  assert.equal(res.status, 401);
  const list = await app.fetch('/api/links');
  assert.equal(list.status, 401);
});

test('OUTSIDE test mode the X-Test-User header is ignored completely -> 401', async () => {
  const create = await prod.fetch('/api/links', {
    method: 'POST', as: 'attacker@example.com', json: { url: 'https://example.com/' }
  });
  assert.equal(create.status, 401);

  const list = await prod.fetch('/api/links', { as: 'attacker@example.com' });
  assert.equal(list.status, 401);

  const del = await prod.fetch('/api/links/whatever', { method: 'DELETE', as: 'attacker@example.com' });
  assert.equal(del.status, 401, 'delete must not be reachable via the test header in production');
});

test('OUTSIDE test mode /api/test/reset does not exist -> 404', async () => {
  const res = await prod.fetch('/api/test/reset', { method: 'POST' });
  assert.equal(res.status, 404);
});

test('magic-link sign-in works end to end against the fake mailer (no network)', async () => {
  const requested = await app.fetch('/api/auth/request', {
    method: 'POST', json: { email: 'Grace@Example.com ' }
  });
  assert.equal(requested.status, 202);

  assert.equal(app.mailer.sent.length, 1);
  const message = app.mailer.sent[0];
  assert.equal(message.to, 'grace@example.com', 'email is normalised before sending');
  const link = /https?:\/\/\S+/.exec(message.text)[0];
  const token = new URL(link).searchParams.get('token');

  const callback = await app.fetch(`/api/auth/callback?token=${encodeURIComponent(token)}`);
  assert.equal(callback.status, 302);
  const cookie = callback.headers.get('set-cookie');
  assert.match(cookie, /^snip_session=/);
  assert.match(cookie, /HttpOnly/);

  const sessionCookie = cookie.split(';')[0];
  const me = await app.fetch('/api/me', { headers: { cookie: sessionCookie } });
  assert.equal(me.status, 200);
  assert.deepEqual(await me.json(), { email: 'grace@example.com' });

  // Single use: the same token cannot mint a second session.
  const replay = await app.fetch(`/api/auth/callback?token=${encodeURIComponent(token)}`);
  assert.equal(replay.status, 400);
});

test('expired magic-link token is refused', async () => {
  await app.fetch('/api/auth/request', { method: 'POST', json: { email: 'linus@example.com' } });
  const token = new URL(/https?:\/\/\S+/.exec(app.mailer.sent[0].text)[0]).searchParams.get('token');
  app.clock.advance(16 * 60 * 1000); // TTL is 15 minutes
  const res = await app.fetch(`/api/auth/callback?token=${encodeURIComponent(token)}`);
  assert.equal(res.status, 400);
});

test('a user only ever sees and touches their own links', async () => {
  const mine = await createLink(app, 'ada@example.com', { url: 'https://ada.example.com/' });
  const theirs = await createLink(app, 'bob@example.com', { url: 'https://bob.example.com/' });
  assert.equal(mine.status, 201);
  assert.equal(theirs.status, 201);

  const adaList = await (await app.fetch('/api/links', { as: 'ada@example.com' })).json();
  assert.equal(adaList.length, 1);
  assert.equal(adaList[0].code, mine.body.code);

  // Bob cannot delete Ada's link, and the 404 does not confirm that it exists.
  const del = await app.fetch(`/api/links/${mine.body.code}`, { method: 'DELETE', as: 'bob@example.com' });
  assert.equal(del.status, 404);

  const stillThere = await app.fetch(`/${mine.body.code}`);
  assert.equal(stillThere.status, 302, "Bob's failed delete must not have destroyed Ada's link");
});
