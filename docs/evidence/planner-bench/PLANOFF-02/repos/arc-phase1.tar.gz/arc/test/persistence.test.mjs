import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startHarness, createLink } from './helpers.mjs';

const USER = 'ada@example.com';
const REPO_ROOT = fileURLToPath(new URL('..', import.meta.url));

let app;
before(async () => { app = await startHarness(); });
after(async () => { await app.stop(); });

test('links survive a restart -- they are really in SQLite, not in memory', async () => {
  const { body } = await createLink(app, USER, { url: 'https://example.com/durable', alias: 'durable' });
  await app.fetch(`/${body.code}`); // one hit before the restart

  assert.ok(existsSync(app.dbPath), 'the database file exists on disk');

  await app.restart(); // closes the DB + HTTP server, reopens from the same file

  const hit = await app.fetch('/durable');
  assert.equal(hit.status, 302);
  assert.equal(hit.headers.get('location'), 'https://example.com/durable');

  const [link] = await (await app.fetch('/api/links', { as: USER })).json();
  assert.equal(link.code, 'durable');
  assert.equal(link.hits, 2, 'the hit counter survived too, and the post-restart hit was counted');
});

test('tombstones survive a restart: a deleted code is still GONE, not unknown', async () => {
  const { body } = await createLink(app, USER, { url: 'https://example.com/x', alias: 'tombstone' });
  await app.fetch(`/api/links/${body.code}`, { method: 'DELETE', as: USER });

  await app.restart();

  assert.equal((await app.fetch('/tombstone')).status, 410);
});

// The entry point is a thing that can break on its own, so exercise the real command.
test('the real server.mjs boots and serves the whole flow (child process)', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'snip-smoke-'));
  const child = spawn(process.execPath, ['server.mjs'], {
    cwd: REPO_ROOT,
    env: { ...process.env, PORT: '0', APP_ENV: 'test', DB_PATH: join(dir, 'snip.db') },
    stdio: ['ignore', 'pipe', 'pipe']
  });

  try {
    const port = await new Promise((resolve, reject) => {
      let out = '';
      const timer = setTimeout(() => reject(new Error(`server did not start; stdout:\n${out}`)), 10_000);
      child.stdout.on('data', (chunk) => {
        out += chunk;
        const match = /listening on http:\/\/localhost:(\d+)/.exec(out);
        if (match) { clearTimeout(timer); resolve(Number(match[1])); }
      });
      child.once('error', reject);
      child.once('exit', (code) => reject(new Error(`server exited early with code ${code}; stdout:\n${out}`)));
    });

    const base = `http://127.0.0.1:${port}`;
    const health = await fetch(`${base}/healthz`);
    assert.equal(health.status, 200);
    assert.deepEqual(await health.json(), { ok: true, appEnv: 'test' });

    const created = await fetch(`${base}/api/links`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'X-Test-User': USER },
      body: JSON.stringify({ url: 'https://example.com/smoke' })
    });
    assert.equal(created.status, 201);
    const { code } = await created.json();

    const redirected = await fetch(`${base}/${code}`, { redirect: 'manual' });
    assert.equal(redirected.status, 302);
    assert.equal(redirected.headers.get('location'), 'https://example.com/smoke');

    const listed = await fetch(`${base}/api/links`, { headers: { 'X-Test-User': USER } });
    assert.deepEqual((await listed.json())[0].hits, 1);

    const page = await fetch(`${base}/`);
    assert.equal(page.status, 200);
    assert.match(page.headers.get('content-type'), /text\/html/);
  } finally {
    child.kill('SIGTERM');
    await new Promise((resolve) => child.once('exit', resolve));
    rmSync(dir, { recursive: true, force: true });
  }
});
