import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { loadConfig } from '../src/config.mjs';
import { openDatabase } from '../src/db.mjs';
import { createFakeClock } from '../src/clock.mjs';
import { createMailer } from '../src/mailer.mjs';
import { createApp } from '../src/app.mjs';

// Boots the real app with the real SQLite file, a FAKE clock and a FAKE mailer.
// Nothing here touches the network: the only sockets opened are to 127.0.0.1.
export async function startHarness({ env = {}, clockStart } = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'snip-test-'));
  const dbPath = join(dir, 'snip.db');
  const clock = createFakeClock(clockStart);

  let config = loadConfig({ APP_ENV: 'test', PORT: '0', DB_PATH: dbPath, ...env });
  let db = openDatabase(config.dbPath);
  let mailer = createMailer(config.mailer);
  let server = createApp({ config, db, clock, mailer });
  await listen(server);

  const harness = {
    dir,
    dbPath,
    clock,
    get mailer() { return mailer; },
    get config() { return config; },
    get baseUrl() { return `http://127.0.0.1:${server.address().port}`; },

    async fetch(path, options = {}) {
      const headers = { ...(options.headers ?? {}) };
      if (options.as) headers['X-Test-User'] = options.as;
      if (options.json !== undefined) headers['content-type'] = 'application/json';
      return fetch(`${harness.baseUrl}${path}`, {
        ...options,
        headers,
        body: options.json !== undefined ? JSON.stringify(options.json) : options.body,
        redirect: 'manual'
      });
    },

    async reset() {
      const res = await harness.fetch('/api/test/reset', { method: 'POST' });
      if (res.status !== 204) throw new Error(`reset failed: ${res.status}`);
    },

    // Close everything and boot again from the SAME database file.
    async restart() {
      await close(server);
      db.close();
      config = loadConfig({ APP_ENV: 'test', PORT: '0', DB_PATH: dbPath, ...env });
      db = openDatabase(config.dbPath);
      mailer = createMailer(config.mailer);
      server = createApp({ config, db, clock, mailer });
      await listen(server);
    },

    async stop() {
      await close(server);
      try { db.close(); } catch { /* already closed */ }
      rmSync(dir, { recursive: true, force: true });
    }
  };
  return harness;
}

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
}

function close(server) {
  return new Promise((resolve) => server.close(resolve));
}

export async function createLink(harness, as, body) {
  const res = await harness.fetch('/api/links', { method: 'POST', as, json: body });
  return { status: res.status, body: await res.json().catch(() => null), res };
}
