import test, { before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startHarness, createLink } from './helpers.mjs';

const USER = 'ada@example.com';
let app;

before(async () => { app = await startHarness(); });
after(async () => { await app.stop(); });
beforeEach(async () => { await app.reset(); });

test('create -> redirect -> the hit is counted', async () => {
  const { status, body } = await createLink(app, USER, { url: 'https://example.com/very/long/path?a=1' });
  assert.equal(status, 201);

  const hit = await app.fetch(`/${body.code}`);
  assert.equal(hit.status, 302);
  assert.equal(hit.headers.get('location'), 'https://example.com/very/long/path?a=1');

  await app.fetch(`/${body.code}`);
  const [link] = await (await app.fetch('/api/links', { as: USER })).json();
  assert.deepEqual(link, { code: body.code, url: 'https://example.com/very/long/path?a=1', hits: 2, expiresAt: null });
});

test('an unknown code is 404 -- it never existed', async () => {
  const res = await app.fetch('/nosuch1');
  assert.equal(res.status, 404);
  assert.equal((await res.json()).error, 'not_found');
});

test('custom alias is used verbatim', async () => {
  const { status, body } = await createLink(app, USER, { url: 'https://example.com/', alias: 'my-launch' });
  assert.equal(status, 201);
  assert.equal(body.code, 'my-launch');
  assert.equal(body.shortUrl, `${app.config.baseUrl}/my-launch`);

  const hit = await app.fetch('/my-launch');
  assert.equal(hit.status, 302);
});

test('two links can never share a code: a taken alias is 409', async () => {
  await createLink(app, USER, { url: 'https://example.com/one', alias: 'dupe' });

  const same = await createLink(app, USER, { url: 'https://example.com/two', alias: 'dupe' });
  assert.equal(same.status, 409);
  assert.equal(same.body.error, 'alias_taken');

  // ...including across users -- the namespace is global.
  const other = await createLink(app, 'bob@example.com', { url: 'https://example.com/three', alias: 'dupe' });
  assert.equal(other.status, 409);

  const hit = await app.fetch('/dupe');
  assert.equal(hit.headers.get('location'), 'https://example.com/one', 'the first owner keeps the code');
});

test('a DELETED code cannot be re-registered as an alias -- the code is spent', async () => {
  await createLink(app, USER, { url: 'https://example.com/one', alias: 'burned' });
  const del = await app.fetch('/api/links/burned', { method: 'DELETE', as: USER });
  assert.equal(del.status, 204);

  const retry = await createLink(app, USER, { url: 'https://example.com/two', alias: 'burned' });
  assert.equal(retry.status, 409, 'reissuing a deleted code would silently re-point printed links');
});

test('bad input is 400, with the reason', async () => {
  const cases = [
    [{ url: 'javascript:alert(1)' }, 'invalid_url'],
    [{ url: 'not a url' }, 'invalid_url'],
    [{ url: 'ftp://example.com/x' }, 'invalid_url'],
    [{}, 'invalid_url'],
    [{ url: 'https://example.com/', alias: 'no' }, 'invalid_alias'],
    [{ url: 'https://example.com/', alias: 'has spaces' }, 'invalid_alias'],
    [{ url: 'https://example.com/', alias: 'api' }, 'reserved_alias'],
    [{ url: 'https://example.com/', expiresAt: 'tomorrow-ish' }, 'invalid_expires_at']
  ];
  for (const [payload, expected] of cases) {
    const { status, body } = await createLink(app, USER, payload);
    assert.equal(status, 400, `expected 400 for ${JSON.stringify(payload)}`);
    assert.equal(body.error, expected);
  }
});

test('DELETE: the code is GONE (410), not unknown (404)', async () => {
  const { body } = await createLink(app, USER, { url: 'https://example.com/' });

  const del = await app.fetch(`/api/links/${body.code}`, { method: 'DELETE', as: USER });
  assert.equal(del.status, 204);

  const hit = await app.fetch(`/${body.code}`);
  assert.equal(hit.status, 410, 'a deleted link is gone, not unknown');
  const payload = await hit.json();
  assert.equal(payload.error, 'gone');
  assert.match(payload.message, /deleted/i);

  const list = await (await app.fetch('/api/links', { as: USER })).json();
  assert.equal(list.length, 0, 'a deleted link leaves the dashboard');

  // Deleting again is idempotent; deleting something that never was is 404.
  assert.equal((await app.fetch(`/api/links/${body.code}`, { method: 'DELETE', as: USER })).status, 204);
  assert.equal((await app.fetch('/api/links/nosuch1', { method: 'DELETE', as: USER })).status, 404);
});

test('hits are only counted when a redirect is actually served', async () => {
  const { body } = await createLink(app, USER, { url: 'https://example.com/' });
  await app.fetch(`/${body.code}`);                                   // counted
  await app.fetch('/nosuch1');                                        // 404, not counted
  await app.fetch(`/api/links/${body.code}`, { method: 'DELETE', as: USER });
  await app.fetch(`/${body.code}`);                                   // 410, not counted

  const rows = await (await app.fetch('/api/links', { as: USER })).json();
  assert.equal(rows.length, 0);

  // Re-create under a fresh code and confirm the counter starts at zero, not at the old value.
  const again = await createLink(app, USER, { url: 'https://example.com/' });
  const [fresh] = await (await app.fetch('/api/links', { as: USER })).json();
  assert.equal(fresh.code, again.body.code);
  assert.equal(fresh.hits, 0);
});

test('wrong method and wrong content-type are reported honestly', async () => {
  assert.equal((await app.fetch('/api/links', { method: 'PUT', as: USER })).status, 405);
  const res = await app.fetch('/api/links', {
    method: 'POST', as: USER, body: 'url=https://example.com', headers: { 'content-type': 'text/plain' }
  });
  assert.equal(res.status, 415);
});
