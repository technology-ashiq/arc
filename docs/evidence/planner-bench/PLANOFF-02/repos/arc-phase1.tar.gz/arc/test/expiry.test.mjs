import test, { before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startHarness, createLink } from './helpers.mjs';

const USER = 'ada@example.com';
const HOUR = 60 * 60 * 1000;
let app;

before(async () => { app = await startHarness(); });
after(async () => { await app.stop(); });
beforeEach(async () => { await app.reset(); });

// The fake clock is what makes this test honest: we jump time instead of sleeping,
// so nothing here is timing-flaky and the assertion is about behaviour, not luck.
test('an expired link stops redirecting -- 410 Gone', async () => {
  const expiresAt = new Date(app.clock.now() + HOUR).toISOString();
  const { status, body } = await createLink(app, USER, { url: 'https://example.com/', expiresAt });
  assert.equal(status, 201);

  const before410 = await app.fetch(`/${body.code}`);
  assert.equal(before410.status, 302, 'still live before the expiry time');

  app.clock.advance(2 * HOUR);

  const after = await app.fetch(`/${body.code}`);
  assert.equal(after.status, 410, 'an expired link is gone, not merely missing');
  assert.equal((await after.json()).error, 'gone');
  assert.match((await (await app.fetch(`/${body.code}`)).json()).message, /expired/i);
});

test('expiry is exact: the link dies at expiresAt, not a millisecond later', async () => {
  const expiresAt = new Date(app.clock.now() + HOUR).toISOString();
  const { body } = await createLink(app, USER, { url: 'https://example.com/', expiresAt });

  app.clock.advance(HOUR - 1);
  assert.equal((await app.fetch(`/${body.code}`)).status, 302);

  app.clock.advance(1); // now exactly at expiresAt
  assert.equal((await app.fetch(`/${body.code}`)).status, 410);
});

test('expired links stay on the owner dashboard, with their expiry and hit count', async () => {
  const expiresAt = new Date(app.clock.now() + HOUR).toISOString();
  const { body } = await createLink(app, USER, { url: 'https://example.com/', expiresAt });
  await app.fetch(`/${body.code}`);          // one real hit while live
  app.clock.advance(2 * HOUR);
  await app.fetch(`/${body.code}`);          // 410, must not count

  const [link] = await (await app.fetch('/api/links', { as: USER })).json();
  assert.equal(link.hits, 1);
  assert.equal(link.expiresAt, expiresAt);
});

test('an expiry in the past is a bad request, not a link that is born dead', async () => {
  const past = new Date(app.clock.now() - 1000).toISOString();
  const { status, body } = await createLink(app, USER, { url: 'https://example.com/', expiresAt: past });
  assert.equal(status, 400);
  assert.equal(body.error, 'invalid_expires_at');
});
