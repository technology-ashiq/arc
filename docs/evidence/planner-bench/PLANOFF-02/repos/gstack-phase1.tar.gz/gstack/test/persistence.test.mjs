import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

test('links, hits and deletions survive a restart', async () => {
  const first = await startServer();
  const dbPath = first.dbPath;
  let code, deletedCode;

  try {
    code = (await (await first.api('/api/links', {
      method: 'POST', user: 'durable@example.com', body: { url: 'https://example.com/durable', alias: 'keepme' },
    })).json()).code;

    deletedCode = (await (await first.api('/api/links', {
      method: 'POST', user: 'durable@example.com', body: { url: 'https://example.com/rip' },
    })).json()).code;

    await first.call(`/${code}`);
    await first.call(`/${code}`);
    await first.api(`/api/links/${deletedCode}`, { method: 'DELETE', user: 'durable@example.com' });
  } finally {
    await first.stop();   // hard kill: no graceful flush, exactly like a crash
  }

  // Same DB file, brand-new process.
  const second = await startServer({ DB_PATH: dbPath });
  try {
    const r = await second.call(`/${code}`);
    assert.equal(r.status, 302, 'the link still redirects after a restart');
    assert.equal(r.headers.get('location'), 'https://example.com/durable');

    const links = await (await second.api('/api/links', { user: 'durable@example.com' })).json();
    assert.equal(links.length, 1, 'the deleted link stayed deleted');
    assert.equal(links[0].code, 'keepme');
    assert.equal(links[0].hits, 3, 'hit counts persisted (2 before restart + 1 after)');

    assert.equal((await second.call(`/${deletedCode}`)).status, 410, 'still gone, not unknown');

    const taken = await second.api('/api/links', {
      method: 'POST', user: 'other@example.com', body: { url: 'https://example.com/steal', alias: 'keepme' },
    });
    assert.equal(taken.status, 409, 'codes stay unique across restarts');
  } finally {
    await second.stop();
    second.cleanup();
  }
  first.cleanup();
});
