import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

let s;
before(async () => { s = await startServer(); });
after(async () => { await s.stop(); s.cleanup(); });
beforeEach(async () => {
  const res = await s.api('/api/test/reset', { method: 'POST' });
  assert.equal(res.status, 204);
});

const ALICE = 'alice@example.com';
const BOB = 'bob@example.com';

const create = (body, user = ALICE) => s.api('/api/links', { method: 'POST', user, body });

test('POST /api/links creates a link -> 201 {code, shortUrl}', async () => {
  const res = await create({ url: 'https://example.com/a/very/long/path' });
  assert.equal(res.status, 201);
  const body = await res.json();
  assert.match(body.code, /^[A-Za-z0-9]{7}$/);
  assert.equal(body.shortUrl, `${s.origin}/${body.code}`);
});

test('GET /:code redirects 302 and counts the hit', async () => {
  const { code } = await (await create({ url: 'https://example.com/dest' })).json();

  const r = await s.call(`/${code}`);
  assert.equal(r.status, 302);
  assert.equal(r.headers.get('location'), 'https://example.com/dest');

  await s.call(`/${code}`);
  await s.call(`/${code}`);
  const [link] = await (await s.api('/api/links', { user: ALICE })).json();
  assert.equal(link.hits, 3, 'every visit is counted');
});

test('concurrent visits do not lose hits (atomic counter)', async () => {
  const { code } = await (await create({ url: 'https://example.com/race' })).json();
  await Promise.all(Array.from({ length: 25 }, () => s.call(`/${code}`)));
  const [link] = await (await s.api('/api/links', { user: ALICE })).json();
  assert.equal(link.hits, 25);
});

test('GET /api/links returns only the caller own links', async () => {
  await create({ url: 'https://example.com/alice' }, ALICE);
  await create({ url: 'https://example.com/bob' }, BOB);

  const mine = await (await s.api('/api/links', { user: ALICE })).json();
  assert.equal(mine.length, 1);
  assert.equal(mine[0].url, 'https://example.com/alice');
  assert.deepEqual(Object.keys(mine[0]).sort(), ['code', 'expiresAt', 'hits', 'url']);
});

test('a custom alias is honoured', async () => {
  const res = await create({ url: 'https://example.com/docs', alias: 'my-docs' });
  assert.equal(res.status, 201);
  assert.equal((await res.json()).code, 'my-docs');
  const r = await s.call('/my-docs');
  assert.equal(r.headers.get('location'), 'https://example.com/docs');
});

test('two links can never share a code or alias -> 409', async () => {
  await create({ url: 'https://example.com/1', alias: 'dupe' });
  const mine = await create({ url: 'https://example.com/2', alias: 'dupe' });
  assert.equal(mine.status, 409);
  assert.equal((await mine.json()).error.code, 'ALIAS_TAKEN');

  // ...including against a different user: the namespace is global, not per-user.
  const theirs = await create({ url: 'https://example.com/3', alias: 'dupe' }, BOB);
  assert.equal(theirs.status, 409);
});

test('a deleted alias stays taken -- the code is gone, not freed', async () => {
  await create({ url: 'https://example.com/1', alias: 'retired' });
  assert.equal((await s.api('/api/links/retired', { method: 'DELETE', user: ALICE })).status, 204);
  const again = await create({ url: 'https://example.com/2', alias: 'retired' });
  assert.equal(again.status, 409, 'a deleted code must never be re-registered');
});

test('a deleted link is GONE (410), not unknown (404)', async () => {
  const { code } = await (await create({ url: 'https://example.com/x' })).json();
  assert.equal((await s.api(`/api/links/${code}`, { method: 'DELETE', user: ALICE })).status, 204);

  const r = await s.call(`/${code}`);
  assert.equal(r.status, 410, 'deleted != never existed');
  const body = await r.json();
  assert.equal(body.error.code, 'LINK_DELETED');
  assert.match(body.error.message, /deleted/i);

  const unknown = await s.call('/nosuchc');
  assert.equal(unknown.status, 404);
  assert.equal((await unknown.json()).error.code, 'NOT_FOUND');
});

test('a deleted link disappears from the dashboard', async () => {
  const { code } = await (await create({ url: 'https://example.com/x' })).json();
  await s.api(`/api/links/${code}`, { method: 'DELETE', user: ALICE });
  assert.deepEqual(await (await s.api('/api/links', { user: ALICE })).json(), []);
});

test('an expired link no longer redirects -> 410', async () => {
  const soon = new Date(Date.now() + 1000).toISOString();
  const { code } = await (await create({ url: 'https://example.com/temp', expiresAt: soon })).json();

  assert.equal((await s.call(`/${code}`)).status, 302, 'still live before expiry');
  await new Promise((r) => setTimeout(r, 1100));

  const r = await s.call(`/${code}`);
  assert.equal(r.status, 410);
  assert.equal((await r.json()).error.code, 'LINK_EXPIRED');
});

test('expiresAt round-trips as ISO-8601', async () => {
  const at = new Date(Date.now() + 3_600_000).toISOString();
  await create({ url: 'https://example.com/e', expiresAt: at });
  const [link] = await (await s.api('/api/links', { user: ALICE })).json();
  assert.equal(link.expiresAt, at);
});

test('you cannot delete, or even detect, someone else link -> 404', async () => {
  const { code } = await (await create({ url: 'https://example.com/private' }, ALICE)).json();
  const res = await s.api(`/api/links/${code}`, { method: 'DELETE', user: BOB });
  assert.equal(res.status, 404, '403 would confirm the code exists to a stranger');

  const r = await s.call(`/${code}`);
  assert.equal(r.status, 302, 'and Alice link is untouched');
});

test('unauthenticated callers get 401, not 500 or 200', async () => {
  assert.equal((await s.api('/api/links')).status, 401);
  assert.equal((await s.api('/api/links', { method: 'POST', body: { url: 'https://a.co' } })).status, 401);
  assert.equal((await s.api('/api/links/abc', { method: 'DELETE' })).status, 401);
});

test('rejects URLs that are not http(s) -- no javascript: XSS dispenser', async () => {
  for (const url of ['javascript:alert(1)', 'data:text/html,<script>x</script>', 'file:///etc/passwd', 'not a url', '']) {
    const res = await create({ url });
    assert.equal(res.status, 400, `${url} must be rejected`);
  }
  assert.equal((await create({})).status, 400);
});

test('rejects bad aliases, reserved aliases and past expiries', async () => {
  assert.equal((await create({ url: 'https://a.co', alias: 'no' })).status, 400);
  assert.equal((await create({ url: 'https://a.co', alias: 'has spaces' })).status, 400);
  assert.equal((await create({ url: 'https://a.co', alias: '../etc' })).status, 400);
  assert.equal((await create({ url: 'https://a.co', alias: 'api' })).status, 400);
  assert.equal((await create({ url: 'https://a.co', expiresAt: 'yesterday' })).status, 400);

  const past = new Date(Date.now() - 60_000).toISOString();
  const res = await create({ url: 'https://a.co', expiresAt: past });
  assert.equal(res.status, 400);
  assert.equal((await res.json()).error.code, 'EXPIRY_IN_PAST');
});

test('an alias can never shadow the API', async () => {
  // "api" is refused above; prove the router would win anyway.
  const res = await s.api('/api/links', { user: ALICE });
  assert.equal(res.status, 200, '/api/links is the API, never a short code');
});
