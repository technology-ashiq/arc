// Regression tests for the findings in REVIEW.md. Each of these failed before the fix.
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

let s;
before(async () => { s = await startServer(); });
after(async () => { await s.stop(); s.cleanup(); });
beforeEach(async () => { await s.api('/api/test/reset', { method: 'POST' }); });

// SEC-01 / COR-01: decodeURIComponent throws URIError on "%zz" -> used to 500.
test('malformed percent-encoding is a 404, never a 500', async () => {
  assert.equal((await s.call('/%zz')).status, 404);
  assert.equal((await s.call('/%')).status, 404);
  const del = await s.api('/api/links/%zz', { method: 'DELETE', user: 'a@example.com' });
  assert.equal(del.status, 404);
});

// SEC-02: a junk session cookie is "not signed in", not a crash.
test('a malformed session cookie is 401, never a 500', async () => {
  const res = await s.call('/api/links', { headers: { cookie: 'snip_session=%zz' } });
  assert.equal(res.status, 401);
});

// SEC-03: /api/auth/request was unbounded -> anyone could bomb a stranger's inbox.
test('magic-link requests are rate limited too', async () => {
  const ask = () => s.api('/api/auth/request', { method: 'POST', body: { email: 'victim@example.com' } });
  for (let i = 0; i < 5; i++) assert.equal((await ask()).status, 202);
  const res = await ask();
  assert.equal(res.status, 429, 'we must not be an email-bombing service');
  assert.ok(Number(res.headers.get('retry-after')) >= 1);
});

// SEC-03b: ...and that budget is separate from the 10/min link-creation budget.
test('sign-in requests do not eat into the 10/min link-creation budget', async () => {
  for (let i = 0; i < 5; i++) {
    await s.api('/api/auth/request', { method: 'POST', body: { email: 'someone@example.com' } });
  }
  for (let i = 0; i < 10; i++) {
    const res = await s.api('/api/links', {
      method: 'POST', user: 'c@example.com', body: { url: 'https://example.com/x' },
    });
    assert.equal(res.status, 201, `create #${i + 1} must still be allowed`);
  }
});

// COR-02: HEAD on a live code used to 404 while GET returned 302.
test('HEAD on a short code behaves like GET', async () => {
  const { code } = await (await s.api('/api/links', {
    method: 'POST', user: 'h@example.com', body: { url: 'https://example.com/head' },
  })).json();
  const res = await s.call(`/${code}`, { method: 'HEAD' });
  assert.equal(res.status, 302);
  assert.equal(res.headers.get('location'), 'https://example.com/head');
});

test('responses carry X-Content-Type-Options: nosniff', async () => {
  const res = await s.call('/health');
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
});

test('junk bodies and wrong methods do not 500', async () => {
  const bad = await s.call('/api/links', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'X-Test-User': 'a@example.com' },
    body: '{not json',
  });
  assert.equal(bad.status, 400);

  const arr = await s.api('/api/links', { method: 'POST', user: 'a@example.com', body: [1, 2] });
  assert.equal(arr.status, 400);

  const wrong = await s.api('/api/links', { method: 'PUT', user: 'a@example.com', body: {} });
  assert.equal(wrong.status, 405);

  const nope = await s.api('/api/nope', { user: 'a@example.com' });
  assert.equal(nope.status, 404);
});
