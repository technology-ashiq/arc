import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));

/**
 * Boot the REAL server.mjs as a child process on an ephemeral port with its own DB file.
 * No network is involved: everything is loopback, and no mailer ever leaves the process.
 */
export async function startServer(env = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'snip-test-'));
  const dbPath = join(dir, 'snip.db');
  const child = spawn(process.execPath, ['server.mjs'], {
    cwd: ROOT,
    env: { ...process.env, PORT: '0', APP_ENV: 'test', DB_PATH: dbPath, ...env },
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  const stdout = [];
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stderr.on('data', () => {});   // node:sqlite prints an ExperimentalWarning; ignore it

  const port = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('server did not start in time')), 10_000);
    child.stdout.on('data', (chunk) => {
      stdout.push(chunk);
      const m = /listening on http:\/\/localhost:(\d+)/.exec(stdout.join(''));
      if (m) { clearTimeout(timer); resolve(Number(m[1])); }
    });
    child.on('exit', (code) => reject(new Error(`server exited early (${code})`)));
  });

  const origin = `http://127.0.0.1:${port}`;
  return {
    origin,
    dbPath,
    stdout: () => stdout.join(''),
    async stop() {
      child.kill('SIGKILL');
      await new Promise((r) => child.on('exit', r));
    },
    cleanup() { rmSync(dir, { recursive: true, force: true }); },
    /** fetch that never follows redirects, so we can assert on the 302 itself */
    call(path, opts = {}) {
      return fetch(`${origin}${path}`, { redirect: 'manual', ...opts });
    },
    api(path, { user, method = 'GET', body, headers = {} } = {}) {
      const h = { ...headers };
      if (user) h['X-Test-User'] = user;
      if (body !== undefined) h['content-type'] = 'application/json';
      return fetch(`${origin}${path}`, {
        method,
        headers: h,
        body: body === undefined ? undefined : JSON.stringify(body),
        redirect: 'manual',
      });
    },
  };
}
