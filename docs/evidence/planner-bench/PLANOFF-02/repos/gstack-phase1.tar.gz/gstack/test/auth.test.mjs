import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

test('test mode: X-Test-User authenticates and sends no email', async () => {
  const s = await startServer({ APP_ENV: 'test' });
  try {
    const res = await s.api('/api/links', {
      method: 'POST', user: 'shim@example.com', body: { url: 'https://example.com' },
    });
    assert.equal(res.status, 201);
    assert.doesNotMatch(s.stdout(), /snip:mail/, 'no mail is sent in test mode');
  } finally { await s.stop(); s.cleanup(); }
});

test('outside test mode, X-Test-User is ignored completely', async () => {
  const s = await startServer({ APP_ENV: 'prod' });
  try {
    const attempts = [
      s.api('/api/links', { method: 'POST', user: 'attacker@evil.com', body: { url: 'https://evil.com' } }),
      s.api('/api/links', { user: 'attacker@evil.com' }),
      s.api('/api/links/whatever', { method: 'DELETE', user: 'attacker@evil.com' }),
    ];
    for (const res of await Promise.all(attempts)) {
      assert.equal(res.status, 401, 'the shim header must be inert outside APP_ENV=test');
    }
  } finally { await s.stop(); s.cleanup(); }
});

test('outside test mode, POST /api/test/reset does not exist', async () => {
  const s = await startServer({ APP_ENV: 'prod' });
  try {
    const res = await s.api('/api/test/reset', { method: 'POST' });
    assert.equal(res.status, 404, 'there is no reset switch to find in production');
  } finally { await s.stop(); s.cleanup(); }
});

test('magic-link sign-in is the real path in prod -- and needs no network', async () => {
  // APP_ENV=prod uses ConsoleMailer, which writes the link to stdout instead of calling a
  // provider. We read the child's stdout: a full sign-in, zero sockets to the outside world.
  const s = await startServer({ APP_ENV: 'prod' });
  try {
    const req = await s.api('/api/auth/request', { method: 'POST', body: { email: 'Real.User@Example.com ' } });
    assert.equal(req.status, 202);
    assert.doesNotMatch(JSON.stringify(await req.json()), /token/i, 'the token is never echoed back');

    const m = /\/api\/auth\/callback\?token=([A-Za-z0-9_-]+)/.exec(s.stdout());
    assert.ok(m, 'the sign-in link was "sent"');
    const token = m[1];

    const cb = await s.call(`/api/auth/callback?token=${token}`);
    assert.equal(cb.status, 200);
    const cookie = cb.headers.get('set-cookie');
    assert.match(cookie, /snip_session=/);
    assert.match(cookie, /HttpOnly/);
    assert.match(cookie, /SameSite=Lax/);

    const jar = cookie.split(';')[0];
    const created = await s.api('/api/links', {
      method: 'POST', body: { url: 'https://example.com/session' }, headers: { cookie: jar },
    });
    assert.equal(created.status, 201, 'the session cookie is a real sign-in');

    const list = await (await s.api('/api/links', { headers: { cookie: jar } })).json();
    assert.equal(list.length, 1);

    // Single use: the same token cannot mint a second session.
    assert.equal((await s.call(`/api/auth/callback?token=${token}`)).status, 400);
    assert.equal((await s.call('/api/auth/callback?token=made-up')).status, 400);
    assert.equal((await s.api('/api/auth/request', { method: 'POST', body: { email: 'nope' } })).status, 400);
  } finally { await s.stop(); s.cleanup(); }
});

test('a session only ever sees its own links', async () => {
  const s = await startServer({ APP_ENV: 'test' });
  try {
    await s.api('/api/links', { method: 'POST', user: 'a@example.com', body: { url: 'https://a.example' } });
    await s.api('/api/links', { method: 'POST', user: 'b@example.com', body: { url: 'https://b.example' } });
    const a = await (await s.api('/api/links', { user: 'a@example.com' })).json();
    const b = await (await s.api('/api/links', { user: 'b@example.com' })).json();
    assert.equal(a.length, 1);
    assert.equal(b.length, 1);
    assert.notEqual(a[0].code, b[0].code);
  } finally { await s.stop(); s.cleanup(); }
});
