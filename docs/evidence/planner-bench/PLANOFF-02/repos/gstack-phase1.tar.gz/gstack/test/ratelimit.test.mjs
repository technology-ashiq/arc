import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

let s;
before(async () => { s = await startServer(); });
after(async () => { await s.stop(); s.cleanup(); });
beforeEach(async () => { await s.api('/api/test/reset', { method: 'POST' }); });

const create = (user = 'rl@example.com') =>
  s.api('/api/links', { method: 'POST', user, body: { url: 'https://example.com/rl' } });

test('creating links is capped at 10 per minute per IP', async () => {
  for (let i = 0; i < 10; i++) {
    assert.equal((await create()).status, 201, `create #${i + 1} should succeed`);
  }
  const res = await create();
  assert.equal(res.status, 429);
});

test('over the limit, the caller is told how long to wait', async () => {
  for (let i = 0; i < 10; i++) await create();
  const res = await create();
  assert.equal(res.status, 429);

  const header = Number(res.headers.get('retry-after'));
  assert.ok(Number.isInteger(header) && header >= 1 && header <= 60, `Retry-After: ${header}`);

  const body = await res.json();
  assert.equal(body.error.code, 'RATE_LIMITED');
  assert.ok(body.error.retryAfterSeconds >= 1 && body.error.retryAfterSeconds <= 60);
  assert.match(body.error.message, /try again in \d+ second/i);
});

test('the limit is per IP, not per user -- a second account does not reset it', async () => {
  for (let i = 0; i < 10; i++) await create('one@example.com');
  const res = await create('two@example.com');
  assert.equal(res.status, 429, 'same IP, different user: still limited');
});

test('the limit does not block reads, redirects or deletes', async () => {
  const { code } = await (await create()).json();
  for (let i = 0; i < 9; i++) await create();
  assert.equal((await create()).status, 429, 'creation is now blocked');

  assert.equal((await s.api('/api/links', { user: 'rl@example.com' })).status, 200);
  assert.equal((await s.call(`/${code}`)).status, 302);
  assert.equal((await s.api(`/api/links/${code}`, { method: 'DELETE', user: 'rl@example.com' })).status, 204);
});

test('X-Forwarded-For cannot be spoofed to bypass the limit (TRUST_PROXY off)', async () => {
  for (let i = 0; i < 10; i++) await create();
  const res = await s.api('/api/links', {
    method: 'POST',
    user: 'rl@example.com',
    body: { url: 'https://example.com/spoof' },
    headers: { 'X-Forwarded-For': '9.9.9.9' },
  });
  assert.equal(res.status, 429, 'a forged XFF must not mint a fresh budget');
});

test('POST /api/test/reset wipes links AND rate-limit state', async () => {
  for (let i = 0; i < 10; i++) await create();
  assert.equal((await create()).status, 429);

  assert.equal((await s.api('/api/test/reset', { method: 'POST' })).status, 204);

  assert.equal((await create()).status, 201, 'rate limit was reset');
  const links = await (await s.api('/api/links', { user: 'rl@example.com' })).json();
  assert.equal(links.length, 1, 'links were wiped');
});
