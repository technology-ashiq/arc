# SPEC — snip (URL shortener)

## Problem
A signed-in user creates short links from long URLs. Anyone visiting a short link is
redirected and the visit is counted. The owner sees their own links with hit counts and
can delete them.

## In scope
- **Auth**: email magic link (real path in dev/prod). Token is issued, emailed, and
  exchanged for a session cookie. A user only ever sees their own links.
- **Test auth shim**: when `APP_ENV=test`, header `X-Test-User: <email>` authenticates as
  that email and no email is sent. When `APP_ENV` is anything else the header is ignored
  completely (not merely "lower priority" — never read).
- **Create link**: `POST /api/links` `{url, alias?, expiresAt?}` -> `201 {code, shortUrl}`.
- **List own links**: `GET /api/links` -> `200 [{code, url, hits, expiresAt}]`.
- **Delete link**: `DELETE /api/links/:code` -> `204`. Idempotent-ish: the code is
  thereafter *gone*, not *unknown*.
- **Redirect**: `GET /:code` -> `302` Location: long URL; hit counted (atomically).
- **Expiry**: `expiresAt` in the past => no redirect (`410 Gone`).
- **Uniqueness**: codes and aliases live in ONE namespace. No two links share a code.
- **Rate limit**: link *creation* limited to 10/min/IP. Over limit -> `429` + how long to
  wait (`Retry-After` header + `retryAfterSeconds` in body).
- **Persistence**: SQLite (`node:sqlite`) file at `./data/snip.db`. Survives restart.
- **Test reset**: `POST /api/test/reset` -> `204`, test mode only; wipes links +
  rate-limit state. `404` outside test mode (the route does not exist there).

## Out of scope (explicitly)
- Web UI / HTML dashboard (API is the product surface here). A minimal static page is NOT built.
- Password auth, OAuth, teams/orgs, link editing, per-link analytics beyond a hit counter,
  QR codes, custom domains, paid tiers.
- Real SMTP delivery: dev/prod use a pluggable mailer; the default logs the link. A real
  provider is one interface implementation away and is never touched by tests.

## Status codes — the true one, not the convenient one
| Case | Status |
|---|---|
| created | 201 |
| bad/missing url, bad alias, bad/past expiresAt | 400 |
| not signed in | 401 |
| deleting someone else's link | 404 (do not leak existence to a non-owner) |
| unknown code on redirect | 404 |
| **deleted** code on redirect | **410 Gone** |
| **expired** code on redirect | **410 Gone** |
| alias/code already taken (incl. taken by a deleted link) | 409 |
| rate limited | 429 + Retry-After |

## Done means
- `PORT=3204 APP_ENV=test node server.mjs` starts the app.
- `npm test` is green with **no network access**.
- `README.md` gives the one-command start.
