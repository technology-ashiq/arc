import http from 'node:http';
import { openDb } from './src/db.mjs';
import { makeMailer } from './src/mailer.mjs';
import { HttpError, sendJson, sendError, readJsonBody, clientIp, baseUrl, safeDecode } from './src/http.mjs';
import {
  authenticate, normalizeEmail, issueMagicToken, consumeMagicToken, sessionCookie,
} from './src/auth.mjs';
import { createLink, listLinks, deleteLink, resolveAndCount } from './src/links.mjs';
import { enforceCreateLimit, enforceAuthLimit, resetRateLimits } from './src/ratelimit.mjs';

// Read ONCE, at boot. Everything test-only hangs off this single constant, so a stray
// X-Test-User header in production has nothing to switch on.
const APP_ENV = process.env.APP_ENV || 'dev';
const TEST_MODE = APP_ENV === 'test';
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const SECURE_COOKIES = APP_ENV === 'prod' || APP_ENV === 'production';

export function createApp({ db = openDb(), mailer = makeMailer(APP_ENV) } = {}) {
  const html = (res, status, body) => {
    res.writeHead(status, { 'content-type': 'text/html; charset=utf-8' });
    res.end(body);
  };

  return async function handler(req, res) {
    let url;
    try {
      url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    } catch {
      return sendError(res, new HttpError(400, 'BAD_REQUEST', 'Malformed request URL.'));
    }
    const path = url.pathname;
    const method = req.method || 'GET';
    res.setHeader('x-content-type-options', 'nosniff');

    try {
      if (path === '/health') return sendJson(res, 200, { ok: true, env: APP_ENV });

      // --- auth: the real path in dev/prod -------------------------------------------------
      if (path === '/api/auth/request' && method === 'POST') {
        const body = await readJsonBody(req);
        const email = normalizeEmail(body.email);
        if (!email) throw new HttpError(400, 'INVALID_EMAIL', 'A valid email address is required.');
        enforceAuthLimit(db, clientIp(req, TRUST_PROXY));
        const token = issueMagicToken(db, email);
        const link = `${baseUrl(req)}/api/auth/callback?token=${encodeURIComponent(token)}`;
        await mailer.send({
          to: email,
          subject: 'Your snip sign-in link',
          text: `Click to sign in (valid for 15 minutes):\n${link}\n`,
        });
        // Never echo the token: the response is identical whether or not the account exists.
        return sendJson(res, 202, { message: 'Check your email for a sign-in link.' });
      }

      if (path === '/api/auth/callback' && method === 'GET') {
        const session = consumeMagicToken(db, url.searchParams.get('token'));
        res.setHeader('set-cookie', sessionCookie(session.id, { secure: SECURE_COOKIES }));
        return sendJson(res, 200, { message: 'Signed in.' });
      }

      // --- test-only --------------------------------------------------------------------
      // Not registered at all outside test mode: it falls through to the /:code redirect,
      // which answers 404. There is no reset switch to find in production.
      if (TEST_MODE && path === '/api/test/reset' && method === 'POST') {
        db.exec('DELETE FROM links;');
        resetRateLimits(db);
        res.writeHead(204);
        return res.end();
      }

      // --- links ------------------------------------------------------------------------
      if (path === '/api/links' && method === 'POST') {
        const user = authenticate(db, req, { testMode: TEST_MODE });
        const body = await readJsonBody(req);
        // Limit after auth: an anonymous flood must not burn a real user's budget.
        enforceCreateLimit(db, clientIp(req, TRUST_PROXY));
        const link = createLink(db, {
          userId: user.id, url: body.url, alias: body.alias, expiresAt: body.expiresAt,
        });
        return sendJson(res, 201, { code: link.code, shortUrl: `${baseUrl(req)}/${link.code}` });
      }

      if (path === '/api/links' && method === 'GET') {
        const user = authenticate(db, req, { testMode: TEST_MODE });
        return sendJson(res, 200, listLinks(db, user.id));
      }

      const del = path.match(/^\/api\/links\/([^/]+)$/);
      if (del && method === 'DELETE') {
        const user = authenticate(db, req, { testMode: TEST_MODE });
        const code = safeDecode(del[1]);
        // "%zz" is not a code anyone can hold, so it is a 404 -- never a 500.
        if (code === null) throw new HttpError(404, 'NOT_FOUND', 'No such link.');
        deleteLink(db, user.id, code);
        res.writeHead(204);
        return res.end();
      }

      if (path === '/api/links' || del) {
        throw new HttpError(405, 'METHOD_NOT_ALLOWED', `${method} is not allowed here.`);
      }
      if (path.startsWith('/api/')) {
        throw new HttpError(404, 'NOT_FOUND', 'No such endpoint.');
      }

      // --- redirect ---------------------------------------------------------------------
      const redirect = path.match(/^\/([^/]+)\/?$/);
      if (redirect && (method === 'GET' || method === 'HEAD')) {
        const code = safeDecode(redirect[1]);
        if (code === null) {
          return sendJson(res, 404, { error: { code: 'NOT_FOUND', message: 'No link exists for this code.' } });
        }
        const result = resolveAndCount(db, code);
        if (result.status === 'ok') {
          res.writeHead(302, { location: result.url, 'cache-control': 'no-store' });
          return res.end();
        }
        // 410 vs 404 is the whole point of requirement 5: a deleted link is GONE, not unknown.
        if (result.status === 'deleted') {
          return sendJson(res, 410, {
            error: { code: 'LINK_DELETED', message: 'This link was deleted and is no longer available.' },
          });
        }
        if (result.status === 'expired') {
          return sendJson(res, 410, {
            error: { code: 'LINK_EXPIRED', message: 'This link has expired and is no longer available.' },
          });
        }
        return sendJson(res, 404, {
          error: { code: 'NOT_FOUND', message: 'No link exists for this code.' },
        });
      }

      if (path === '/' && method === 'GET') {
        return html(res, 200, '<!doctype html><meta charset="utf-8"><title>snip</title>'
          + '<h1>snip</h1><p>A URL shortener. See <code>README.md</code> for the API.</p>');
      }

      throw new HttpError(404, 'NOT_FOUND', 'Not found.');
    } catch (err) {
      return sendError(res, err);
    }
  };
}

export function startServer({ port = process.env.PORT || 3204, db, mailer } = {}) {
  const server = http.createServer(createApp({ db, mailer }));
  return new Promise((resolve) => {
    server.listen(Number(port), () => resolve(server));
  });
}

// Only auto-start when run directly, so tests can import without booting a second listener.
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.PORT || 3204);
  startServer({ port }).then((server) => {
    const bound = server.address().port;   // PORT=0 => ephemeral; tests read this line
    console.log(`[snip] listening on http://localhost:${bound} (APP_ENV=${APP_ENV})`);
    if (TEST_MODE) console.log('[snip] TEST MODE: X-Test-User header is honoured; no email is sent.');
  });
}
