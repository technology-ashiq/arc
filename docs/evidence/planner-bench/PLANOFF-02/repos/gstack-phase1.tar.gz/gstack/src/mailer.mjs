// Mailer is an interface with two impls. The test path NEVER touches a live provider:
// APP_ENV=test authenticates via the X-Test-User shim and no mail is ever sent.
// A real provider (Postmark/SES/...) is a third impl of send() and changes nothing else.

export class ConsoleMailer {
  async send({ to, subject, text }) {
    console.log(`[snip:mail] to=${to} subject=${subject}\n${text}`);
    return { delivered: true, transport: 'console' };
  }
}

/** Used by tests and by APP_ENV=test boots: captures mail in memory, sends nothing. */
export class MemoryMailer {
  constructor() { this.outbox = []; }
  async send(msg) {
    this.outbox.push(msg);
    return { delivered: true, transport: 'memory' };
  }
}

export function makeMailer(env = process.env.APP_ENV) {
  return env === 'test' ? new MemoryMailer() : new ConsoleMailer();
}
