import { randomInt } from 'node:crypto';
import { HttpError } from './http.mjs';

const ALPHABET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const CODE_LEN = 7;
const ALIAS_RE = /^[A-Za-z0-9_-]{3,32}$/;

// Paths the router owns. An alias may never claim one, or it would shadow the app itself.
export const RESERVED = new Set(['api', 'health', 'favicon.ico', 'robots.txt', 'sitemap.xml', '_']);

function randomCode() {
  let out = '';
  for (let i = 0; i < CODE_LEN; i++) out += ALPHABET[randomInt(ALPHABET.length)];
  return out;
}

/**
 * A URL shortener that accepts `javascript:` or `data:` is a stored-XSS dispenser.
 * Allow exactly the two schemes a browser should ever be redirected to.
 */
export function validateUrl(raw) {
  if (typeof raw !== 'string' || !raw.trim()) {
    throw new HttpError(400, 'INVALID_URL', 'url is required.');
  }
  const value = raw.trim();
  if (value.length > 2048) throw new HttpError(400, 'INVALID_URL', 'url must be at most 2048 characters.');
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    throw new HttpError(400, 'INVALID_URL', 'url must be an absolute http(s) URL.');
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new HttpError(400, 'INVALID_URL', 'url must use the http or https scheme.');
  }
  if (!parsed.hostname) throw new HttpError(400, 'INVALID_URL', 'url must have a host.');
  return parsed.toString();
}

export function validateAlias(raw) {
  if (raw === undefined || raw === null || raw === '') return null;
  if (typeof raw !== 'string' || !ALIAS_RE.test(raw)) {
    throw new HttpError(400, 'INVALID_ALIAS',
      'alias must be 3-32 characters of letters, numbers, hyphen or underscore.');
  }
  if (RESERVED.has(raw.toLowerCase())) {
    throw new HttpError(400, 'RESERVED_ALIAS', `The alias "${raw}" is reserved.`);
  }
  return raw;
}

export function validateExpiry(raw, now = Date.now()) {
  if (raw === undefined || raw === null || raw === '') return null;
  if (typeof raw !== 'string') {
    throw new HttpError(400, 'INVALID_EXPIRY', 'expiresAt must be an ISO-8601 date string.');
  }
  const ms = Date.parse(raw);
  if (Number.isNaN(ms)) {
    throw new HttpError(400, 'INVALID_EXPIRY', 'expiresAt must be a valid ISO-8601 date string.');
  }
  if (ms <= now) {
    throw new HttpError(400, 'EXPIRY_IN_PAST', 'expiresAt must be in the future.');
  }
  return ms;
}

const isTaken = (err) => String(err?.message || '').includes('UNIQUE constraint failed');

export function createLink(db, { userId, url, alias, expiresAt }, now = Date.now()) {
  const safeUrl = validateUrl(url);
  const safeAlias = validateAlias(alias);
  const expiry = validateExpiry(expiresAt, now);

  const insert = db.prepare(
    `INSERT INTO links (code, url, user_id, hits, expires_at, deleted_at, created_at)
     VALUES (?, ?, ?, 0, ?, NULL, ?)`);

  if (safeAlias) {
    try {
      insert.run(safeAlias, safeUrl, userId, expiry, now);
    } catch (err) {
      // Taken by anyone's link -- INCLUDING a soft-deleted one. A deleted code is gone, not free.
      if (isTaken(err)) {
        throw new HttpError(409, 'ALIAS_TAKEN', `The alias "${safeAlias}" is already taken.`);
      }
      throw err;
    }
    return { code: safeAlias, url: safeUrl, expiresAt: expiry };
  }

  for (let attempt = 0; attempt < 6; attempt++) {
    const code = randomCode();
    try {
      insert.run(code, safeUrl, userId, expiry, now);
      return { code, url: safeUrl, expiresAt: expiry };
    } catch (err) {
      if (isTaken(err)) continue;   // astronomically rare; just draw again
      throw err;
    }
  }
  throw new HttpError(503, 'CODE_EXHAUSTED', 'Could not allocate a short code. Please retry.');
}

/** A user's own links only. The WHERE clause is the access control -- not a hopeful `if`. */
export function listLinks(db, userId) {
  return db.prepare(
    `SELECT code, url, hits, expires_at FROM links
      WHERE user_id = ? AND deleted_at IS NULL
      ORDER BY created_at DESC`).all(userId).map((r) => ({
    code: r.code,
    url: r.url,
    hits: r.hits,
    expiresAt: r.expires_at === null ? null : new Date(r.expires_at).toISOString(),
  }));
}

/**
 * Soft delete. The row stays, so (a) the code can never be re-registered by someone else and
 * (b) the redirect can honestly answer 410 Gone rather than 404 Not Found.
 * Someone else's link answers 404, not 403 -- a 403 would confirm the code exists to a stranger.
 */
export function deleteLink(db, userId, code, now = Date.now()) {
  const info = db.prepare(
    'UPDATE links SET deleted_at = ? WHERE code = ? AND user_id = ? AND deleted_at IS NULL')
    .run(now, code, userId);
  if (info.changes > 0) return { deleted: true };

  const mine = db.prepare('SELECT deleted_at FROM links WHERE code = ? AND user_id = ?').get(code, userId);
  if (mine) return { deleted: false, alreadyDeleted: true };   // idempotent: still 204
  throw new HttpError(404, 'NOT_FOUND', 'No such link.');
}

/**
 * Resolve + count in ONE statement. A SELECT-then-UPDATE would drop hits under concurrency,
 * and hit counts are the entire point of the dashboard.
 */
export function resolveAndCount(db, code, now = Date.now()) {
  const hit = db.prepare(
    `UPDATE links SET hits = hits + 1
      WHERE code = ? AND deleted_at IS NULL AND (expires_at IS NULL OR expires_at > ?)
      RETURNING url`).get(code, now);
  if (hit) return { status: 'ok', url: hit.url };

  const row = db.prepare('SELECT deleted_at, expires_at FROM links WHERE code = ?').get(code);
  if (!row) return { status: 'unknown' };
  if (row.deleted_at !== null) return { status: 'deleted' };
  return { status: 'expired' };
}
