import { HttpError } from './http.mjs';

export const WINDOW_MS = 60_000;
export const MAX_CREATES = 10;   // 10 link creations per minute per IP (the specified limit)
export const MAX_AUTH = 5;       // 5 magic-link requests per minute per IP (anti email-bombing)

/**
 * Sliding-window limiter, SQLite-backed so /api/test/reset can wipe it and so it survives a
 * restart (an in-memory counter would hand an attacker a fresh budget on every deploy).
 * Call this only on the path being limited (link creation), and only AFTER auth, so an
 * anonymous flood can't burn a real user's budget.
 */
export function enforceCreateLimit(db, ip, now = Date.now()) {
  return enforceLimit(db, `create:${ip}`, MAX_CREATES, now, 'Too many links created');
}

/**
 * Magic-link requests are also limited, keyed separately so they can never eat into the
 * 10/min link-creation budget. Without this, anyone can use us to bomb a stranger's inbox
 * and flood magic_tokens -- the limiter exists for creation, but the abuse case is wider.
 */
export function enforceAuthLimit(db, ip, now = Date.now()) {
  return enforceLimit(db, `auth:${ip}`, MAX_AUTH, now, 'Too many sign-in requests');
}

function enforceLimit(db, key, max, now, what) {
  const since = now - WINDOW_MS;
  db.prepare('DELETE FROM rate_events WHERE created_at <= ?').run(since);

  const rows = db.prepare(
    'SELECT created_at FROM rate_events WHERE ip = ? AND created_at > ? ORDER BY created_at ASC'
  ).all(key, since);

  if (rows.length >= max) {
    // The oldest event in the window is the one that has to age out before a slot frees up.
    const oldest = rows[0].created_at;
    const retryAfterSeconds = Math.max(1, Math.ceil((oldest + WINDOW_MS - now) / 1000));
    throw new HttpError(
      429,
      'RATE_LIMITED',
      `${what}. Try again in ${retryAfterSeconds} second${retryAfterSeconds === 1 ? '' : 's'}.`,
      { retryAfterSeconds, limit: max, windowSeconds: WINDOW_MS / 1000 },
    );
  }

  db.prepare('INSERT INTO rate_events (ip, created_at) VALUES (?, ?)').run(key, now);
  return { remaining: max - rows.length - 1 };
}

export function resetRateLimits(db) {
  db.prepare('DELETE FROM rate_events').run();
}
