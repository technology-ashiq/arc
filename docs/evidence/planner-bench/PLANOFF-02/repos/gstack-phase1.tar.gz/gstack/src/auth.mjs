import { randomUUID, randomBytes, createHash } from 'node:crypto';
import { HttpError, parseCookies } from './http.mjs';

const TOKEN_TTL_MS = 15 * 60 * 1000;        // magic link: short-lived on purpose
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;
export const SESSION_COOKIE = 'snip_session';

const sha256 = (s) => createHash('sha256').update(s).digest('hex');

// Deliberately permissive but real: exactly one @, no spaces, a dot in the domain.
const EMAIL_RE = /^[^\s@]+@[^\s@.]+\.[^\s@]+$/;

export function normalizeEmail(raw) {
  if (typeof raw !== 'string') return null;
  const email = raw.trim().toLowerCase();
  if (email.length < 3 || email.length > 254 || !EMAIL_RE.test(email)) return null;
  return email;
}

export function upsertUser(db, email) {
  const existing = db.prepare('SELECT id, email FROM users WHERE email = ?').get(email);
  if (existing) return existing;
  const user = { id: randomUUID(), email };
  db.prepare('INSERT INTO users (id, email, created_at) VALUES (?, ?, ?)')
    .run(user.id, user.email, Date.now());
  return user;
}

/** Issue a magic-link token. Only the SHA-256 is persisted: a DB leak is not account takeover. */
export function issueMagicToken(db, email, now = Date.now()) {
  const token = randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO magic_tokens (token_hash, email, expires_at, used_at) VALUES (?, ?, ?, NULL)')
    .run(sha256(token), email, now + TOKEN_TTL_MS);
  return token;
}

/** Consume a magic-link token: single-use, TTL-checked, then a session is born. */
export function consumeMagicToken(db, token, now = Date.now()) {
  if (typeof token !== 'string' || !token) {
    throw new HttpError(400, 'INVALID_TOKEN', 'Missing sign-in token.');
  }
  const row = db.prepare('SELECT token_hash, email, expires_at, used_at FROM magic_tokens WHERE token_hash = ?')
    .get(sha256(token));
  if (!row || row.used_at !== null || row.expires_at <= now) {
    throw new HttpError(400, 'INVALID_TOKEN', 'This sign-in link is invalid or has expired.');
  }
  db.prepare('UPDATE magic_tokens SET used_at = ? WHERE token_hash = ?').run(now, row.token_hash);
  const user = upsertUser(db, row.email);
  return createSession(db, user.id, now);
}

export function createSession(db, userId, now = Date.now()) {
  const id = randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)')
    .run(id, userId, now + SESSION_TTL_MS);
  return { id, userId, expiresAt: now + SESSION_TTL_MS };
}

export function sessionCookie(sessionId, { secure }) {
  const bits = [
    `${SESSION_COOKIE}=${sessionId}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}`,
  ];
  if (secure) bits.push('Secure');
  return bits.join('; ');
}

/**
 * The ONLY place a request becomes a user.
 *
 * `testMode` is read once at boot from APP_ENV. When it is false the X-Test-User header is
 * never read -- the branch that touches it does not execute -- so in dev/prod the header is
 * inert no matter who sends it. Magic-link sessions remain the real path in every mode.
 */
export function authenticate(db, req, { testMode, now = Date.now() }) {
  if (testMode) {
    const header = req.headers['x-test-user'];
    if (typeof header === 'string' && header.trim()) {
      const email = normalizeEmail(header);
      if (!email) throw new HttpError(400, 'INVALID_TEST_USER', 'X-Test-User must be a valid email address.');
      return upsertUser(db, email);
    }
  }

  const sid = parseCookies(req.headers.cookie || '')[SESSION_COOKIE];
  if (!sid) throw new HttpError(401, 'UNAUTHENTICATED', 'Sign in to do that.');

  const row = db.prepare(
    `SELECT u.id AS id, u.email AS email, s.expires_at AS expires_at
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.id = ?`).get(sid);
  if (!row || row.expires_at <= now) {
    throw new HttpError(401, 'UNAUTHENTICATED', 'Your session has expired. Sign in again.');
  }
  return { id: row.id, email: row.email };
}
