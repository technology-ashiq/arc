export class HttpError extends Error {
  constructor(status, code, message, extra = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

export function sendJson(res, status, body, headers = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    ...headers,
  });
  res.end(payload);
}

export function sendError(res, err) {
  const e = err instanceof HttpError ? err : new HttpError(500, 'INTERNAL', 'Internal server error.');
  if (!(err instanceof HttpError)) console.error('[snip] unhandled:', err);
  const headers = {};
  if (e.status === 429 && e.extra.retryAfterSeconds != null) {
    headers['retry-after'] = String(e.extra.retryAfterSeconds);
  }
  sendJson(res, e.status, { error: { code: e.code, message: e.message, ...e.extra } }, headers);
}

const MAX_BODY = 64 * 1024;

export async function readJsonBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) throw new HttpError(413, 'BODY_TOO_LARGE', 'Request body too large.');
    chunks.push(chunk);
  }
  if (size === 0) return {};
  let parsed;
  try {
    parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'INVALID_JSON', 'Request body must be valid JSON.');
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new HttpError(400, 'INVALID_JSON', 'Request body must be a JSON object.');
  }
  return parsed;
}

/** Client IP. X-Forwarded-For is spoofable, so only trust it behind a proxy we opted into. */
export function clientIp(req, trustProxy) {
  if (trustProxy) {
    const xff = req.headers['x-forwarded-for'];
    if (typeof xff === 'string' && xff.length) {
      const first = xff.split(',')[0].trim();
      if (first) return first;
    }
  }
  return req.socket.remoteAddress || 'unknown';
}

/** decodeURIComponent throws URIError on inputs like "%zz". Never let that become a 500. */
export function safeDecode(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return null;
  }
}

export function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    if (!k) continue;
    const raw = part.slice(i + 1).trim();
    const decoded = safeDecode(raw);
    out[k] = decoded === null ? raw : decoded;   // a junk cookie is unauthenticated, not a crash
  }
  return out;
}

/** Origin for the shortUrl we hand back. Configured base wins; else the request's Host. */
export function baseUrl(req) {
  const configured = process.env.PUBLIC_BASE_URL;
  if (configured) return configured.replace(/\/+$/, '');
  const host = req.headers.host || `localhost:${process.env.PORT || 3204}`;
  const proto = process.env.TRUST_PROXY === '1' && req.headers['x-forwarded-proto']
    ? String(req.headers['x-forwarded-proto']).split(',')[0].trim()
    : 'http';
  return `${proto}://${host}`;
}
