# REVIEW — Review Army pass over the snip diff

Three specialist reviews of my own code, run after the build. Findings are numbered; every
FIXED item has a regression test in `test/hardening.test.mjs` that fails against the old code.

---

## 1. Security review

| # | Finding | Severity | Status |
|---|---|---|---|
| SEC-01 | `decodeURIComponent()` on a path segment throws `URIError` for input like `/%zz`. The throw escaped to the generic handler and became a **500 with a stack trace in the logs** — a cheap, unauthenticated way to spray errors into a production log pipeline. | Medium | **FIXED** — `safeDecode()` returns `null`; an undecodable code is a `404`, because no user can hold that code. |
| SEC-02 | Same `URIError` via the **cookie** parser: `Cookie: snip_session=%zz` 500'd instead of answering "not signed in". | Medium | **FIXED** — a junk cookie is treated as absent → `401`. |
| SEC-03 | `POST /api/auth/request` was **unbounded**. Anyone could point snip at a stranger's address and bomb their inbox, and flood `magic_tokens` while doing it. The brief only mandates a limit on *creation*, but the abuse case does not stop at the brief. | High | **FIXED** — 5/min/IP on sign-in requests, keyed `auth:<ip>` so it is a **separate budget** from the mandated 10/min creation budget (verified by test). |
| SEC-04 | `javascript:` / `data:` / `file:` URLs would turn snip into a stored-XSS dispenser — the classic shortener abuse. | High | **Already handled** — scheme allowlist (`http:`/`https:` only) in `validateUrl`, tested. |
| SEC-05 | `X-Test-User` reaching prod = total auth bypass. | Critical | **Already handled** — `TEST_MODE` is `APP_ENV === 'test'`, read **once at boot**; the header is only read inside that branch, and `/api/test/reset` is not registered at all otherwise. Tested against a real `APP_ENV=prod` boot. |
| SEC-06 | `X-Forwarded-For` spoofing to mint a fresh rate-limit budget. | High | **Already handled** — XFF is only trusted when `TRUST_PROXY=1`; default is the socket peer. Tested with a forged header. |
| SEC-07 | IDOR: deleting someone else's link. Also, answering `403` would *confirm* the code exists to a stranger. | High | **Already handled** — the `UPDATE` is scoped by `user_id`; a stranger's link answers `404`. Tested. |
| SEC-08 | Magic tokens readable in a DB dump = account takeover. | High | **Already handled** — SHA-256 at rest, single-use (`used_at`), 15-min TTL. The token is never echoed in a response body. |
| SEC-09 | Response sniffing / reserved-path shadowing (`alias: "api"`). | Low | **FIXED / handled** — `nosniff` header added; RESERVED alias set enforced. |
| SEC-10 | **Open redirect.** `GET /:code` sends users to an arbitrary attacker-chosen host. | — | **ACCEPTED, BY DESIGN.** This is what a URL shortener *is*. Documented in the README so nobody "fixes" it later; a real deployment should add a malware/phishing blocklist at creation time. |

## 2. Correctness / edge-case review

| # | Finding | Status |
|---|---|---|
| COR-01 | Malformed percent-encoding in `/:code` and `DELETE /api/links/:code` → 500. | **FIXED** (see SEC-01). |
| COR-02 | `HEAD /:code` returned `404` while `GET /:code` returned `302` — incoherent to every link-checker and preview bot on the internet. | **FIXED** — `HEAD` resolves exactly like `GET`. |
| COR-03 | **Hit counting under concurrency.** A `SELECT`-then-`UPDATE` silently drops hits when two people click at once — and hit counts are the entire point of the dashboard. | **Correct by construction** — one `UPDATE ... RETURNING url` statement does resolve + count together. Proven with 25 concurrent visits asserting exactly 25 hits. |
| COR-04 | Expiry boundary: is a link dead *at* `expiresAt`? | **Defined** — `expires_at > now` to redirect, so the link is dead at the instant it expires. Creating an already-past `expiresAt` is a `400`, not a silently-dead link. |
| COR-05 | `410` vs `404`: deleted must not collapse into unknown. | **Correct** — `LINK_DELETED` / `LINK_EXPIRED` are `410`; only a genuinely unknown code is `404`. Tested. |
| COR-06 | Deleting twice. | **Idempotent** — the second `DELETE` is still `204` (the caller's intent is satisfied), while a *stranger's* code is `404`. |
| COR-07 | An expired link still appears on the owner's dashboard. | **Intended** — the owner must be able to see *why* their link stopped working. It carries its `expiresAt`; it just doesn't redirect. |
| COR-08 | Failed creates (400/409) consume a rate-limit slot. | **Intended** — otherwise the limit is trivially bypassed by alternating junk and real requests. |
| COR-09 | Junk JSON / arrays as bodies / wrong methods. | **FIXED/tested** — `400` and `405`, never `500`. |

## 3. Data-model, migration & persistence review

| # | Finding | Status |
|---|---|---|
| DAT-01 | **Hard-deleting a link would free its code for re-registration** — a stranger could re-mint someone's retired link and take over its traffic. It also makes "gone, not unknown" *unrepresentable*. | **Correct by construction** — delete is a soft delete (`deleted_at`); the row stays, the code stays reserved forever. Tested across a restart: re-registering a deleted alias is `409`. |
| DAT-02 | Codes and aliases in two columns/tables would eventually collide. | **Correct by construction** — ONE column, `links.code`, is the PRIMARY KEY. A collision is not a bug we must avoid; it is a state the schema cannot represent. |
| DAT-03 | Timestamps stored as ISO strings compare correctly only until someone writes a `+05:30` offset. | **Correct** — epoch-ms `INTEGER` in the DB; ISO-8601 only at the API edge, and it round-trips (tested). |
| DAT-04 | **No schema version** — the next person changing the schema has nothing to branch on. | **FIXED** — `PRAGMA user_version = 1` set at open, with a comment marking the migration hook. |
| DAT-05 | Rate-limit state in memory would (a) be lost on deploy, handing attackers a fresh budget, and (b) be unwipeable by `/api/test/reset`. | **Correct by construction** — `rate_events` is a table. Old rows are pruned on every check, so it does not grow. |
| DAT-06 | Durability on a hard crash. | **Proven, not assumed** — `test/persistence.test.mjs` **SIGKILLs** the process and restarts it against the same file: the link still redirects, hits persisted, the deleted link is still `410`, the alias is still taken. |
| DAT-07 | Tests could clobber a developer's real `./data/snip.db`. | **FIXED** — `DB_PATH` env; the harness gives every run a temp file. The mandated start command still uses `./data/snip.db` exactly. |
| DAT-08 | No graceful shutdown / `db.close()` on SIGTERM. | **ACCEPTED** — WAL + synchronous commits mean a hard kill loses nothing already acknowledged (DAT-06 proves it). A half-built shutdown path would be worse than none. |
| DAT-09 | `DB_PATH` default `./data/snip.db` is resolved against the **CWD**, so starting the app from a different directory opens a different database. | **ACCEPTED + documented** — that is what `./` means, and it is what the brief specifies. Noted in the README. |

## Verdict
9 findings fixed, 3 accepted with a written reason. All 35 tests green, no network in the test path.
