# PLAN — snip

## 1. Architecture
Single Node 22 process, ESM, `node:http` + a tiny hand-rolled router (no framework needed for
6 routes; zero deps in the request path = nothing to CVE-patch).

```
server.mjs          boot: env, db init, listen(process.env.PORT)
src/db.mjs          node:sqlite DatabaseSync, schema + migrations, WAL
src/auth.mjs        magic-link issue/consume, sessions, the test shim
src/mailer.mjs      Mailer interface + ConsoleMailer (default) + MemoryMailer (tests)
src/links.mjs       create / list / delete / resolve+count  (all SQL, no read-modify-write)
src/ratelimit.mjs   10/min/IP sliding window, SQLite-backed so /reset can wipe it
src/http.mjs        router, JSON body parse, error envelope
test/*.test.mjs     node:test, spawns the real server on an ephemeral port
```

## 2. Data model (one namespace for codes, soft delete)
```sql
users(id TEXT PK, email TEXT UNIQUE NOT NULL, created_at INTEGER)
sessions(id TEXT PK, user_id TEXT NOT NULL REFERENCES users, expires_at INTEGER)
magic_tokens(token_hash TEXT PK, email TEXT, expires_at INTEGER, used_at INTEGER NULL)
links(
  code       TEXT PRIMARY KEY,       -- generated code AND custom alias share this column.
  url        TEXT NOT NULL,          -- One namespace => two links can never collide. Period.
  user_id    TEXT NOT NULL REFERENCES users,
  hits       INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER NULL,           -- epoch ms
  deleted_at INTEGER NULL,           -- soft delete: the row STAYS, so the code stays taken
  created_at INTEGER NOT NULL
)
rate_events(ip TEXT, created_at INTEGER)   -- durable, wipeable by /api/test/reset
```
**Delete is soft.** A hard delete would (a) free the code for re-registration and (b) make it
impossible to say "gone" rather than "unknown". Deleted code => `410 Gone`. Unknown code => `404`.

## 3. Key flows
- **Redirect+count is one statement**, not read-then-write:
  `UPDATE links SET hits=hits+1 WHERE code=? AND deleted_at IS NULL AND (expires_at IS NULL OR expires_at>?) RETURNING url`
  No row back => second query decides 404 (unknown) vs 410 (deleted or expired).
- **Auth**: `POST /api/auth/request {email}` -> mailer sends `/api/auth/callback?token=`.
  Token stored as SHA-256, 15-min TTL, single-use. Callback sets `snip_session` cookie.
- **Test shim**: `const TEST_MODE = process.env.APP_ENV === 'test'` is read ONCE at boot.
  `X-Test-User` is only ever *read* inside `if (TEST_MODE)`. Outside test mode the header
  name does not appear in any executed code path, and `/api/test/reset` returns 404.
- **Rate limit**: sliding 60s window on `POST /api/links` keyed by IP. On block:
  `429`, `Retry-After: <s>` header + `{"error":{...,"retryAfterSeconds":N}}`.

## 4. Personas — review of the plan above

### CEO — is this the smallest thing that satisfies the user?
- CUT: HTML dashboard, QR codes, link editing, click analytics beyond `hits`, custom domains,
  teams. The user asked for an API contract and a dashboard *view of their links* — `GET /api/links`
  IS that view. Building React for this would be scope creep with no requirement behind it.
- CUT: a real SMTP integration. Requirement 7 forbids the test path touching a live provider, and
  nothing asks us to actually deliver mail. A `Mailer` interface + console impl is honest and is
  the whole of the work; swapping in Postmark later is 20 lines and zero refactor.
- KEEP: zero npm runtime deps. Fewer moving parts to explain, install, and break.
- CHALLENGE ACCEPTED: "do we even need a users table?" — yes, `user_id` FK is what makes
  "a user only ever sees their own links" enforceable in SQL rather than in a hopeful `if`.

### Engineer — what breaks in production? data-model risk?
- **`GET /:code` will happily swallow `/api/links`.** Router must match `/api/*` first and
  keep a RESERVED set (`api`, `health`, `favicon.ico`, `robots.txt`) that aliases cannot claim.
- **Hit counting race.** Two concurrent visitors doing SELECT-then-UPDATE lose a hit. Fixed by
  the single `UPDATE ... RETURNING` above.
- **`./data/` will not exist on a fresh clone** => `mkdirSync(recursive:true)` at boot, before open.
- **node:sqlite is experimental** => it prints an ExperimentalWarning; harmless, but tests must not
  assert on clean stderr. Enable `journal_mode=WAL` + `foreign_keys=ON`.
- **Test/dev DB collision**: tests must not wipe a developer's real `./data/snip.db`. Add
  `DB_PATH` env (default exactly `./data/snip.db`, as specified); the test harness points it at
  a temp file. The mandated start command still works untouched.
- **Expiry stored as epoch ms INTEGER**, not a string — string comparison of ISO-8601 works by
  luck only until someone stores a `+05:30` offset. Serialise back to ISO-8601 at the edge.
- **Restart durability** is the whole point of req 2 => a test that kills the process, restarts it
  on the same DB file, and asserts the link still redirects. Assert it, don't assume it.

### Design/DX — is the API contract coherent to a consumer?
- One error envelope everywhere: `{"error":{"code":"ALIAS_TAKEN","message":"..."}}`. A consumer
  branches on `error.code`, never on prose.
- `410` prose must actually *say* the link was deleted — req 5 is a DX requirement, not a DB one.
  `{"code":"LINK_DELETED","message":"This link was deleted."}` vs `{"code":"NOT_FOUND"}`.
- `shortUrl` needs an origin: `PUBLIC_BASE_URL` env, else derive from the request `Host` header.
  Never hardcode localhost into a 201 response.
- `expiresAt` echoes back as ISO-8601 or `null` — same shape in the create request and the list
  response. Round-tripping the object a consumer got back must be valid input.
- `Retry-After` is the *standard* way to say "wait N seconds"; also mirror it into the JSON body
  so a fetch() consumer doesn't have to reach for headers.

### Security — what's the abuse case?
1. **`javascript:`/`data:` URLs** => a shortener that hands out stored XSS. Scheme allowlist:
   `http:`/`https:` only. This is the #1 real-world abuse of a URL shortener.
2. **`X-Test-User` reaching prod = total auth bypass.** Gate is `APP_ENV === 'test'`, read at boot.
   Belt and braces: `/api/test/reset` is not even registered outside test mode.
3. **`X-Forwarded-For` spoofing => rate-limit bypass** (attacker rotates the header, gets
   unlimited creates). Only trust XFF when `TRUST_PROXY=1`; default to the socket peer address.
4. **Magic tokens at rest**: store SHA-256, never the raw token. DB leak != account takeover.
   Single-use (`used_at`), 15-min TTL.
5. **Session cookie**: `HttpOnly; SameSite=Lax; Path=/`, `Secure` whenever not in test/dev.
6. **IDOR on `DELETE /api/links/:code`**: scope the statement by `user_id`. Someone else's live
   link must answer `404`, not `403` — `403` would confirm the code exists to a stranger.
7. **Alias squatting** of `api`/`health` => reserved list, `400`.
8. **Alias charset**: `^[A-Za-z0-9_-]{3,32}$`. Blocks `../`, `%2e`, unicode homoglyph lookalikes,
   and anything that could escape a path segment.
9. Codes are 7 chars of CSPRNG base62 (~3.5e12 space) — not a sequential integer to enumerate.
10. Open redirect is *the product*. Accepted, documented, not a bug.

## 5. Folded back into the plan (deltas from the review)
- Router: `/api/*` matched before `/:code`; RESERVED code set. *(Engineer)*
- `DB_PATH` env for test isolation; `mkdir -p ./data` at boot. *(Engineer)*
- Restart-durability test is mandatory, not optional. *(Engineer)*
- URL scheme allowlist + alias regex + reserved names. *(Security)*
- `TRUST_PROXY` gate on XFF. *(Security)*
- Hashed, single-use, TTL'd magic tokens. *(Security)*
- Error envelope with stable `error.code`; `LINK_DELETED` distinct from `NOT_FOUND`. *(Design)*
- `PUBLIC_BASE_URL` / Host-derived `shortUrl`. *(Design)*
- No UI, no SMTP, no npm runtime deps. *(CEO)*

## 6. Build order
1. db + schema  2. http/router + errors  3. auth (+shim) + mailer  4. links  5. ratelimit
6. server.mjs wiring  7. tests  8. README  9. Review Army -> REVIEW.md -> fixes
