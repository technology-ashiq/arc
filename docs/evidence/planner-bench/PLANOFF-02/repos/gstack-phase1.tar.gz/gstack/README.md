# snip — a URL shortener

Sign in with an email magic link, turn a long URL into a short one, watch the hits come in.

## Start it (one command)

```bash
PORT=3204 APP_ENV=test node server.mjs
```

No install step, no build step, no dependencies — Node 22+ only (uses the built-in `node:sqlite`).
The database is created on first boot at `./data/snip.db` and survives restarts.

```bash
npm test        # 35 tests, no network access required
```

> `APP_ENV=test` enables the test auth shim (below). For a real run use `APP_ENV=dev` or
> `APP_ENV=prod`, where sign-in goes through the magic link.

## API

| Method | Path | Behaviour |
|---|---|---|
| `POST` | `/api/links` | `{ "url": string, "alias"?: string, "expiresAt"?: ISO-8601 }` → `201 { "code", "shortUrl" }` |
| `GET` | `/api/links` | → `200 [{ "code", "url", "hits", "expiresAt" }]` — your links only |
| `DELETE` | `/api/links/:code` | → `204` |
| `GET` | `/:code` | → `302` to the long URL; the hit is counted |
| `POST` | `/api/auth/request` | `{ "email" }` → `202`, sends the magic link |
| `GET` | `/api/auth/callback?token=` | → `200` + `snip_session` cookie |
| `POST` | `/api/test/reset` | **test mode only** → `204`; wipes links + rate-limit state |

```bash
curl -X POST localhost:3204/api/links \
  -H 'X-Test-User: you@example.com' -H 'content-type: application/json' \
  -d '{"url":"https://example.com/a/very/long/path","alias":"docs"}'
# {"code":"docs","shortUrl":"http://localhost:3204/docs"}

curl -i localhost:3204/docs      # 302 -> https://example.com/a/very/long/path
```

Errors come back as `{"error":{"code":"ALIAS_TAKEN","message":"..."}}` — branch on `error.code`.

### Status codes — the true one, not the convenient one
- `400` bad URL (only `http`/`https`), bad alias, expiry in the past
- `401` not signed in · `404` unknown code, or a link that isn't yours
- **`409`** the code/alias is taken — *including by a link that was deleted*
- **`410`** the link was **deleted** (`LINK_DELETED`) or has **expired** (`LINK_EXPIRED`).
  A deleted link is **gone**, not unknown. Delete is a soft delete: the row stays, so the code
  is never handed to anyone else.
- **`429`** rate limited — **10 link creations per minute per IP**. The response tells you how
  long to wait, in the `Retry-After` header *and* in `error.retryAfterSeconds`.

## Auth

**Real path (dev/prod):** `POST /api/auth/request` → a single-use, 15-minute magic link is mailed
→ `GET /api/auth/callback?token=…` sets an `HttpOnly; SameSite=Lax` session cookie.
Tokens are stored SHA-256 hashed, so a database dump is not an account takeover.

**Test shim:** when — and only when — `APP_ENV=test`, the header `X-Test-User: <email>`
authenticates as that email and no mail is sent. `APP_ENV` is read **once at boot**: in any other
environment the header is never read at all, and `/api/test/reset` does not exist. This is what
keeps the test suite off the network: no email provider is ever called in the test path.

## Configuration

| Var | Default | Notes |
|---|---|---|
| `PORT` | `3204` | |
| `APP_ENV` | `dev` | `test` enables the shim + reset route. Nothing else does. |
| `DB_PATH` | `./data/snip.db` | Resolved against the **current working directory** — start the app from the repo root, or set this explicitly. |
| `PUBLIC_BASE_URL` | request `Host` | The origin used to build `shortUrl`. |
| `TRUST_PROXY` | off | Set to `1` **only** behind a proxy you control. It makes `X-Forwarded-For` authoritative for rate limiting, and a forged header would otherwise mint a fresh budget. |

## Design notes
- **One namespace for codes.** A generated code and a custom alias are the same primary-key
  column, so two links sharing a code is a state the schema cannot represent.
- **Resolve + count is one SQL statement** (`UPDATE … RETURNING url`), so concurrent visitors
  never lose a hit.
- **Open redirect is the product**, not a bug — snip sends users to whatever URL was shortened.
  A public deployment should add a phishing/malware blocklist at creation time.
- See `SPEC.md` (scope), `PLAN.md` (design + the four-persona review), `REVIEW.md` (the security /
  correctness / persistence review of the shipped code and what it found).
