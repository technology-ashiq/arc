# snip — PLAN

Order is forced by TDD: every task marked [TEST] must be written, run, and **seen to fail** before the
matching [CODE] task exists. Each task is one commit.

## Phase 0 — scaffolding (no product logic, so no test debt)
- [x] 0.1 `git init`, `git config` identity, DESIGN.md.
- [x] 0.2 `package.json`: `"type":"module"`, `"test": "node --test test/"`, zero dependencies.
        `.gitignore`: `data/`, `node_modules/`, `.tmp/`.
- [x] 0.3 `test/helper.mjs`: `startApp({env, seedIp})` -> boots the app on port 0 with a temp `DB_PATH`
        and a `FakeMailer`, returns `{ base, mailer, stop, dbPath }`; `req(base, method, path, {body, user, ip})`
        -> `{ status, headers, json }`, `redirect: 'manual'`. No third-party sockets anywhere.

## Phase 1 — auth (R1)
- [x] 1.1 [TEST] `test/auth.test.mjs`: (a) `POST /api/links` with no auth -> 401.
        (b) with `X-Test-User` in test mode -> 201. (c) **same header against an `APP_ENV=production`
        app -> 401** (header ignored completely). (d) `POST /api/auth/magic-link` -> 204, FakeMailer holds
        exactly 1 message containing a `/api/auth/verify?token=` URL. (e) that token -> 302 + `Set-Cookie`
        session; the cookie authenticates `GET /api/links` -> 200. (f) reusing a spent token -> 400.
- [x] 1.2 [CODE] `lib/config.mjs`, `lib/db.mjs` (schema + migrate), `lib/mailer.mjs`
        (Console/Http/Fake), `lib/auth.mjs` (HMAC cookie, token mint/consume, `resolveUser`), and enough of
        `lib/app.mjs` to serve those routes. Run test -> green.

## Phase 2 — create + redirect + hits (R2, R3, R4)
- [x] 2.1 [TEST] `test/links.test.mjs`: create -> 201 `{code, shortUrl}`; `GET /:code` -> 302 to the long
        url; two hits then `GET /api/links` shows `hits: 2`; unknown code -> 404; a hit on an unknown code
        counts nothing. Invalid url (`not-a-url`, `javascript:alert(1)`) -> 400.
- [x] 2.2 [CODE] `lib/codes.mjs` (base62, collision retry), create/list/redirect handlers.
- [x] 2.3 [TEST] alias: custom alias is honoured; duplicate alias -> 409; alias colliding with an
        auto-generated code -> 409 (one namespace); bad grammar (`ab`, `no spaces`, 33 chars) -> 400;
        reserved (`api`) -> 400.
- [x] 2.4 [CODE] alias validation + `INSERT` constraint catch (no check-then-insert).
- [x] 2.5 [TEST] expiry: link with `expiresAt` in the future redirects; once past, `GET /:code` -> 410 and
        `hits` does **not** increase; `expiresAt` in the past at create -> 400; garbage `expiresAt` -> 400.
- [x] 2.6 [CODE] expiry checks in create + redirect.
- [x] 2.7 [TEST] persistence: create a link, `stop()` the server, boot a new app on the **same `DB_PATH`**,
        `GET /:code` -> 302. Restart does not lose hits.
- [x] 2.8 [CODE] (should already pass — if it does not, the DB layer is wrong, not the test.)

## Phase 3 — ownership + delete (R5)
- [x] 3.1 [TEST] `test/ownership.test.mjs`: alice's links never appear in bob's `GET /api/links`;
        bob deleting alice's code -> 404 **and alice's link still redirects** (the 404 was not a silent delete).
- [x] 3.2 [TEST] `test/delete.test.mjs`: delete -> 204; `GET /:code` -> **410, not 404**; body says `gone`;
        an unknown code -> **404** (the two are different); the deleted link is absent from `GET /api/links`;
        the deleted code **cannot be re-registered as an alias** -> 409; re-deleting -> 204 (idempotent).
- [x] 3.3 [CODE] soft delete (`deleted_at`), ownership filters, 410-vs-404 in the redirect handler.

## Phase 4 — rate limit (R6)
- [x] 4.1 [TEST] `test/ratelimit.test.mjs`: 10 creates -> all 201; the 11th -> 429, `Retry-After` header
        present and >= 1, body has `retryAfterSeconds` >= 1 and <= 60. A **different IP** (X-Forwarded-For,
        trusted in test mode) is unaffected -> 201. `POST /api/test/reset` clears the window -> 201 again.
        Redirects are never rate limited.
- [x] 4.2 [CODE] `lib/ratelimit.mjs` sliding window + wire into `POST /api/links` + `/api/test/reset`.
- [x] 4.3 [TEST] `/api/test/reset` on a production app -> 404.

## Phase 5 — ship
- [x] 5.1 `server.mjs` boots on `process.env.PORT`; a tiny dashboard at `/`.
- [x] 5.2 Verify by hand: `PORT=3205 APP_ENV=test node server.mjs`, curl create -> follow -> list -> delete.
- [x] 5.3 `README.md`: one-command start, env vars, API table, the design decisions worth knowing.
- [x] 5.4 Final `npm test`, paste output. Commit.
