import http from 'node:http';
import { createApp } from './lib/app.mjs';
import { loadConfig } from './lib/config.mjs';

const config = loadConfig(process.env);
const app = createApp(config);
const server = http.createServer(app.handler);

server.listen(config.port, () => {
  console.log(`snip listening on http://localhost:${config.port} (APP_ENV=${config.env}, db=${config.dbPath})`);
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => server.close(() => { app.close(); process.exit(0); }));
}
