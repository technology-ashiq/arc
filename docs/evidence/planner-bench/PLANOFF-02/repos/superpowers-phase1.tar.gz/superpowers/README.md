# snip

A URL shortener. Sign in with an email magic link, shorten a URL (auto code or custom alias, optional
expiry), share it, watch the hits climb, delete it when it has served its purpose.

Node 22, ESM, **zero dependencies** — `node:http`, `node:sqlite`, `node:test`.

## Start it

```bash
PORT=3205 APP_ENV=test node server.mjs      # then open http://localhost:3205
```

For dev/prod, drop `APP_ENV=test` (see the env table). The SQLite file is created on first boot.

## Test it

```bash
npm test     # 24 tests, no network access, no third-party services
```

## API

| Method | Path | Behaviour |
|---|---|---|
| POST | `/api/links` | `{ url, alias?, expiresAt? }` -> `201 { code, shortUrl }` |
| GET | `/api/links` | `200 [{ code, url, hits, expiresAt }]` — your own links only |
| DELETE | `/api/links/:code` | `204` |
| GET | `/:code` | `302` to the long URL; the hit is counted |
| POST | `/api/auth/magic-link` | `{ email }` -> `204`, sign-in link emailed |
| GET | `/api/auth/verify?token=` | `302` + session cookie |
| POST | `/api/test/reset` | test mode only -> `204`; wipes links + rate-limit state |

Errors are `{ "error": { "code", "message" } }`.

| Situation | Status |
|---|---|
| not signed in / bad cookie | `401` |
| bad url, bad or reserved alias, past or unparseable `expiresAt` | `400` |
| alias already taken (including by a deleted link) | `409` |
| code never issued | `404` |
| code deleted, or expired | `410` |
| more than 10 creations/min/IP | `429` + `Retry-After` + `retryAfterSeconds` in the body |

## Things worth knowing (the full reasoning is in DESIGN.md)

- **Deleted is not unknown.** Delete is a tombstone: the row stays, `deleted_at` is stamped. A deleted code
  answers `410 Gone`; a code we never issued answers `404`. The tombstone also keeps the code **permanently
  reserved** — nobody, not even the original owner, can re-register it. A short link printed on a flyer can
  never be hijacked by re-registering it after deletion.
- **One namespace.** Auto-generated codes and custom aliases share the `links.code` primary key, so a
  collision is impossible at the storage layer. We attempt the insert and catch the constraint rather than
  checking first, which would be a TOCTOU race between two concurrent requests.
- **URLs are stored verbatim.** We validate by parsing, but never canonicalise: a visitor lands on exactly
  what the creator typed. `http(s)` only — a `javascript:` short link would be stored XSS.
- **Ownership is invisibility.** Deleting someone else's link is `404`, not `403`; a `403` would confirm the
  code exists and belongs to someone.
- **Rate limit** is per IP, sliding 60s window, creations only (redirects and reads are never limited).
  Only successful creations spend budget, so a rejected request cannot extend its own ban. It is in-process:
  behind several instances you would move the window into a shared store.
- **Auth in tests.** When `APP_ENV=test`, `X-Test-User: <email>` authenticates. Outside test mode the header
  is never read — a test asserts that a production app returns `401` for it — and mail goes through a
  `Mailer` interface (`FakeMailer` in tests, `ConsoleMailer` in dev, `HttpMailer` in prod), so nothing in the
  test path touches a live provider.

## Environment

| Var | Default | Meaning |
|---|---|---|
| `PORT` | `3000` | listen port |
| `APP_ENV` | `development` | `test` enables `X-Test-User` + `/api/test/reset`. Anything else disables both. |
| `DB_PATH` | `./data/snip.db` | SQLite file |
| `SESSION_SECRET` | dev placeholder | **set this in production**; signs session cookies |
| `BASE_URL` | request `Host` | base for `shortUrl` and magic links |
| `TRUST_PROXY` | off | `1` to read the client IP from `X-Forwarded-For` (only behind a proxy you control) |
| `MAIL_WEBHOOK_URL` | unset | if set outside test mode, magic links POST to this provider instead of the log |
