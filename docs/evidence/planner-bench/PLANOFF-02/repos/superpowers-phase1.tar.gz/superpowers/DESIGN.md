# snip — DESIGN

A URL shortener. Signed-in users create short links; anyone can follow them; hits are counted.
Zero runtime dependencies: `node:http` + `node:sqlite` + `node:test`.

## 1. Interrogating the requirements

### R1 — Magic-link auth, and "a user only ever sees their own links"
*Non-obvious case: how do we test auth without sending email?*
Two auth resolvers, tried in order:
1. **Test shim** — `X-Test-User: <email>` -> authenticated as that email. **Only consulted when `APP_ENV === 'test'`.**
   The check is against the config captured at boot; there is no code path where a non-test process reads that
   header. Proven by a test that boots a second app with `APP_ENV=production` and asserts the header yields `401`.
2. **Session cookie** — `snip_session=<email>.<hmac>` signed with `SESSION_SECRET` (HMAC-SHA256, timing-safe
   compare). Issued by `GET /api/auth/verify?token=...`, which is what the magic link points at.

Magic link is the real path: `POST /api/auth/magic-link {email}` mints a random 32-byte token, stores it with
a 15-minute expiry, and hands it to a **Mailer interface** — never called directly.
- `ConsoleMailer` (dev default) prints the link.
- `HttpMailer` (prod, only when `MAIL_WEBHOOK_URL` is set) POSTs to the provider.
- `FakeMailer` (tests) captures messages in an array.
The test suite constructs the app with a `FakeMailer`, so **the test path never opens a socket to a third
party** (R7). Loopback HTTP to our own server is not a third party.
Tokens are single-use (`used_at` stamped) and expire — replaying a consumed link is `400`.

*Non-obvious case: does a magic link for an unknown email fail?* No. Sign-in **is** sign-up; the user row is
created on verify. `POST /api/auth/magic-link` never reveals whether an email is known (no enumeration).

### R2 — Persistence
SQLite file at `./data/snip.db` (`DB_PATH` overridable, which is how tests get an isolated temp file).
A test writes a link, **closes the server, reopens it on the same file**, and follows the link. That is the
only honest way to test "survives a restart".

### R3 — Codes and aliases can never collide
*Non-obvious case: are auto-codes and custom aliases two namespaces or one?*
**One.** `links.code` is the PRIMARY KEY; an alias is simply a caller-chosen code. Collision is impossible at
the storage layer rather than in application logic that can be raced: we attempt the insert and catch the
`SQLITE_CONSTRAINT_PRIMARYKEY`. A check-then-insert would be a TOCTOU race between two concurrent requests.
Auto-codes: 7 chars of base62 from `crypto.randomBytes`, retried up to 5 times on collision.
Alias grammar: `^[A-Za-z0-9_-]{3,32}$`. Codes are **case-sensitive** (`aB` != `ab`) — base62 needs it.
Reserved aliases (`api`, `favicon.ico`, `robots.txt`, empty string) are rejected `400`, not `409`: they are
not taken by another link, they are unusable.

### R4 — Expiry
`expires_at` is nullable epoch-ms. A link with `expires_at <= now` does not redirect and does not count a hit.
*Non-obvious case: what status?* Not `404` — the code is real and we know exactly what it was. **`410 Gone`.**
`expiresAt` in the past at creation time is `400` (a link born dead is a client bug, not a feature).
Unparseable `expiresAt` is `400`. An expired link stays visible on the owner's dashboard.

### R5 — Delete is a tombstone, not an erasure
Requirement: *"the code is gone, not unknown."* So delete is **soft**: `deleted_at` is stamped, the row stays.
Consequences, each deliberate:
- `GET /:code` on a deleted link -> **`410 Gone`**; on a code that never existed -> **`404 Not Found`**.
  These are different facts and get different status codes.
- The tombstone keeps the PK occupied, so **a deleted code/alias can never be reused** by anyone. This is a
  security property, not an accident: if `promo` could be re-registered after deletion, an attacker could
  hijack a link already printed on a flyer.
- The link disappears from `GET /api/links` (the dashboard shows live links, not history).
- `DELETE` on an already-deleted link you own -> `204` (delete is idempotent; the post-condition holds).
- `DELETE` on a code owned by someone else -> **`404`, not `403`.** A `403` would confirm the code exists and
  is somebody's, which is exactly the enumeration leak R1 forbids. To a non-owner, the link is not a thing.

### R6 — Rate limit: 10 creations / minute / IP
Sliding window of timestamps per IP, in memory (single process; documented as such). Applies to
`POST /api/links` only — reading and redirecting are not "creating".
Over the limit -> **`429`** with `Retry-After: <seconds>` **and** a JSON body `{ retryAfterSeconds }`, because
the requirement says the caller must be *told how long to wait*, and a machine caller reads the body.
`retryAfterSeconds = ceil((oldestHitInWindow + 60000 - now) / 1000)`, minimum 1 — never `0`, which would
invite an immediate retry that fails again.
*Non-obvious case: what is "the IP" behind a proxy?* `socket.remoteAddress`, unless `TRUST_PROXY=1` (or test
mode), in which case the first entry of `X-Forwarded-For`. Trusting XFF by default would make the limit
trivially bypassable with a forged header. Test mode trusts it so we can prove the limit is *per IP*.
A rejected request is **not** recorded in the window (otherwise a hammering client extends its own ban forever).

### R7 — No network in tests
No third-party client exists in the test path (see R1). Tests bind to port 0 on loopback. Zero npm deps, so
`npm test` cannot even reach a registry.

## 2. Status codes — "the one that is actually true"
| Situation | Code |
|---|---|
| link created | `201` |
| list / redirect / delete | `200` / `302` / `204` |
| no or bad credentials | `401` |
| malformed url, bad alias grammar, reserved alias, unparseable or past `expiresAt` | `400` |
| code unknown to the system | `404` |
| code exists but is not yours (DELETE) | `404` |
| code existed and was deleted | `410` |
| code exists and has expired | `410` |
| alias already taken (even by a tombstone) | `409` |
| more than 10 creations/min/IP | `429` + `Retry-After` |
| `/api/test/reset` outside test mode | `404` (the route does not exist there) |

URL validation: must parse as absolute `http:` or `https:`. `javascript:` and `data:` are rejected `400` —
an open redirect to a `javascript:` URI is a stored-XSS vector.
The URL is stored **verbatim**: we validate by parsing, but do not canonicalise. `new URL(x).toString()`
would append a trailing slash and lowercase the host, i.e. redirect the visitor somewhere the creator never
typed. Validation is not a licence to rewrite user data.

## 3. Schema
users(email PK, created_at) ; magic_tokens(token PK, email, expires_at, used_at) ;
links(code PK, url, owner_email, created_at, expires_at NULL, deleted_at NULL, hits DEFAULT 0) ;
index on links(owner_email)

## 4. Layout
`server.mjs` (entrypoint: env -> app -> listen on `process.env.PORT`) · `lib/config.mjs` · `lib/db.mjs` ·
`lib/mailer.mjs` · `lib/auth.mjs` · `lib/ratelimit.mjs` · `lib/codes.mjs` · `lib/app.mjs` (router) ·
`test/*.test.mjs`.
