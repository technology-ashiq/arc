import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, req } from './helper.mjs';

const ALICE = 'alice@example.com';
const create = (app, opts = {}) =>
  req(app.base, 'POST', '/api/links', { user: ALICE, body: { url: 'https://example.com/x' }, ...opts });

test('the 11th creation in a minute is refused, and says how long to wait', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());

  for (let i = 1; i <= 10; i++) {
    const r = await create(app, { ip: '10.0.0.1' });
    assert.equal(r.status, 201, `creation ${i} of 10 should succeed`);
  }

  const over = await create(app, { ip: '10.0.0.1' });
  assert.equal(over.status, 429);
  const retryAfter = Number(over.headers.get('retry-after'));
  assert.ok(retryAfter >= 1 && retryAfter <= 60, `Retry-After should be 1..60, got ${retryAfter}`);
  assert.ok(over.json.retryAfterSeconds >= 1 && over.json.retryAfterSeconds <= 60,
    'the body must tell a machine caller how long to wait');
  assert.equal(over.json.error.code, 'rate_limited');
});

test('the limit is per IP, and redirects are never limited', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());

  for (let i = 0; i < 10; i++) await create(app, { ip: '10.0.0.1' });
  assert.equal((await create(app, { ip: '10.0.0.1' })).status, 429);

  const other = await create(app, { ip: '10.0.0.2' });
  assert.equal(other.status, 201, 'a different IP has its own budget');

  for (let i = 0; i < 15; i++) {
    const hop = await req(app.base, 'GET', `/${other.json.code}`, { ip: '10.0.0.1' });
    assert.equal(hop.status, 302, 'redirects must never be rate limited');
  }
  const list = await req(app.base, 'GET', '/api/links', { user: ALICE, ip: '10.0.0.1' });
  assert.equal(list.status, 200, 'reads must never be rate limited');
});

test('POST /api/test/reset wipes links and the rate-limit window', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());

  for (let i = 0; i < 10; i++) await create(app, { ip: '10.0.0.1' });
  assert.equal((await create(app, { ip: '10.0.0.1' })).status, 429);

  const reset = await req(app.base, 'POST', '/api/test/reset');
  assert.equal(reset.status, 204);

  assert.equal((await create(app, { ip: '10.0.0.1' })).status, 201, 'the window is clear again');
  const list = await req(app.base, 'GET', '/api/links', { user: ALICE });
  assert.equal(list.json.length, 1, 'reset wiped the old links');
});

test('the test-only reset route does not exist outside test mode', async (t) => {
  const app = await startApp({ env: 'production' });
  t.after(() => app.stop());
  const r = await req(app.base, 'POST', '/api/test/reset');
  assert.equal(r.status, 404);
});
