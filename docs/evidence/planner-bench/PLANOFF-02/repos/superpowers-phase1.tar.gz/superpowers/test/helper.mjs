import http from 'node:http';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../lib/app.mjs';
import { FakeMailer } from '../lib/mailer.mjs';

// Boots the real app on loopback:0 with an isolated temp DB and a FakeMailer.
// Nothing here (or anywhere in the test path) talks to a third-party service.
export async function startApp(opts = {}) {
  const dir = opts.dbPath ? null : mkdtempSync(join(tmpdir(), 'snip-'));
  const dbPath = opts.dbPath ?? join(dir, 'snip.db');
  const mailer = opts.mailer ?? new FakeMailer();
  const app = createApp({
    env: opts.env ?? 'test',
    dbPath,
    sessionSecret: opts.sessionSecret ?? 'test-secret',
    mailer,
    baseUrl: opts.baseUrl ?? null,
  });
  const server = http.createServer(app.handler);
  await new Promise((res) => server.listen(0, '127.0.0.1', res));
  const base = `http://127.0.0.1:${server.address().port}`;
  return {
    base,
    mailer,
    dbPath,
    async stop({ keepData = false } = {}) {
      await new Promise((res) => server.close(res));
      app.close();
      if (dir && !keepData) rmSync(dir, { recursive: true, force: true });
    },
  };
}

// Thin fetch wrapper. `user` sets the test-auth header, `ip` forges X-Forwarded-For.
export async function req(base, method, path, opts = {}) {
  const headers = { ...(opts.headers ?? {}) };
  if (opts.user) headers['X-Test-User'] = opts.user;
  if (opts.ip) headers['X-Forwarded-For'] = opts.ip;
  if (opts.cookie) headers['Cookie'] = opts.cookie;
  let body;
  if (opts.body !== undefined) {
    body = JSON.stringify(opts.body);
    headers['Content-Type'] = 'application/json';
  }
  const res = await fetch(base + path, { method, headers, body, redirect: 'manual' });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* not json (html page) */ }
  return { status: res.status, headers: res.headers, text, json };
}
