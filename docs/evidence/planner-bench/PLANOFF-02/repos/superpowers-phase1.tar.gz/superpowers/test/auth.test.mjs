import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, req } from './helper.mjs';

test('unauthenticated create is 401', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  const r = await req(app.base, 'POST', '/api/links', { body: { url: 'https://example.com' } });
  assert.equal(r.status, 401);
});

test('X-Test-User authenticates when APP_ENV=test', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  const r = await req(app.base, 'POST', '/api/links', {
    user: 'alice@example.com',
    body: { url: 'https://example.com' },
  });
  assert.equal(r.status, 201);
});

test('X-Test-User is ignored completely outside test mode', async (t) => {
  const app = await startApp({ env: 'production' });
  t.after(() => app.stop());
  const create = await req(app.base, 'POST', '/api/links', {
    user: 'attacker@example.com',
    body: { url: 'https://example.com' },
  });
  assert.equal(create.status, 401, 'the shim header must not authenticate in production');
  const list = await req(app.base, 'GET', '/api/links', { user: 'attacker@example.com' });
  assert.equal(list.status, 401);
});

test('magic link: mail is sent through the mailer, never over the network', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  const r = await req(app.base, 'POST', '/api/auth/magic-link', { body: { email: 'bob@example.com' } });
  assert.equal(r.status, 204);
  assert.equal(app.mailer.sent.length, 1);
  const msg = app.mailer.sent[0];
  assert.equal(msg.to, 'bob@example.com');
  assert.match(msg.text, /\/api\/auth\/verify\?token=/);
});

test('magic link: verifying signs you in, and the token is single-use', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  await req(app.base, 'POST', '/api/auth/magic-link', { body: { email: 'bob@example.com' } });
  const token = app.mailer.sent[0].text.match(/token=([A-Za-z0-9_-]+)/)[1];

  const verify = await req(app.base, 'GET', `/api/auth/verify?token=${token}`);
  assert.equal(verify.status, 302);
  const setCookie = verify.headers.get('set-cookie');
  assert.match(setCookie, /snip_session=/);
  assert.match(setCookie, /HttpOnly/i);

  const cookie = setCookie.split(';')[0];
  const list = await req(app.base, 'GET', '/api/links', { cookie });
  assert.equal(list.status, 200);
  assert.deepEqual(list.json, []);

  const replay = await req(app.base, 'GET', `/api/auth/verify?token=${token}`);
  assert.equal(replay.status, 400, 'a spent magic-link token must not sign anyone in twice');
});

test('a forged session cookie is rejected', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  const r = await req(app.base, 'GET', '/api/links', {
    cookie: 'snip_session=alice@example.com.deadbeef',
  });
  assert.equal(r.status, 401);
});
