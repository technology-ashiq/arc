import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, req } from './helper.mjs';

const ALICE = 'alice@example.com';

test('a link redirects until it expires, then it is Gone', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());

  const expiresAt = new Date(Date.now() + 600).toISOString();
  const created = await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://example.com/sale', expiresAt },
  });
  assert.equal(created.status, 201);

  const before = await req(app.base, 'GET', `/${created.json.code}`);
  assert.equal(before.status, 302);

  await new Promise((r) => setTimeout(r, 750));

  const after = await req(app.base, 'GET', `/${created.json.code}`);
  assert.equal(after.status, 410, 'an expired code is Gone, not Not Found');
  assert.equal(after.json.error.code, 'expired');

  const list = await req(app.base, 'GET', '/api/links', { user: ALICE });
  assert.equal(list.json[0].hits, 1, 'a hit on an expired link is not counted');
  assert.equal(list.json[0].expiresAt, new Date(expiresAt).toISOString());
});

test('expiry in the past, or unparseable, is rejected at creation', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());

  const past = await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://e.com', expiresAt: new Date(Date.now() - 1000).toISOString() },
  });
  assert.equal(past.status, 400);
  assert.equal(past.json.error.code, 'invalid_expiry');

  for (const bad of ['tomorrow', '2026-13-45T00:00:00Z', 12345, {}]) {
    const r = await req(app.base, 'POST', '/api/links', { user: ALICE, body: { url: 'https://e.com', expiresAt: bad } });
    assert.equal(r.status, 400, `expected 400 for expiresAt ${JSON.stringify(bad)}`);
    assert.equal(r.json.error.code, 'invalid_expiry');
  }
});

test('links and hits survive a restart', async (t) => {
  const first = await startApp();
  const created = await req(first.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://example.com/persisted', alias: 'keeper' },
  });
  assert.equal(created.status, 201);
  await req(first.base, 'GET', '/keeper');
  await first.stop({ keepData: true });

  const second = await startApp({ dbPath: first.dbPath });
  t.after(() => second.stop());

  const hop = await req(second.base, 'GET', '/keeper');
  assert.equal(hop.status, 302, 'the link must survive a restart');
  assert.equal(hop.headers.get('location'), 'https://example.com/persisted');

  const list = await req(second.base, 'GET', '/api/links', { user: ALICE });
  assert.equal(list.json[0].hits, 2, 'hit counts survive a restart too');
});
