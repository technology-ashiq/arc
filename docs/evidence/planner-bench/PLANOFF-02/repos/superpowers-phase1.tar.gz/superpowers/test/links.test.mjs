import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, req } from './helper.mjs';

const ALICE = 'alice@example.com';

test('create -> redirect -> hits are counted', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());

  const created = await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://example.com/a/very/long/path?q=1' },
  });
  assert.equal(created.status, 201);
  assert.match(created.json.code, /^[A-Za-z0-9_-]+$/);
  assert.equal(created.json.shortUrl, `${app.base}/${created.json.code}`);

  const hop = await req(app.base, 'GET', `/${created.json.code}`);
  assert.equal(hop.status, 302);
  assert.equal(hop.headers.get('location'), 'https://example.com/a/very/long/path?q=1');

  await req(app.base, 'GET', `/${created.json.code}`);

  const list = await req(app.base, 'GET', '/api/links', { user: ALICE });
  assert.equal(list.status, 200);
  assert.equal(list.json.length, 1);
  assert.equal(list.json[0].hits, 2);
  assert.equal(list.json[0].url, 'https://example.com/a/very/long/path?q=1');
  assert.equal(list.json[0].expiresAt, null);
});

test('an unknown code is 404 and counts nothing', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  const r = await req(app.base, 'GET', '/nosuchcode');
  assert.equal(r.status, 404);
  assert.equal(r.json.error.code, 'not_found');
});

test('a url that is not an http(s) url is rejected', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  for (const url of ['not-a-url', 'javascript:alert(1)', 'data:text/html,<script>', '', null, 42]) {
    const r = await req(app.base, 'POST', '/api/links', { user: ALICE, body: { url } });
    assert.equal(r.status, 400, `expected 400 for ${JSON.stringify(url)}`);
    assert.equal(r.json.error.code, 'invalid_url');
  }
});

test('custom alias is honoured, and no two links can share a code', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());

  const a = await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://example.com/1', alias: 'launch-day' },
  });
  assert.equal(a.status, 201);
  assert.equal(a.json.code, 'launch-day');
  const hop = await req(app.base, 'GET', '/launch-day');
  assert.equal(hop.headers.get('location'), 'https://example.com/1');

  // Same owner, and a different owner, both collide: the namespace is global.
  const dupe = await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://example.com/2', alias: 'launch-day' },
  });
  assert.equal(dupe.status, 409);
  assert.equal(dupe.json.error.code, 'code_taken');

  const otherUser = await req(app.base, 'POST', '/api/links', {
    user: 'bob@example.com', body: { url: 'https://evil.example/phish', alias: 'launch-day' },
  });
  assert.equal(otherUser.status, 409, 'a taken alias is taken for everybody');

  const stillMine = await req(app.base, 'GET', '/launch-day');
  assert.equal(stillMine.headers.get('location'), 'https://example.com/1');
});

test('an alias that collides with an auto-generated code is refused (one namespace)', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  const auto = await req(app.base, 'POST', '/api/links', { user: ALICE, body: { url: 'https://example.com/x' } });
  const clash = await req(app.base, 'POST', '/api/links', {
    user: 'bob@example.com', body: { url: 'https://example.com/y', alias: auto.json.code },
  });
  assert.equal(clash.status, 409);
});

test('bad or reserved aliases are 400, not 409', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  for (const alias of ['ab', 'no spaces', 'x'.repeat(33), 'sla/sh', 'dot.dot']) {
    const r = await req(app.base, 'POST', '/api/links', { user: ALICE, body: { url: 'https://e.com', alias } });
    assert.equal(r.status, 400, `expected 400 for alias ${alias}`);
    assert.equal(r.json.error.code, 'invalid_alias');
  }
  const reserved = await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://e.com', alias: 'api' },
  });
  assert.equal(reserved.status, 400);
  assert.equal(reserved.json.error.code, 'reserved_alias');
});
