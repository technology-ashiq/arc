import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startApp, req } from './helper.mjs';

const ALICE = 'alice@example.com';
const BOB = 'bob@example.com';

test('a user only ever sees their own links', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  await req(app.base, 'POST', '/api/links', { user: ALICE, body: { url: 'https://alice.example' } });
  await req(app.base, 'POST', '/api/links', { user: BOB, body: { url: 'https://bob.example' } });

  const alices = await req(app.base, 'GET', '/api/links', { user: ALICE });
  assert.equal(alices.json.length, 1);
  assert.equal(alices.json[0].url, 'https://alice.example');

  const bobs = await req(app.base, 'GET', '/api/links', { user: BOB });
  assert.equal(bobs.json.length, 1);
  assert.equal(bobs.json[0].url, 'https://bob.example');
});

test("bob cannot delete alice's link, and the refusal does not leak that it exists", async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://alice.example', alias: 'alices-link' },
  });

  const attempt = await req(app.base, 'DELETE', '/api/links/alices-link', { user: BOB });
  assert.equal(attempt.status, 404, "someone else's link is not a thing you can see");

  const stillWorks = await req(app.base, 'GET', '/alices-link');
  assert.equal(stillWorks.status, 302, 'the 404 must not have been a silent delete');
  assert.equal(stillWorks.headers.get('location'), 'https://alice.example');
});

test('a deleted link is Gone (410), not Unknown (404)', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  const created = await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://example.com/old', alias: 'retired' },
  });
  assert.equal(created.status, 201);

  const del = await req(app.base, 'DELETE', '/api/links/retired', { user: ALICE });
  assert.equal(del.status, 204);

  const gone = await req(app.base, 'GET', '/retired');
  assert.equal(gone.status, 410, 'the code is gone, not unknown');
  assert.equal(gone.json.error.code, 'gone');

  const neverExisted = await req(app.base, 'GET', '/neverwashere');
  assert.equal(neverExisted.status, 404, 'a code that never existed is a different fact');
  assert.equal(neverExisted.json.error.code, 'not_found');

  const list = await req(app.base, 'GET', '/api/links', { user: ALICE });
  assert.deepEqual(list.json, [], 'a deleted link is off the dashboard');
});

test('a deleted code can never be re-registered', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  await req(app.base, 'POST', '/api/links', { user: ALICE, body: { url: 'https://e.com/1', alias: 'flyer' } });
  await req(app.base, 'DELETE', '/api/links/flyer', { user: ALICE });

  const reclaim = await req(app.base, 'POST', '/api/links', {
    user: ALICE, body: { url: 'https://e.com/2', alias: 'flyer' },
  });
  assert.equal(reclaim.status, 409, 'a tombstoned code stays taken -- printed links cannot be hijacked');

  const byOther = await req(app.base, 'POST', '/api/links', {
    user: 'mallory@example.com', body: { url: 'https://evil.example', alias: 'flyer' },
  });
  assert.equal(byOther.status, 409);
});

test('deleting is idempotent; deleting an unknown code is 404; delete needs auth', async (t) => {
  const app = await startApp();
  t.after(() => app.stop());
  await req(app.base, 'POST', '/api/links', { user: ALICE, body: { url: 'https://e.com', alias: 'twice' } });

  assert.equal((await req(app.base, 'DELETE', '/api/links/twice', { user: ALICE })).status, 204);
  assert.equal((await req(app.base, 'DELETE', '/api/links/twice', { user: ALICE })).status, 204);
  assert.equal((await req(app.base, 'DELETE', '/api/links/ghost', { user: ALICE })).status, 404);
  assert.equal((await req(app.base, 'DELETE', '/api/links/twice')).status, 401);
});
