import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

let app;
const ALICE = 'alice@example.com';
const BOB = 'bob@example.com';

before(async () => { app = await startServer(); });
after(async () => { await app.stop(); });
beforeEach(async () => { await app.call('/api/test/reset', { method: 'POST' }); });

test('creates a short link and returns 201 with code + shortUrl', async () => {
  const res = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com/a/very/long/path' } });
  assert.equal(res.status, 201);
  assert.match(res.body.code, /^[A-Za-z0-9]{7}$/);
  assert.equal(res.body.shortUrl, `${app.base}/${res.body.code}`);
});

test('redirects with 302 and counts the hit', async () => {
  const { body: { code } } = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com/target' } });

  const r1 = await app.call(`/${code}`);
  assert.equal(r1.status, 302);
  assert.equal(r1.headers.get('location'), 'https://example.com/target');
  await app.call(`/${code}`);
  await app.call(`/${code}`);

  const list = await app.call('/api/links', { user: ALICE });
  assert.equal(list.body.find((l) => l.code === code).hits, 3);
});

test('unknown code is 404 not_found', async () => {
  const res = await app.call('/nosuchcode');
  assert.equal(res.status, 404);
  assert.equal(res.body.error, 'not_found');
});

test('rejects a url that is not http(s)', async () => {
  for (const url of ['javascript:alert(1)', 'not a url', '']) {
    const res = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url } });
    assert.equal(res.status, 400, `expected 400 for ${JSON.stringify(url)}`);
    assert.equal(res.body.error, 'invalid_url');
  }
});

test('custom alias is honoured, and a taken alias is 409', async () => {
  const first = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com/1', alias: 'my-link' } });
  assert.equal(first.status, 201);
  assert.equal(first.body.code, 'my-link');
  assert.equal((await app.call('/my-link')).headers.get('location'), 'https://example.com/1');

  // same user, and a different user, both blocked: codes are globally unique
  for (const user of [ALICE, BOB]) {
    const dup = await app.call('/api/links', { method: 'POST', user, body: { url: 'https://example.com/2', alias: 'my-link' } });
    assert.equal(dup.status, 409);
    assert.equal(dup.body.error, 'alias_taken');
  }
});

test('generated codes are unique and never collide with an alias', async () => {
  // its own server: 50 creates would otherwise trip the (deliberate) 10/min limit
  const bulk = await startServer({ env: { RATE_LIMIT: '1000' } });
  try {
    await bulk.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com/x', alias: 'takenalias' } });
    const codes = new Set(['takenalias']);
    for (let i = 0; i < 50; i++) {
      const res = await bulk.call('/api/links', { method: 'POST', user: ALICE, body: { url: `https://example.com/${i}` } });
      assert.equal(res.status, 201);
      assert.equal(codes.has(res.body.code), false, 'duplicate code issued');
      codes.add(res.body.code);
    }
  } finally {
    await bulk.stop();
  }
});

test('malformed alias is 400, reserved alias is 409', async () => {
  const bad = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com', alias: 'no spaces!' } });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.error, 'invalid_alias');

  const reserved = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com', alias: 'api' } });
  assert.equal(reserved.status, 409);
  assert.equal(reserved.body.error, 'alias_reserved');
});

test('an expired link stops redirecting (410 expired) and stops counting hits', async () => {
  const soon = new Date(Date.now() + 120).toISOString();
  const { body: { code } } = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com/temp', expiresAt: soon } });

  assert.equal((await app.call(`/${code}`)).status, 302);
  await new Promise((r) => setTimeout(r, 200));

  const after = await app.call(`/${code}`);
  assert.equal(after.status, 410);
  assert.equal(after.body.error, 'expired');

  const list = await app.call('/api/links', { user: ALICE });
  const link = list.body.find((l) => l.code === code);
  assert.equal(link.hits, 1, 'the expired visit must not be counted');
  assert.equal(link.expiresAt, soon);
});

test('expiry must be a future ISO-8601 timestamp', async () => {
  const junk = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com', expiresAt: 'tomorrow-ish' } });
  assert.equal(junk.status, 400);
  assert.equal(junk.body.error, 'invalid_expiry');

  const past = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com', expiresAt: '2020-01-01T00:00:00.000Z' } });
  assert.equal(past.status, 400);
  assert.equal(past.body.error, 'invalid_expiry');
});

test('deleted link is gone (410), not unknown (404), and its code is never reused', async () => {
  const { body: { code } } = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com/doomed', alias: 'doomed' } });

  assert.equal((await app.call(`/api/links/${code}`, { method: 'DELETE', user: ALICE })).status, 204);

  const visit = await app.call(`/${code}`);
  assert.equal(visit.status, 410);
  assert.equal(visit.body.error, 'gone');
  assert.notEqual(visit.body.error, 'not_found');
  assert.match(visit.body.message, /deleted/i);

  // a never-existing code is a different answer entirely
  assert.equal((await app.call('/neverwas')).status, 404);

  // the code is spent: nobody can claim it again
  const reclaim = await app.call('/api/links', { method: 'POST', user: BOB, body: { url: 'https://evil.example/phish', alias: 'doomed' } });
  assert.equal(reclaim.status, 409);

  // and it drops off the owner's dashboard
  const list = await app.call('/api/links', { user: ALICE });
  assert.equal(list.body.find((l) => l.code === code), undefined);

  // deleting twice is 410, not 204
  const again = await app.call(`/api/links/${code}`, { method: 'DELETE', user: ALICE });
  assert.equal(again.status, 410);
});

test('deleting a code that never existed is 404', async () => {
  const res = await app.call('/api/links/neverwas', { method: 'DELETE', user: ALICE });
  assert.equal(res.status, 404);
  assert.equal(res.body.error, 'not_found');
});
