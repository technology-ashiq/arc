import http from 'node:http';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openDb } from '../src/db.mjs';
import { createMemoryMailer } from '../src/mailer.mjs';
import { createApp } from '../src/app.mjs';

/**
 * Boots the real app over a real HTTP socket against a real (temp-file) SQLite db.
 * The mailer is the in-memory one, so nothing in the test path leaves the process.
 */
export async function startServer({ env = {}, dbFile, clock } = {}) {
  const dir = dbFile ? null : mkdtempSync(join(tmpdir(), 'snip-test-'));
  const file = dbFile ?? join(dir, 'snip.db');

  const db = openDb(file);
  const mailer = createMemoryMailer();
  const fullEnv = { APP_ENV: 'test', SESSION_SECRET: 'test-secret', ...env };
  const now = clock ?? (() => Date.now());
  const server = http.createServer(createApp({ db, mailer, env: fullEnv, now }));

  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;

  return {
    base, db, mailer, dbFile: file,
    async call(path, { method = 'GET', body, user, headers = {}, cookie } = {}) {
      const h = { ...headers };
      if (user) h['x-test-user'] = user;
      if (cookie) h.cookie = cookie;
      if (body !== undefined) h['content-type'] = 'application/json';
      const res = await fetch(base + path, {
        method,
        headers: h,
        body: body === undefined ? undefined : JSON.stringify(body),
        redirect: 'manual',
      });
      const text = await res.text();
      let json = null;
      try { json = text ? JSON.parse(text) : null; } catch { /* not json (html, empty) */ }
      return { status: res.status, headers: res.headers, body: json, text };
    },
    async stop({ keepDb = false } = {}) {
      await new Promise((resolve) => server.close(resolve));
      db.close();
      if (dir && !keepDb) rmSync(dir, { recursive: true, force: true });
    },
  };
}
