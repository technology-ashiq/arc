import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';

const ALICE = 'alice@example.com';
const BOB = 'bob@example.com';

let app;
before(async () => { app = await startServer(); });
after(async () => { await app.stop(); });
beforeEach(async () => { await app.call('/api/test/reset', { method: 'POST' }); });

test('the links API requires a signed-in caller', async () => {
  const create = await app.call('/api/links', { method: 'POST', body: { url: 'https://example.com' } });
  assert.equal(create.status, 401);
  assert.equal(create.body.error, 'unauthorized');

  assert.equal((await app.call('/api/links')).status, 401);
  assert.equal((await app.call('/api/links/whatever', { method: 'DELETE' })).status, 401);
});

test('a user only ever sees, and can only delete, their own links', async () => {
  const { body: a } = await app.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com/alice' } });
  await app.call('/api/links', { method: 'POST', user: BOB, body: { url: 'https://example.com/bob' } });

  const bobList = await app.call('/api/links', { user: BOB });
  assert.equal(bobList.body.length, 1);
  assert.equal(bobList.body[0].url, 'https://example.com/bob');
  assert.equal(bobList.body.some((l) => l.code === a.code), false);

  // Bob cannot delete Alice's link, and it keeps working
  const attack = await app.call(`/api/links/${a.code}`, { method: 'DELETE', user: BOB });
  assert.equal(attack.status, 404);
  assert.equal((await app.call(`/${a.code}`)).status, 302);

  // ...but anyone may follow it
  assert.equal((await app.call(`/${a.code}`)).headers.get('location'), 'https://example.com/alice');
});

test('magic-link sign-in works end to end without touching the network', async () => {
  const req = await app.call('/api/auth/magic-link', { method: 'POST', body: { email: 'carol@example.com' } });
  assert.equal(req.status, 202);
  assert.equal(req.text.includes('token'), false, 'the response must not leak the token');

  assert.equal(app.mailer.outbox.length, 1);
  const mail = app.mailer.outbox[0];
  assert.equal(mail.to, 'carol@example.com');
  const token = mail.text.match(/token=([^\s&]+)/)[1];

  const cb = await app.call(`/api/auth/callback?token=${token}`);
  assert.equal(cb.status, 302);
  const cookie = cb.headers.getSetCookie()[0].split(';')[0];
  assert.match(cookie, /^snip_session=/);

  const me = await app.call('/api/me', { cookie });
  assert.equal(me.status, 200);
  assert.equal(me.body.email, 'carol@example.com');

  const created = await app.call('/api/links', { method: 'POST', cookie, body: { url: 'https://example.com/carol' } });
  assert.equal(created.status, 201);
  const list = await app.call('/api/links', { cookie });
  assert.equal(list.body[0].code, created.body.code);

  // single use
  assert.equal((await app.call(`/api/auth/callback?token=${token}`)).status, 401);
  // forged / unknown token
  assert.equal((await app.call('/api/auth/callback?token=made-up')).status, 401);
  // tampered cookie
  assert.equal((await app.call('/api/me', { cookie: `${cookie}tamper` })).status, 401);
});

test('magic-link requires a plausible email', async () => {
  const res = await app.call('/api/auth/magic-link', { method: 'POST', body: { email: 'nope' } });
  assert.equal(res.status, 400);
  assert.equal(res.body.error, 'invalid_email');
  assert.equal(app.mailer.outbox.length, 0);
});

test('outside APP_ENV=test the X-Test-User header is ignored completely', async () => {
  const dev = await startServer({ env: { APP_ENV: 'development' } });
  try {
    const create = await dev.call('/api/links', { method: 'POST', user: ALICE, body: { url: 'https://example.com' } });
    assert.equal(create.status, 401, 'the shim must not authenticate outside test mode');
    assert.equal((await dev.call('/api/links', { user: ALICE })).status, 401);
    assert.equal((await dev.call('/api/me', { user: ALICE })).status, 401);

    // and the test-only reset endpoint does not exist there either
    const reset = await dev.call('/api/test/reset', { method: 'POST', user: ALICE });
    assert.equal(reset.status, 404);

    // the real path still works in dev
    await dev.call('/api/auth/magic-link', { method: 'POST', body: { email: ALICE } });
    const token = dev.mailer.outbox[0].text.match(/token=([^\s&]+)/)[1];
    const cb = await dev.call(`/api/auth/callback?token=${token}`);
    const cookie = cb.headers.getSetCookie()[0].split(';')[0];
    assert.equal((await dev.call('/api/me', { cookie })).body.email, ALICE);
  } finally {
    await dev.stop();
  }
});
