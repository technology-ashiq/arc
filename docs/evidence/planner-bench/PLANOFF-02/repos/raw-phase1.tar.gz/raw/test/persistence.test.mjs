import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { startServer } from './helpers.mjs';

test('links, hits and tombstones survive a restart', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'snip-persist-'));
  const dbFile = join(dir, 'snip.db');
  const user = 'alice@example.com';

  let app = await startServer({ dbFile });
  let code, doomed;
  try {
    ({ body: { code } } = await app.call('/api/links', { method: 'POST', user, body: { url: 'https://example.com/kept', alias: 'kept' } }));
    ({ body: { code: doomed } } = await app.call('/api/links', { method: 'POST', user, body: { url: 'https://example.com/gone', alias: 'gone-forever' } }));
    await app.call(`/${code}`);
    await app.call(`/${code}`);
    await app.call(`/api/links/${doomed}`, { method: 'DELETE', user });
  } finally {
    await app.stop({ keepDb: true }); // process restart: db file stays
  }

  app = await startServer({ dbFile });
  try {
    const visit = await app.call(`/${code}`);
    assert.equal(visit.status, 302);
    assert.equal(visit.headers.get('location'), 'https://example.com/kept');

    const list = await app.call('/api/links', { user });
    assert.equal(list.body.length, 1);
    assert.equal(list.body[0].code, 'kept');
    assert.equal(list.body[0].hits, 3, 'hits from before the restart are still there');

    // the tombstone survived too
    assert.equal((await app.call(`/${doomed}`)).body.error, 'gone');
    const reclaim = await app.call('/api/links', { method: 'POST', user, body: { url: 'https://example.com/x', alias: 'gone-forever' } });
    assert.equal(reclaim.status, 409);
  } finally {
    await app.stop({ keepDb: true });
    rmSync(dir, { recursive: true, force: true });
  }
});
