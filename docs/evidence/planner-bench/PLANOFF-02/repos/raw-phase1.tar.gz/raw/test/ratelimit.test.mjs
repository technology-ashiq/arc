import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startServer } from './helpers.mjs';
import { createRateLimiter } from '../src/ratelimit.mjs';

const ALICE = 'alice@example.com';

let app;
let clock = Date.now();
before(async () => { app = await startServer({ clock: () => clock }); });
after(async () => { await app.stop(); });
beforeEach(async () => { await app.call('/api/test/reset', { method: 'POST' }); });

const create = (user = ALICE) =>
  app.call('/api/links', { method: 'POST', user, body: { url: 'https://example.com/rl' } });

test('the 11th create in a minute is rejected with 429 and a wait time', async () => {
  for (let i = 0; i < 10; i++) {
    assert.equal((await create()).status, 201, `create #${i + 1} should succeed`);
  }

  const blocked = await create();
  assert.equal(blocked.status, 429);
  assert.equal(blocked.body.error, 'rate_limited');

  const retryAfter = Number(blocked.headers.get('retry-after'));
  assert.ok(retryAfter >= 1 && retryAfter <= 60, `retry-after should be a sane wait, got ${retryAfter}`);
  assert.match(blocked.body.message, /retry in \d+ second/i);
});

test('the limit is per IP, not per user, and it frees up as the window slides', async () => {
  for (let i = 0; i < 10; i++) await create();
  // a different user from the same IP is still blocked
  assert.equal((await create('bob@example.com')).status, 429);

  clock += 61_000; // window has passed
  assert.equal((await create('bob@example.com')).status, 201);
});

test('reset clears rate-limit state as well as links', async () => {
  for (let i = 0; i < 10; i++) await create();
  assert.equal((await create()).status, 429);

  await app.call('/api/test/reset', { method: 'POST' });

  assert.equal((await create()).status, 201);
  const list = await app.call('/api/links', { user: ALICE });
  assert.equal(list.body.length, 1, 'reset should have wiped the earlier links');
});

test('rate limiter unit: window is sliding, not fixed', () => {
  let t = 1_000_000;
  const limiter = createRateLimiter({ limit: 2, windowMs: 1000, now: () => t });
  assert.equal(limiter.take('ip').allowed, true);
  t += 600;
  assert.equal(limiter.take('ip').allowed, true);
  const third = limiter.take('ip');
  assert.equal(third.allowed, false);
  assert.equal(third.retryAfterSeconds, 1);
  t += 500; // first stamp aged out, second has not
  assert.equal(limiter.take('ip').allowed, true);
  assert.equal(limiter.take('ip').allowed, false);
});
