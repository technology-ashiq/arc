// Mailer is an interface with three implementations. The test path only ever
// uses the in-memory one, so `npm test` never touches a live email provider.

export function createMemoryMailer() {
  const outbox = [];
  return {
    kind: 'memory',
    outbox,
    async send(message) { outbox.push(message); return { id: `mem-${outbox.length}` }; },
  };
}

export function createConsoleMailer(log = console.log) {
  return {
    kind: 'console',
    async send({ to, subject, text }) {
      log(`\n--- email (dev) ---\nto: ${to}\nsubject: ${subject}\n${text}\n-------------------\n`);
      return { id: 'console' };
    },
  };
}

// Real provider. Only ever constructed when APP_ENV is not `test`.
export function createHttpMailer({ apiUrl, apiKey, from }) {
  if (!apiUrl || !apiKey) throw new Error('http mailer requires MAIL_API_URL and MAIL_API_KEY');
  return {
    kind: 'http',
    async send({ to, subject, text }) {
      const res = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({ from, to, subject, text }),
      });
      if (!res.ok) throw new Error(`mail provider responded ${res.status}`);
      return res.json().catch(() => ({}));
    },
  };
}

export function createMailer(env = process.env) {
  if (env.APP_ENV === 'test') return createMemoryMailer();
  if (env.MAIL_API_URL && env.MAIL_API_KEY) {
    return createHttpMailer({
      apiUrl: env.MAIL_API_URL,
      apiKey: env.MAIL_API_KEY,
      from: env.MAIL_FROM ?? 'snip <no-reply@snip.local>',
    });
  }
  return createConsoleMailer();
}
