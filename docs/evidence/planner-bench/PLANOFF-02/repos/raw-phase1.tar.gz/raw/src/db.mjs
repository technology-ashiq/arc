import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id         INTEGER PRIMARY KEY,
  email      TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL
);

-- A link row is never hard-deleted: the tombstone (deleted_at) is what lets us
-- answer "410 Gone" instead of "404 Not Found", and it keeps the code/alias
-- permanently reserved so a dead short link can never be resurrected by someone else.
CREATE TABLE IF NOT EXISTS links (
  id         INTEGER PRIMARY KEY,
  code       TEXT NOT NULL UNIQUE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  url        TEXT NOT NULL,
  hits       INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT,
  created_at TEXT NOT NULL,
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_links_user ON links(user_id, deleted_at);

CREATE TABLE IF NOT EXISTS magic_tokens (
  token_hash TEXT PRIMARY KEY,
  email      TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at    TEXT
);
`;

export function openDb(file = process.env.DB_FILE ?? './data/snip.db') {
  if (file !== ':memory:') mkdirSync(dirname(resolve(file)), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA foreign_keys = ON');
  db.exec(SCHEMA);
  return db;
}

export function upsertUser(db, email) {
  const normalized = String(email).trim().toLowerCase();
  db.prepare('INSERT OR IGNORE INTO users (email, created_at) VALUES (?, ?)')
    .run(normalized, new Date().toISOString());
  return db.prepare('SELECT id, email FROM users WHERE email = ?').get(normalized);
}
