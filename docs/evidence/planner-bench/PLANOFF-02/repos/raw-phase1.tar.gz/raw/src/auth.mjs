import { createHmac, randomBytes, createHash, timingSafeEqual } from 'node:crypto';
import { upsertUser } from './db.mjs';

const SESSION_COOKIE = 'snip_session';
const TOKEN_TTL_MS = 15 * 60 * 1000;
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

export function sessionSecret(env = process.env) {
  if (env.SESSION_SECRET) return env.SESSION_SECRET;
  if (env.APP_ENV === 'production') {
    throw new Error('SESSION_SECRET is required when APP_ENV=production');
  }
  return 'snip-insecure-dev-secret'; // stable across restarts so dev/test sessions survive
}

const b64 = (s) => Buffer.from(s, 'utf8').toString('base64url');
const unb64 = (s) => Buffer.from(s, 'base64url').toString('utf8');

function sign(payload, secret) {
  return createHmac('sha256', secret).update(payload).digest('base64url');
}

export function mintSession(email, secret, now = Date.now()) {
  const payload = b64(JSON.stringify({ email, exp: now + SESSION_TTL_MS }));
  return `${payload}.${sign(payload, secret)}`;
}

export function readSession(cookieValue, secret, now = Date.now()) {
  if (!cookieValue || !cookieValue.includes('.')) return null;
  const [payload, sig] = cookieValue.split('.', 2);
  const expected = sign(payload, secret);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const { email, exp } = JSON.parse(unb64(payload));
    if (!email || typeof exp !== 'number' || exp < now) return null;
    return email;
  } catch { return null; }
}

export function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function sessionCookie(value, { secure = false, maxAgeSeconds = SESSION_TTL_MS / 1000 } = {}) {
  const bits = [
    `${SESSION_COOKIE}=${encodeURIComponent(value)}`,
    'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${maxAgeSeconds}`,
  ];
  if (secure) bits.push('Secure');
  return bits.join('; ');
}

export const clearSessionCookie = (opts) => sessionCookie('', { ...opts, maxAgeSeconds: 0 });

/**
 * Resolve the caller.
 * The X-Test-User shim is honoured ONLY when APP_ENV === 'test'. In every other
 * environment the header is never read, so it cannot be used to impersonate.
 */
export function authenticate(req, { db, env }) {
  if (env.APP_ENV === 'test') {
    const testUser = req.headers['x-test-user'];
    if (typeof testUser === 'string' && testUser.includes('@')) {
      return upsertUser(db, testUser);
    }
  }
  const cookies = parseCookies(req.headers.cookie ?? '');
  const email = readSession(cookies[SESSION_COOKIE], sessionSecret(env));
  return email ? upsertUser(db, email) : null;
}

const hashToken = (token) => createHash('sha256').update(token).digest('hex');

export function issueMagicToken(db, email, now = Date.now()) {
  const token = randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO magic_tokens (token_hash, email, expires_at) VALUES (?, ?, ?)')
    .run(hashToken(token), String(email).trim().toLowerCase(), new Date(now + TOKEN_TTL_MS).toISOString());
  return token;
}

/** Single-use and time-limited. Returns the email, or null if bad/expired/spent. */
export function redeemMagicToken(db, token, now = Date.now()) {
  if (!token) return null;
  const row = db.prepare('SELECT * FROM magic_tokens WHERE token_hash = ?').get(hashToken(token));
  if (!row || row.used_at) return null;
  if (Date.parse(row.expires_at) < now) return null;
  db.prepare('UPDATE magic_tokens SET used_at = ? WHERE token_hash = ?')
    .run(new Date(now).toISOString(), row.token_hash);
  return row.email;
}

export { SESSION_COOKIE };
