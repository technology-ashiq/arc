import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { upsertUser } from './db.mjs';
import { randomCode, isReserved, ALIAS_RE } from './codes.mjs';
import { createRateLimiter } from './ratelimit.mjs';
import {
  authenticate, issueMagicToken, redeemMagicToken, mintSession,
  sessionSecret, sessionCookie, clearSessionCookie,
} from './auth.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const MAX_BODY = 64 * 1024;

function send(res, status, body, headers = {}) {
  const payload = body === undefined ? '' : JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    ...headers,
  });
  res.end(payload);
}
const fail = (res, status, error, message, headers) =>
  send(res, status, { error, message }, headers);

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) { const e = new Error('body too large'); e.status = 413; throw e; }
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error('body must be a JSON object');
    }
    return parsed;
  } catch (err) {
    const e = new Error(err.message || 'invalid JSON body');
    e.status = 400;
    throw e;
  }
}

function clientIp(req, env) {
  if (env.TRUST_PROXY === '1') {
    const fwd = req.headers['x-forwarded-for'];
    if (typeof fwd === 'string' && fwd.length) return fwd.split(',')[0].trim();
  }
  return req.socket.remoteAddress ?? 'unknown';
}

function baseUrl(req, env) {
  if (env.BASE_URL) return env.BASE_URL.replace(/\/$/, '');
  const proto = env.TRUST_PROXY === '1' && req.headers['x-forwarded-proto']
    ? String(req.headers['x-forwarded-proto']).split(',')[0]
    : 'http';
  return `${proto}://${req.headers.host ?? 'localhost'}`;
}

/** http/https only: a `javascript:` or `data:` short link is an XSS vector, not a link. */
function validateUrl(raw) {
  if (typeof raw !== 'string' || !raw.trim()) return { ok: false, message: 'url is required' };
  let parsed;
  try { parsed = new URL(raw.trim()); } catch { return { ok: false, message: 'url must be a valid absolute URL' }; }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { ok: false, message: 'url must use http or https' };
  }
  return { ok: true, value: parsed.toString() };
}

export function createApp({ db, mailer, env = process.env, now = () => Date.now() }) {
  const limiter = createRateLimiter({ limit: Number(env.RATE_LIMIT ?? 10), windowMs: 60_000, now });
  const isTest = env.APP_ENV === 'test';
  const secureCookies = env.APP_ENV === 'production';

  const findByCode = db.prepare('SELECT * FROM links WHERE code = ?');
  const insertLink = db.prepare(
    'INSERT INTO links (code, user_id, url, expires_at, created_at) VALUES (?, ?, ?, ?, ?)',
  );
  const bumpHits = db.prepare('UPDATE links SET hits = hits + 1 WHERE id = ?');
  const listForUser = db.prepare(
    'SELECT code, url, hits, expires_at FROM links WHERE user_id = ? AND deleted_at IS NULL ORDER BY id DESC',
  );
  const softDelete = db.prepare('UPDATE links SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL');

  const expired = (row, t) => row.expires_at !== null && Date.parse(row.expires_at) <= t;

  async function createLink(req, res, url) {
    const user = authenticate(req, { db, env });
    if (!user) return fail(res, 401, 'unauthorized', 'Sign in to create links.');

    const gate = limiter.take(clientIp(req, env));
    if (!gate.allowed) {
      return fail(res, 429, 'rate_limited',
        `Too many links created. Retry in ${gate.retryAfterSeconds} second(s).`,
        { 'retry-after': String(gate.retryAfterSeconds) });
    }

    const body = await readJson(req);

    const checked = validateUrl(body.url);
    if (!checked.ok) return fail(res, 400, 'invalid_url', checked.message);

    let expiresAt = null;
    if (body.expiresAt !== undefined && body.expiresAt !== null && body.expiresAt !== '') {
      const ms = Date.parse(body.expiresAt);
      if (Number.isNaN(ms)) {
        return fail(res, 400, 'invalid_expiry', 'expiresAt must be an ISO-8601 timestamp.');
      }
      if (ms <= now()) {
        return fail(res, 400, 'invalid_expiry', 'expiresAt must be in the future.');
      }
      expiresAt = new Date(ms).toISOString();
    }

    let code;
    if (body.alias !== undefined && body.alias !== null && body.alias !== '') {
      if (typeof body.alias !== 'string' || !ALIAS_RE.test(body.alias)) {
        return fail(res, 400, 'invalid_alias',
          'alias must be 3-64 characters of letters, digits, hyphen or underscore.');
      }
      if (isReserved(body.alias)) {
        return fail(res, 409, 'alias_reserved', `"${body.alias}" is reserved by snip.`);
      }
      // Deliberately checks tombstoned rows too: a deleted code is spent forever.
      if (findByCode.get(body.alias)) {
        return fail(res, 409, 'alias_taken', `"${body.alias}" is already taken.`);
      }
      code = body.alias;
    }

    const createdAt = new Date(now()).toISOString();
    if (code) {
      try {
        insertLink.run(code, user.id, checked.value, expiresAt, createdAt);
      } catch (err) {
        if (String(err.message).includes('UNIQUE')) { // lost a race with a concurrent create
          return fail(res, 409, 'alias_taken', `"${code}" is already taken.`);
        }
        throw err;
      }
    } else {
      let placed = false;
      for (let attempt = 0; attempt < 8 && !placed; attempt++) {
        code = randomCode();
        try {
          insertLink.run(code, user.id, checked.value, expiresAt, createdAt);
          placed = true;
        } catch (err) {
          if (!String(err.message).includes('UNIQUE')) throw err;
        }
      }
      if (!placed) return fail(res, 503, 'code_exhausted', 'Could not allocate a short code. Try again.');
    }

    return send(res, 201, { code, shortUrl: `${baseUrl(req, env)}/${code}` }, { location: `${baseUrl(req, env)}/${code}` });
  }

  function listLinks(req, res) {
    const user = authenticate(req, { db, env });
    if (!user) return fail(res, 401, 'unauthorized', 'Sign in to see your links.');
    const rows = listForUser.all(user.id).map((r) => ({
      code: r.code,
      url: r.url,
      hits: r.hits,
      expiresAt: r.expires_at,
    }));
    return send(res, 200, rows);
  }

  function deleteLink(req, res, code) {
    const user = authenticate(req, { db, env });
    if (!user) return fail(res, 401, 'unauthorized', 'Sign in to delete links.');

    const row = findByCode.get(code);
    // Someone else's link is not the caller's to know about, let alone delete.
    if (!row || row.user_id !== user.id) {
      return fail(res, 404, 'not_found', `No link with code "${code}".`);
    }
    if (row.deleted_at) {
      return fail(res, 410, 'gone', `The link "${code}" was already deleted.`);
    }
    softDelete.run(new Date(now()).toISOString(), row.id);
    res.writeHead(204).end();
  }

  function redirect(req, res, code) {
    const row = findByCode.get(code);
    if (!row) return fail(res, 404, 'not_found', `No link with code "${code}".`);
    if (row.deleted_at) {
      return fail(res, 410, 'gone', `The link "${code}" existed and was deleted. It will not be reused.`);
    }
    if (expired(row, now())) {
      return fail(res, 410, 'expired', `The link "${code}" expired at ${row.expires_at}.`);
    }
    bumpHits.run(row.id);
    res.writeHead(302, { location: row.url, 'cache-control': 'no-store' }).end();
  }

  async function requestMagicLink(req, res) {
    const body = await readJson(req);
    const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return fail(res, 400, 'invalid_email', 'A valid email address is required.');
    }
    const token = issueMagicToken(db, email, now());
    const link = `${baseUrl(req, env)}/api/auth/callback?token=${encodeURIComponent(token)}`;
    await mailer.send({
      to: email,
      subject: 'Your snip sign-in link',
      text: `Click to sign in to snip (valid for 15 minutes):\n\n${link}\n`,
    });
    // Never echo the token in the response: it would turn the mailbox check into a no-op.
    return send(res, 202, { sent: true, message: `If ${email} is a valid address, a sign-in link is on its way.` });
  }

  function magicCallback(req, res, url) {
    const email = redeemMagicToken(db, url.searchParams.get('token'), now());
    if (!email) {
      return fail(res, 401, 'invalid_token', 'That sign-in link is invalid, expired, or already used.');
    }
    upsertUser(db, email);
    const cookie = sessionCookie(mintSession(email, sessionSecret(env), now()), { secure: secureCookies });
    res.writeHead(302, { location: '/', 'set-cookie': cookie }).end();
  }

  async function serveIndex(res) {
    try {
      const html = await readFile(join(HERE, '..', 'public', 'index.html'));
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }).end(html);
    } catch {
      send(res, 200, { name: 'snip', docs: 'POST /api/links, GET /api/links, DELETE /api/links/:code, GET /:code' });
    }
  }

  return async function handler(req, res) {
    const url = new URL(req.url, `http://${req.headers.host ?? 'localhost'}`);
    const path = url.pathname;
    const method = req.method ?? 'GET';

    try {
      if (path === '/health') return send(res, 200, { ok: true, env: env.APP_ENV ?? 'development' });
      if (path === '/' && (method === 'GET' || method === 'HEAD')) return serveIndex(res);

      if (path === '/api/auth/magic-link' && method === 'POST') return await requestMagicLink(req, res);
      if (path === '/api/auth/callback' && method === 'GET') return magicCallback(req, res, url);
      if (path === '/api/auth/logout' && method === 'POST') {
        res.writeHead(204, { 'set-cookie': clearSessionCookie({ secure: secureCookies }) }).end();
        return;
      }
      if (path === '/api/me' && method === 'GET') {
        const user = authenticate(req, { db, env });
        return user ? send(res, 200, { email: user.email }) : fail(res, 401, 'unauthorized', 'Not signed in.');
      }

      // Test-only. In any other env this path simply does not exist.
      if (path === '/api/test/reset') {
        if (!isTest) return fail(res, 404, 'not_found', 'Unknown endpoint.');
        if (method !== 'POST') return fail(res, 405, 'method_not_allowed', 'Use POST.');
        db.exec('DELETE FROM links');
        db.exec('DELETE FROM magic_tokens');
        limiter.reset();
        if (mailer.outbox) mailer.outbox.length = 0;
        res.writeHead(204).end();
        return;
      }

      if (path === '/api/links') {
        if (method === 'POST') return await createLink(req, res, url);
        if (method === 'GET') return listLinks(req, res);
        return fail(res, 405, 'method_not_allowed', 'Use GET or POST.', { allow: 'GET, POST' });
      }

      const linkMatch = path.match(/^\/api\/links\/([^/]+)$/);
      if (linkMatch) {
        const code = decodeURIComponent(linkMatch[1]);
        if (method === 'DELETE') return deleteLink(req, res, code);
        return fail(res, 405, 'method_not_allowed', 'Use DELETE.', { allow: 'DELETE' });
      }

      if (path.startsWith('/api/')) return fail(res, 404, 'not_found', 'Unknown endpoint.');

      const codeMatch = path.match(/^\/([^/]+)$/);
      if (codeMatch && (method === 'GET' || method === 'HEAD')) {
        return redirect(req, res, decodeURIComponent(codeMatch[1]));
      }

      return fail(res, 404, 'not_found', 'Unknown path.');
    } catch (err) {
      const status = err.status ?? 500;
      if (status >= 500) console.error('[snip] unhandled error', err);
      return fail(res, status, status === 400 ? 'bad_request' : status === 413 ? 'payload_too_large' : 'internal_error',
        status >= 500 ? 'Something went wrong.' : err.message);
    }
  };
}
