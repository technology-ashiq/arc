import { randomInt } from 'node:crypto';

const ALPHABET = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no look-alikes
const CODE_LEN = 7;

export const ALIAS_RE = /^[A-Za-z0-9_-]{3,64}$/;

// Paths the router owns; an alias here would be unreachable, so it is not allowed.
export const RESERVED = new Set([
  'api', 'health', 'favicon.ico', 'robots.txt', 'assets', 'static', 'public',
  'login', 'logout', 'dashboard', 'admin',
]);

export function randomCode(len = CODE_LEN) {
  let out = '';
  for (let i = 0; i < len; i++) out += ALPHABET[randomInt(ALPHABET.length)];
  return out;
}

export function isReserved(code) {
  return RESERVED.has(code.toLowerCase());
}
