// Fixed-cost sliding window, per key (IP). Process-local: fine for a single
// node, and swappable for Redis behind the same two methods.
export function createRateLimiter({ limit = 10, windowMs = 60_000, now = Date.now } = {}) {
  const hits = new Map(); // key -> number[] (timestamps, ascending)

  return {
    limit,
    windowMs,
    /** @returns {{allowed: boolean, remaining: number, retryAfterSeconds: number}} */
    take(key) {
      const t = now();
      const cutoff = t - windowMs;
      const stamps = (hits.get(key) ?? []).filter((s) => s > cutoff);

      if (stamps.length >= limit) {
        hits.set(key, stamps);
        const msUntilFree = stamps[0] + windowMs - t;
        return {
          allowed: false,
          remaining: 0,
          retryAfterSeconds: Math.max(1, Math.ceil(msUntilFree / 1000)),
        };
      }
      stamps.push(t);
      hits.set(key, stamps);
      return { allowed: true, remaining: limit - stamps.length, retryAfterSeconds: 0 };
    },
    reset() { hits.clear(); },
  };
}
