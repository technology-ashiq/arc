import http from 'node:http';
import { openDb } from './src/db.mjs';
import { createMailer } from './src/mailer.mjs';
import { createApp } from './src/app.mjs';

const port = Number(process.env.PORT ?? 3000);
const appEnv = process.env.APP_ENV ?? 'development';

const db = openDb(process.env.DB_FILE ?? './data/snip.db');
const mailer = createMailer(process.env);
const server = http.createServer(createApp({ db, mailer, env: process.env }));

server.listen(port, () => {
  console.log(`snip listening on http://localhost:${port}  (APP_ENV=${appEnv}, mailer=${mailer.kind})`);
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    server.close(() => { db.close(); process.exit(0); });
  });
}
