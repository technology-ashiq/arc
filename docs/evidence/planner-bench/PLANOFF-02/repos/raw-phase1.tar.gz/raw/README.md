# snip

A URL shortener. Sign in with an email magic link, shorten a URL (auto code or your own
alias, with an optional expiry), and watch the hits add up on your dashboard.

## Start it (one command)

```bash
PORT=3202 APP_ENV=test node server.mjs
```

Then open <http://localhost:3202>. No install step, no build step, no external service:
storage is Node's built-in SQLite (`node:sqlite`), written to `./data/snip.db`.

For real use, run it in dev/production mode instead — the sign-in email is the only path in,
and the `X-Test-User` shim below is dead code outside `APP_ENV=test`:

```bash
APP_ENV=development node server.mjs          # sign-in links are printed to the console
SESSION_SECRET=... MAIL_API_URL=... MAIL_API_KEY=... APP_ENV=production node server.mjs
```

Requires Node >= 22.5 (for `node:sqlite`). Config lives in `.env.example`.

## Tests

```bash
npm test
```

21 tests, no network: the suite drives the real HTTP server against a real temp-file SQLite
database, and the email provider is swapped for an in-memory mailer, so nothing in the test
path touches a live third party.

## API

| Method | Path | Behaviour |
|---|---|---|
| POST | `/api/links` | `{ url, alias?, expiresAt? }` → `201 { code, shortUrl }` |
| GET | `/api/links` | `200 [{ code, url, hits, expiresAt }]` — the caller's own links only |
| DELETE | `/api/links/:code` | `204` |
| GET | `/:code` | `302` to the long URL; the hit is counted |
| POST | `/api/auth/magic-link` | `{ email }` → `202`, sign-in link emailed |
| GET | `/api/auth/callback?token=` | `302` to `/`, sets the session cookie |
| POST | `/api/auth/logout` | `204` |
| GET | `/api/me` | `200 { email }` |
| POST | `/api/test/reset` | `APP_ENV=test` only → `204`, wipes links + rate-limit state |

### Auth

- **Real path:** POST an email to `/api/auth/magic-link`. A single-use, 15-minute token is
  emailed; following it sets an HMAC-signed, HttpOnly session cookie.
- **Test shim:** when `APP_ENV=test`, `X-Test-User: someone@example.com` authenticates as
  that user and no email is sent. Any other `APP_ENV` never reads the header — the code path
  is behind an `APP_ENV === 'test'` check in `src/auth.mjs`, so it cannot be used to
  impersonate in dev or production.

### Status codes, and why

| Situation | Status |
|---|---|
| Code was never issued | `404 not_found` |
| Code was issued and then **deleted** | `410 gone` — the code is spent, not unknown, and can never be reclaimed |
| Link has passed its `expiresAt` | `410 expired` (the visit is **not** counted) |
| Alias already used by anyone, live or deleted | `409 alias_taken` |
| Alias is a reserved path (`api`, `health`, …) | `409 alias_reserved` |
| Alias malformed, url not http(s), expiry unparseable or in the past | `400` |
| Not signed in | `401 unauthorized` |
| Someone else's link (read or delete) | `404` — it is not the caller's to know about |
| 11th create in a minute from one IP | `429 rate_limited`, with `Retry-After: <seconds>` and the wait in the message |

## Design notes

- **Deletes are tombstones.** A deleted row keeps its `code` under the `UNIQUE` constraint,
  which is what lets `/:code` answer *gone* rather than *not found*, and stops a dead link
  from being resurrected by a stranger pointing it somewhere hostile.
- **Rate limiting** is a sliding window (10/min per IP by default, `RATE_LIMIT`), checked after
  authentication, and it tells the caller exactly how many seconds to wait.
- **The mailer is an interface** (`src/mailer.mjs`) with three implementations — memory (tests),
  console (dev), HTTP (production). Nothing else in the app knows how mail is sent.
- Only `http:`/`https:` destinations are accepted: a `javascript:` short link is an XSS vector.

## Layout

```
server.mjs         boot: db + mailer + app, listen on $PORT
src/app.mjs        routing, validation, all the HTTP semantics
src/auth.mjs       sessions, magic tokens, the APP_ENV=test shim
src/db.mjs         node:sqlite schema
src/ratelimit.mjs  sliding-window limiter
src/mailer.mjs     mail interface + memory/console/http impls
public/index.html  dashboard
test/              21 tests over the real server
```
