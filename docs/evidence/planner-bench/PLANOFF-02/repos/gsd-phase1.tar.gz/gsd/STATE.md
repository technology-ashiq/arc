# STATE — snip

| Phase | Status |
|---|---|
| SPEC | done — `SPEC.md` locked, 28 numbered decisions, no unresolved ambiguity |
| PLAN | done — `PLAN.md`; plan-check found 10 gaps, all folded back in before coding |
| EXECUTE | done — 5 waves, each committed |
| VERIFY | **passed** |
| SHIP | shipped |

## VERIFY — 2 parts

**1. `npm test`: 40/40 pass, 0 fail.** Runs with no network access: the app has zero runtime
dependencies, the test path always wires `ConsoleMailer`, and a guard test asserts no test file
imports a network/mail client and that `nodemailer` is only ever `await import()`ed inside the
production branch.

**2. SPEC walked line by line against the running app** (`PORT=3203 APP_ENV=test node server.mjs`):

| Req | Check | Result |
|---|---|---|
| R1 | anon → 401; `X-Test-User` signs in; ada sees 1 link, bob sees `[]` | pass |
| R1 | deleting another user's link → 404 (no ownership leak) | pass |
| R2 | created link + 1 hit → **process killed and relaunched** → `/keepme` still 302s, hits=2 | pass |
| R3 | auto code issued; alias `ant` honoured; duplicate alias → 409; alias over a deleted code → 409 | pass |
| R4 | future expiry redirects; expired → 410 `expired`, hit **not** counted; past expiry → 400 | pass |
| R5 | deleted `/ant` → **410 `{"error":"gone","message":"This link has been deleted."}"**; unknown `/zzzzzzz` → **404 `not_found`**. Gone ≠ unknown. | pass |
| R6 | creates 1–10 → 201; 11th and 12th → 429 `{"retryAfter":60}` + `Retry-After: 60` | pass |
| R7 | `npm test` green offline; no live third party in the test path | pass |
| Shim | with `APP_ENV=development`, `X-Test-User` → **401**, and `/api/test/reset` → **404** | pass |

## Notes for whoever is next
- Decisions live in `SPEC.md` (D1–D28) — read those before changing behaviour; the status codes
  in particular are deliberate, not accidental (see SPEC §6).
- The one bug VERIFY caught in my own work: the R7 guard test originally grepped test sources for
  the *word* "nodemailer" and so flagged itself. It now matches real import specifiers. A guard
  that cries wolf is worse than no guard.
- Rate-limit state is in-memory; if you run more than one process, move it to SQLite or Redis or
  the limit becomes 10/min *per process*.
