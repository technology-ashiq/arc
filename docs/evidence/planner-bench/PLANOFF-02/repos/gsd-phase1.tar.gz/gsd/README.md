# snip

A URL shortener. Sign in with an email magic link, shorten a URL, watch the hits, delete it
when you're done. Node 22, `node:sqlite`, zero runtime dependencies.

## Start it (one command)

```bash
PORT=3203 APP_ENV=test node server.mjs
```

Then: `curl -XPOST localhost:3203/api/links -H 'content-type: application/json' -H 'X-Test-User: you@example.com' -d '{"url":"https://anthropic.com"}'`

For dev/prod, drop the test env: `PORT=3203 APP_ENV=development node server.mjs` — sign-in then
goes through the real magic-link flow (the link is printed to the console by the dev mailer).

## Test

```bash
npm test        # 40 tests, no network access, no third-party services
```

## API

| Method | Path | Behaviour |
|---|---|---|
| POST | `/api/links` | `{url, alias?, expiresAt?}` → `201 {code, shortUrl}` |
| GET | `/api/links` | `200 [{code,url,hits,expiresAt}]` — your own links only |
| DELETE | `/api/links/:code` | `204` (idempotent) |
| GET | `/:code` | `302` to the long URL; the hit is counted |
| POST | `/api/auth/magic-link` | `{email}` → `200` — mints a sign-in link |
| GET | `/api/auth/callback?token=` | sets the session cookie |
| POST | `/api/test/reset` | `APP_ENV=test` only → `204`; 404 otherwise |

### Status codes mean what they say

- `404` — that code never existed.
- `410` — that code **existed and is gone**: deleted (`{"error":"gone"}`) or expired
  (`{"error":"expired"}`). A retired code is never recycled, so nobody can re-register it and
  inherit its traffic.
- `409` — the alias is taken. `429` — rate limited; `Retry-After` and `retryAfter` tell you how
  many seconds to wait. `401` — not signed in. Another user's link is `404`, never `403` (a `403`
  would confirm the code exists).

## Auth

- **Real path:** email magic link. Tokens are random 32-byte values, stored sha256-hashed,
  single-use, 15-minute TTL. Sessions are HttpOnly cookies, also hashed at rest.
- **Test shim:** when `APP_ENV=test`, `X-Test-User: <email>` authenticates as that email and no
  email is sent. When `APP_ENV` is anything else the header is **never read** — the check is
  gated on the env itself, so it cannot leak into dev or prod. There is a test for exactly that.

## Config

| Env | Default | Notes |
|---|---|---|
| `PORT` | `3000` | |
| `APP_ENV` | `development` | `test` enables the shim + reset route |
| `SNIP_DB` | `./data/snip.db` | file-backed SQLite (WAL); survives restarts |
| `BASE_URL` | `http://localhost:$PORT` | used to build `shortUrl` |
| `TRUST_PROXY` | off | when `1`, take the client IP from `X-Forwarded-For` |
| `SMTP_URL` | — | required only when `APP_ENV=production` |

Rate limit: **10 creates per minute per IP**. Attempts count, so a bad body still costs quota.
`X-Forwarded-For` is ignored unless `TRUST_PROXY=1` (otherwise the limit is trivially spoofed).

## Design notes

`SPEC.md` is the locked contract (28 numbered decisions); `PLAN.md` records the plan and the
plan-check that caught 10 gaps before any code was written; `STATE.md` records the verify result.

Known limits (v1, accepted): rate-limit state is per-process and in-memory (a restart resets the
window); no SSRF filtering on target URLs; no pagination on `GET /api/links`.
