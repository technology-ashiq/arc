import { createApp } from './src/app.mjs';

const port = Number(process.env.PORT ?? 3000);
const app = createApp({ port });

app.server.listen(port, () => {
  console.log(`snip listening on http://localhost:${port} (env=${app.env}, db=${app.dbFile})`);
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    app.server.close(() => {
      app.db.close();
      process.exit(0);
    });
  });
}
