import { test, describe, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { startApp } from './helpers.mjs';

const U = 'ada@snip.test';

describe('R6 - creating links is rate limited to 10/min per IP', () => {
  let t;
  before(async () => { t = await startApp(); });
  after(async () => { await t.stop(); });
  beforeEach(async () => { await t.call('/api/test/reset', { method: 'POST' }); });

  const make = (body = { url: 'https://example.com/rl' }, headers = {}) =>
    t.call('/api/links', { user: U, method: 'POST', body, headers });

  test('10 creates succeed; the 11th is 429 and says how long to wait', async () => {
    for (let i = 0; i < 10; i++) {
      const r = await make({ url: 'https://example.com/' + i });
      assert.equal(r.status, 201, 'create #' + (i + 1) + ' should succeed');
    }
    const over = await make({ url: 'https://example.com/11' });
    assert.equal(over.status, 429);
    assert.equal(over.json.error, 'rate_limited');

    // The caller must be told how long to wait - in the body AND the standard header.
    assert.equal(typeof over.json.retryAfter, 'number');
    assert.ok(over.json.retryAfter >= 1 && over.json.retryAfter <= 60, 'retryAfter within the window');
    assert.equal(over.headers.get('retry-after'), String(over.json.retryAfter));
    assert.match(over.json.message, /retry in \d+ second/i);
  });

  test('D22: invalid attempts still cost quota (no free retries with a bad body)', async () => {
    for (let i = 0; i < 10; i++) {
      const r = await make({ url: 'not-a-url' });
      assert.equal(r.status, 400);
    }
    const over = await make({ url: 'https://example.com/valid' });
    assert.equal(over.status, 429, 'the limit counts attempts, not just successes');
  });

  test('D19: X-Forwarded-For cannot be used to escape the limit when the proxy is untrusted', async () => {
    for (let i = 0; i < 10; i++) {
      assert.equal((await make({ url: 'https://example.com/x' + i })).status, 201);
    }
    const spoof = await make({ url: 'https://example.com/spoof' }, { 'x-forwarded-for': '9.9.9.9' });
    assert.equal(spoof.status, 429, 'a spoofed forwarded IP must not grant a fresh bucket');
  });

  test('D23: reset clears the rate-limit state', async () => {
    for (let i = 0; i < 11; i++) await make({ url: 'https://example.com/r' + i });
    await t.call('/api/test/reset', { method: 'POST' });
    assert.equal((await make({ url: 'https://example.com/after-reset' })).status, 201);
  });
});

describe('D19 - with TRUST_PROXY on, the limit is keyed per forwarded IP', () => {
  let t;
  before(async () => { t = await startApp({ trustProxy: true }); });
  after(async () => { await t.stop(); });

  test('two distinct forwarded IPs get their own buckets', async () => {
    const from = (ip, url) =>
      t.call('/api/links', { user: U, method: 'POST', body: { url }, headers: { 'x-forwarded-for': ip } });
    for (let i = 0; i < 10; i++) assert.equal((await from('1.1.1.1', 'https://a.example/' + i)).status, 201);
    assert.equal((await from('1.1.1.1', 'https://a.example/over')).status, 429);
    assert.equal((await from('2.2.2.2', 'https://b.example/first')).status, 201);
  });
});
