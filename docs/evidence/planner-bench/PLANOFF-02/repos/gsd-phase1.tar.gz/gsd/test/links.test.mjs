import { test, describe, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { startApp } from './helpers.mjs';

const U = 'ada@snip.test';
const OTHER = 'bob@snip.test';

describe('links', () => {
  let t;
  before(async () => { t = await startApp(); });
  after(async () => { await t.stop(); });
  beforeEach(async () => { await t.call('/api/test/reset', { method: 'POST' }); });

  const make = (body, user = U) => t.call('/api/links', { user, method: 'POST', body });

  test('contract: POST -> 201 {code, shortUrl}', async () => {
    const res = await make({ url: 'https://example.com/a/very/long/path?x=1' });
    assert.equal(res.status, 201);
    assert.equal(typeof res.json.code, 'string');
    assert.equal(res.json.shortUrl, 'http://short.test/' + res.json.code);
    assert.equal(res.json.code.length, 7);
  });

  test('contract: GET -> 200 [{code,url,hits,expiresAt}]', async () => {
    const { json: created } = await make({ url: 'https://example.com/x' });
    const res = await t.call('/api/links', { user: U });
    assert.equal(res.status, 200);
    assert.equal(res.json.length, 1);
    assert.deepEqual(Object.keys(res.json[0]).sort(), ['code', 'expiresAt', 'hits', 'url']);
    assert.deepEqual(res.json[0], { code: created.code, url: 'https://example.com/x', hits: 0, expiresAt: null });
  });

  test('GET /:code -> 302 to the long URL, and the hit is counted (R1/D17)', async () => {
    const { json } = await make({ url: 'https://example.com/dest' });
    const r = await t.call('/' + json.code);
    assert.equal(r.status, 302);
    assert.equal(r.headers.get('location'), 'https://example.com/dest');
    await t.call('/' + json.code);
    const list = await t.call('/api/links', { user: U });
    assert.equal(list.json[0].hits, 2);
  });

  // ---- R3
  test('R3: auto-generated codes are unique across many creates', async () => {
    const codes = new Set();
    for (let i = 0; i < 8; i++) {
      const r = await make({ url: 'https://example.com/' + i });
      assert.equal(r.status, 201);
      codes.add(r.json.code);
    }
    assert.equal(codes.size, 8);
  });

  test('R3: a custom alias is honoured', async () => {
    const r = await make({ url: 'https://example.com/docs', alias: 'docs' });
    assert.equal(r.status, 201);
    assert.equal(r.json.code, 'docs');
    assert.equal((await t.call('/docs')).headers.get('location'), 'https://example.com/docs');
  });

  test('R3: two links can never share a code or alias -> 409', async () => {
    assert.equal((await make({ url: 'https://a.example', alias: 'dup' })).status, 201);
    const again = await make({ url: 'https://b.example', alias: 'dup' });
    assert.equal(again.status, 409);
    assert.equal(again.json.error, 'alias_taken');
    // ...and not even a *different user* can take it.
    const cross = await make({ url: 'https://c.example', alias: 'dup' }, OTHER);
    assert.equal(cross.status, 409);
  });

  test('R3: an alias colliding with an existing auto-code is refused (one namespace, D7)', async () => {
    const { json } = await make({ url: 'https://example.com/auto' });
    const clash = await make({ url: 'https://evil.example', alias: json.code }, OTHER);
    assert.equal(clash.status, 409);
    assert.equal((await t.call('/' + json.code)).headers.get('location'), 'https://example.com/auto');
  });

  test('D14: the code of a DELETED link is never recycled -> 409', async () => {
    await make({ url: 'https://example.com/old', alias: 'retired' });
    assert.equal((await t.call('/api/links/retired', { user: U, method: 'DELETE' })).status, 204);
    const hijack = await make({ url: 'https://evil.example', alias: 'retired' }, OTHER);
    assert.equal(hijack.status, 409); // an attacker cannot inherit a retired code's traffic
  });

  test('D8/D9: invalid and reserved aliases are 400', async () => {
    assert.equal((await make({ url: 'https://a.example', alias: 'no' })).json.error, 'invalid_alias');
    assert.equal((await make({ url: 'https://a.example', alias: 'has space' })).json.error, 'invalid_alias');
    assert.equal((await make({ url: 'https://a.example', alias: 'a/b' })).json.error, 'invalid_alias');
    const reserved = await make({ url: 'https://a.example', alias: 'api' });
    assert.equal(reserved.status, 400);
    assert.equal(reserved.json.error, 'reserved_alias');
  });

  // ---- R4
  test('R4: a not-yet-expired link still redirects', async () => {
    const future = new Date(Date.now() + 60_000).toISOString();
    const { json } = await make({ url: 'https://example.com/soon', expiresAt: future });
    assert.equal((await t.call('/' + json.code)).status, 302);
    const list = await t.call('/api/links', { user: U });
    assert.equal(list.json[0].expiresAt, new Date(future).toISOString());
  });

  test('R4/D13: once expired it no longer redirects -> 410 expired, and the hit is NOT counted', async () => {
    const { json } = await make({ url: 'https://example.com/gone', expiresAt: new Date(Date.now() + 60_000).toISOString() });
    // Backdate the expiry rather than sleeping: deterministic, no flake.
    t.app.db.prepare('UPDATE links SET expires_at = ? WHERE code = ?').run(Date.now() - 1000, json.code);

    const r = await t.call('/' + json.code);
    assert.equal(r.status, 410);
    assert.equal(r.json.error, 'expired');

    const list = await t.call('/api/links', { user: U });
    assert.equal(list.json[0].hits, 0);            // an expired link served no redirect
    assert.equal(list.json.length, 1);             // ...but the owner can still see and delete it
  });

  test('D12: a bad or past expiresAt is a 400', async () => {
    assert.equal((await make({ url: 'https://a.example', expiresAt: 'tomorrow-ish' })).json.error, 'invalid_expires_at');
    const past = await make({ url: 'https://a.example', expiresAt: new Date(Date.now() - 60_000).toISOString() });
    assert.equal(past.status, 400);
    assert.equal(past.json.error, 'expires_at_in_past');
  });

  // ---- R5: the heart of it
  test('R5: deleted is GONE (410), never-existed is UNKNOWN (404) - and they differ', async () => {
    const { json } = await make({ url: 'https://example.com/bye', alias: 'byebye' });
    assert.equal((await t.call('/' + json.code)).status, 302);

    assert.equal((await t.call('/api/links/byebye', { user: U, method: 'DELETE' })).status, 204);

    const deleted = await t.call('/byebye');
    const neverExisted = await t.call('/nosuchcode');

    assert.equal(deleted.status, 410);
    assert.equal(deleted.json.error, 'gone');
    assert.match(deleted.json.message, /deleted/i);   // the response SAYS so

    assert.equal(neverExisted.status, 404);
    assert.equal(neverExisted.json.error, 'not_found');

    assert.notEqual(deleted.status, neverExisted.status); // gone !== unknown
  });

  test('R5/D16: a deleted link disappears from the dashboard', async () => {
    const { json } = await make({ url: 'https://example.com/bye2' });
    await t.call('/api/links/' + json.code, { user: U, method: 'DELETE' });
    assert.deepEqual((await t.call('/api/links', { user: U })).json, []);
  });

  test('D15: deleting twice is idempotent (204, 204)', async () => {
    const { json } = await make({ url: 'https://example.com/twice' });
    assert.equal((await t.call('/api/links/' + json.code, { user: U, method: 'DELETE' })).status, 204);
    assert.equal((await t.call('/api/links/' + json.code, { user: U, method: 'DELETE' })).status, 204);
  });

  test('D15: deleting an unknown code is 404', async () => {
    assert.equal((await t.call('/api/links/nope', { user: U, method: 'DELETE' })).status, 404);
  });

  // ---- D11 / D25 / D27
  test('D11: only http(s) URLs are accepted', async () => {
    for (const bad of ['javascript:alert(1)', 'data:text/html,x', 'file:///etc/passwd', 'not a url', '']) {
      const r = await make({ url: bad });
      assert.equal(r.status, 400, 'expected 400 for ' + JSON.stringify(bad));
      assert.equal(r.json.error, 'invalid_url');
    }
    assert.equal((await make({})).json.error, 'invalid_url'); // missing entirely
  });

  test('D25: malformed JSON is 400, unknown api route 404, wrong method 405', async () => {
    const bad = await t.call('/api/links', { user: U, method: 'POST', body: '{nope', headers: { 'content-type': 'application/json' } });
    assert.equal(bad.status, 400);
    assert.equal(bad.json.error, 'invalid_json');
    assert.equal((await t.call('/api/nope', { user: U })).status, 404);
    assert.equal((await t.call('/api/links', { user: U, method: 'PUT', body: {} })).status, 405);
  });

  test('D27: the dashboard lists newest first', async () => {
    await make({ url: 'https://example.com/1' });
    await make({ url: 'https://example.com/2' });
    const list = await t.call('/api/links', { user: U });
    assert.equal(list.json[0].url, 'https://example.com/2');
  });

  test('D23: reset wipes the links', async () => {
    await make({ url: 'https://example.com/wipe' });
    assert.equal((await t.call('/api/test/reset', { method: 'POST' })).status, 204);
    assert.deepEqual((await t.call('/api/links', { user: U })).json, []);
  });
});

// ---- R2
describe('R2 - links survive a restart', () => {
  test('a link created by one process instance still resolves after the DB is reopened', async () => {
    const dbFile = './data/test-restart-' + randomUUID() + '.db';

    const first = await startApp({ dbFile });
    const { json } = await first.call('/api/links', { user: U, method: 'POST', body: { url: 'https://example.com/durable', alias: 'durable' } });
    await first.call('/' + json.code);           // one hit, so we can prove counts persist too
    await new Promise((r) => first.server ? r() : r());
    await new Promise((r) => first.app.server.close(r));
    first.app.db.close();                        // full shutdown: nothing left in memory

    assert.ok(existsSync(dbFile), 'the database is a real file on disk');

    const second = await startApp({ dbFile });   // "restart"
    const r = await second.call('/durable');
    assert.equal(r.status, 302);
    assert.equal(r.headers.get('location'), 'https://example.com/durable');

    const list = await second.call('/api/links', { user: U });
    assert.equal(list.json.length, 1);
    assert.equal(list.json[0].hits, 2);          // 1 before the restart + 1 after
    await second.stop();
  });
});
