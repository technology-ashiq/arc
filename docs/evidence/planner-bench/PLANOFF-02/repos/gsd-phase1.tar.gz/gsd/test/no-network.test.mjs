import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { startApp } from './helpers.mjs';
import { makeMailer, ConsoleMailer } from '../src/mailer.mjs';

describe('R7 - the test suite runs with no network access', () => {
  test('test mode always wires the offline ConsoleMailer', () => {
    assert.ok(makeMailer('test') instanceof ConsoleMailer);
    assert.ok(makeMailer('development') instanceof ConsoleMailer);
  });

  test('the app under test never holds a network-capable mailer', async () => {
    const t = await startApp();
    assert.ok(t.app.mailer instanceof ConsoleMailer);
    await t.stop();
  });

  test('no test file imports a third-party client, and there are no runtime dependencies', () => {
    // Match real module resolution (import/require of a package), not the mere mention of a
    // name - otherwise this guard flags its own source, which is a false positive, not a leak.
    const THIRD_PARTY = /(?:from\s*|import\s*\(\s*|require\s*\(\s*)['"](nodemailer|axios|node-fetch|got|undici|superagent)['"]/;
    for (const f of readdirSync('./test')) {
      const src = readFileSync('./test/' + f, 'utf8');
      assert.doesNotMatch(src, THIRD_PARTY, f + ' must not import a mail/network client');
    }
    const pkg = JSON.parse(readFileSync('./package.json', 'utf8'));
    assert.equal(pkg.dependencies, undefined, 'snip has no runtime dependencies');
  });

  test('the SMTP transport is imported lazily, so it is never loaded in test', () => {
    const src = readFileSync('./src/mailer.mjs', 'utf8');
    assert.doesNotMatch(src, /^import .*nodemailer/m, 'nodemailer must not be imported at module top level');
    assert.match(src, /await import\('nodemailer'\)/);
  });
});
