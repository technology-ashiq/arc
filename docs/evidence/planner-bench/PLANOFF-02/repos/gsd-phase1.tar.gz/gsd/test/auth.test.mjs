import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startApp } from './helpers.mjs';
import { ConsoleMailer } from '../src/mailer.mjs';

describe('R1 - auth, and a user only ever sees their own links', () => {
  let t;
  before(async () => { t = await startApp(); });
  after(async () => { await t.stop(); });

  test('anonymous callers are rejected on every /api/links route (401)', async () => {
    assert.equal((await t.call('/api/links')).status, 401);
    assert.equal((await t.call('/api/links', { method: 'POST', body: { url: 'https://a.com' } })).status, 401);
    assert.equal((await t.call('/api/links/whatever', { method: 'DELETE' })).status, 401);
  });

  test('X-Test-User authenticates in test mode', async () => {
    const res = await t.call('/api/links', { user: 'ada@snip.test' });
    assert.equal(res.status, 200);
    assert.deepEqual(res.json, []);
  });

  test('a user sees only their own links', async () => {
    await t.call('/api/test/reset', { method: 'POST' });
    await t.call('/api/links', { user: 'ada@snip.test', method: 'POST', body: { url: 'https://ada.example' } });
    await t.call('/api/links', { user: 'bob@snip.test', method: 'POST', body: { url: 'https://bob.example' } });
    const ada = await t.call('/api/links', { user: 'ada@snip.test' });
    const bob = await t.call('/api/links', { user: 'bob@snip.test' });
    assert.equal(ada.json.length, 1);
    assert.equal(bob.json.length, 1);
    assert.equal(ada.json[0].url, 'https://ada.example');
    assert.equal(bob.json[0].url, 'https://bob.example');
  });

  test("deleting someone else's link is 404, not 403 - no ownership leak (D15)", async () => {
    const made = await t.call('/api/links', { user: 'ada@snip.test', method: 'POST', body: { url: 'https://ada.example/secret' } });
    const res = await t.call('/api/links/' + made.json.code, { user: 'bob@snip.test', method: 'DELETE' });
    assert.equal(res.status, 404);
    assert.equal((await t.call('/' + made.json.code)).status, 302);
  });

  test('identity is normalised - case/space insensitive (D1)', async () => {
    await t.call('/api/test/reset', { method: 'POST' });
    await t.call('/api/links', { user: 'Cyd@Snip.Test', method: 'POST', body: { url: 'https://cyd.example' } });
    const res = await t.call('/api/links', { user: '  cyd@snip.test ' });
    assert.equal(res.json.length, 1);
  });
});

describe('R7/D3/D4 - the real magic-link path works entirely offline', () => {
  let t;
  before(async () => { t = await startApp({ mailer: new ConsoleMailer({ quiet: true }) }); });
  after(async () => { await t.stop(); });

  test('mint -> callback -> session cookie -> authenticated, with no network', async () => {
    const sent = await t.call('/api/auth/magic-link', { method: 'POST', body: { email: 'zoe@snip.test' } });
    assert.equal(sent.status, 200);
    assert.equal(t.app.mailer.sent.length, 1);
    assert.equal(t.app.mailer.sent[0].to, 'zoe@snip.test');

    const token = new URL(t.app.mailer.sent[0].link).searchParams.get('token');
    const cb = await t.call('/api/auth/callback?token=' + token);
    assert.equal(cb.status, 200);
    const cookie = cb.headers.get('set-cookie');
    assert.match(cookie, /snip_session=/);
    assert.match(cookie, /HttpOnly/);

    const jar = cookie.split(';')[0];
    const mine = await t.call('/api/links', { headers: { cookie: jar } });
    assert.equal(mine.status, 200);
  });

  test('a magic token is single-use', async () => {
    await t.call('/api/auth/magic-link', { method: 'POST', body: { email: 'eve@snip.test' } });
    const token = new URL(t.app.mailer.sent.at(-1).link).searchParams.get('token');
    assert.equal((await t.call('/api/auth/callback?token=' + token)).status, 200);
    assert.equal((await t.call('/api/auth/callback?token=' + token)).status, 400);
  });

  test('a garbage token is refused', async () => {
    assert.equal((await t.call('/api/auth/callback?token=nope')).status, 400);
  });
});

describe('D2/D23 - outside test mode the shim does not exist', () => {
  let t;
  before(async () => { t = await startApp({ env: 'development' }); });
  after(async () => { await t.stop(); });

  test('X-Test-User is ignored completely when APP_ENV is not test', async () => {
    assert.equal((await t.call('/api/links', { user: 'attacker@snip.test' })).status, 401);
    const post = await t.call('/api/links', { user: 'attacker@snip.test', method: 'POST', body: { url: 'https://x.example' } });
    assert.equal(post.status, 401);
  });

  test('/api/test/reset does not exist outside test mode (404)', async () => {
    assert.equal((await t.call('/api/test/reset', { method: 'POST' })).status, 404);
  });
});
