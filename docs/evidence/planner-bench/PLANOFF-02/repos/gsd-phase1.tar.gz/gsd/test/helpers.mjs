import { randomUUID } from 'node:crypto';
import { rmSync } from 'node:fs';
import { createApp } from '../src/app.mjs';

/** Boot the app on an ephemeral port with a throwaway file-backed DB. No network, ever. */
export async function startApp(opts = {}) {
  const dbFile = opts.dbFile ?? `./data/test-${randomUUID()}.db`;
  const app = createApp({ env: 'test', dbFile, baseUrl: 'http://short.test', ...opts });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const port = app.server.address().port;
  const origin = `http://127.0.0.1:${port}`;

  const call = async (path, { method = 'GET', user, body, headers = {} } = {}) => {
    const h = { ...headers };
    if (user) h['x-test-user'] = user;
    if (body !== undefined) h['content-type'] = 'application/json';
    const res = await fetch(origin + path, {
      method,
      headers: h,
      body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)),
      redirect: 'manual',
    });
    let json = null;
    const text = await res.text();
    if (text) { try { json = JSON.parse(text); } catch { json = text; } }
    return { status: res.status, json, headers: res.headers };
  };

  const stop = async () => {
    await new Promise((r) => app.server.close(r));
    app.db.close();
    for (const suffix of ['', '-wal', '-shm']) {
      try { rmSync(dbFile + suffix, { force: true }); } catch {}
    }
  };

  return { app, origin, call, stop, dbFile };
}
