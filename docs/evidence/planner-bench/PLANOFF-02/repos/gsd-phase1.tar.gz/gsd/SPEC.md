# SPEC — snip (URL shortener)

Status: **LOCKED** (v1). Changes require a new numbered decision below.

## 1. Product

A signed-in user creates short links from long URLs. Anyone visiting a short link is
redirected and the visit is counted. The owner sees their own links with hit counts and
can delete them.

## 2. Requirements (verbatim, numbered)

- R1 Users sign in with an email magic link. A user only ever sees their own links.
- R2 Links are stored in SQLite and survive a restart.
- R3 Short codes are auto-generated; a user may request a custom alias. Two links can never
     share a code or alias.
- R4 A link may have an expiry time. Once expired it no longer redirects.
- R5 A user may delete a link. A deleted link no longer redirects, and the response must
     distinguish *gone* from *never existed*.
- R6 Creating links is rate limited to 10/min per IP; over the limit the caller is told how
     long to wait.
- R7 The test suite runs with no network access; nothing in the test path calls a live
     third-party service (incl. the email provider).

## 3. API contract (fixed)

| Method | Path | Behaviour |
|---|---|---|
| POST | `/api/links` | `{url, alias?, expiresAt?}` → `201 {code, shortUrl}` |
| GET | `/api/links` | `200 [{code,url,hits,expiresAt}]` — caller's own only |
| DELETE | `/api/links/:code` | `204` |
| GET | `/:code` | `302` to long URL, hit counted |
| POST | `/api/test/reset` | test mode only → `204`, wipes links + rate-limit state |

## 4. Ambiguity audit + DECISIONS (binding)

Scored each requirement on: edge-case behaviour / error semantics / data model / external deps.
Every material ambiguity below is resolved. No unresolved ambiguity remains.

### Auth & identity
- **D1** Identity = the email string, lowercased and trimmed. No separate user table is needed
  for ownership, but we keep a `users` table (id, email, created_at) so magic-link tokens have
  a real subject. Ownership column on `links` is `owner_email`.
- **D2** Test shim: `APP_ENV=test` ⇒ header `X-Test-User: <email>` authenticates as that email.
  When `APP_ENV !== 'test'` the header is **read but never consulted** — parsing is gated on the
  env check itself, so it cannot leak. Unauthenticated ⇒ **401** on every `/api/links*` route.
- **D3** Real path (dev/prod): `POST /api/auth/magic-link {email}` mints a random 32-byte token
  (sha256-hashed at rest, 15-min TTL, single use) and hands it to a **mailer interface**.
  `GET /api/auth/callback?token=...` consumes the token and sets an HTTP-only session cookie
  (`snip_session`, 30-day TTL, sha256-hashed at rest).
- **D4** Mailer is an injected dependency with two impls: `ConsoleMailer` (dev/test — writes to
  stdout, **never** touches the network) and `SmtpMailer` (prod, lazy-imports nodemailer only
  when `APP_ENV=production`). Test path uses ConsoleMailer ⇒ R7 satisfied by construction.
  Auth tests exercise the token flow directly against the API; no SMTP, no network.
- **D5** Session cookie auth also works in test mode; the `X-Test-User` header takes precedence
  when present and `APP_ENV=test`.

### Codes & aliases
- **D6** Auto code: 7 chars from a base58-ish alphabet (`23456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ`,
  no 0/O/1/l/I), from `crypto.randomInt`. On collision, retry up to 5×, then **500**.
- **D7** Codes and aliases live in **one namespace**: a single `code` column with a `UNIQUE`
  constraint. An alias is simply a user-chosen `code`. This makes R3 ("never share a code or
  alias") enforceable by the database, not by application luck.
- **D8** Alias validation: `^[A-Za-z0-9_-]{3,64}$`. Case-**sensitive** (URLs are). Invalid alias
  ⇒ **400** `{error:"invalid_alias"}`.
- **D9** Reserved aliases (would shadow real routes): `api`, `health`, `favicon.ico`, `robots.txt`,
  `_`, `admin`. Requesting one ⇒ **400** `{error:"reserved_alias"}`.
- **D10** Alias already taken (by anyone, incl. by a **deleted** link — see D14) ⇒ **409**
  `{error:"alias_taken"}`. 409 is the true code: the request is valid, the state conflicts.

### URL validation
- **D11** `url` must parse via `new URL()` and have protocol `http:` or `https:`. Anything else
  (`javascript:`, `data:`, `file:`, garbage, missing) ⇒ **400** `{error:"invalid_url"}`.
  Max length 2048. No SSRF/loopback filtering in v1 (out of scope; noted as a known limit).

### Expiry
- **D12** `expiresAt` is optional ISO-8601. Unparseable ⇒ **400** `{error:"invalid_expires_at"}`.
  A timestamp in the **past** ⇒ **400** `{error:"expires_at_in_past"}` (creating an already-dead
  link is a client mistake, not a valid state). Stored as epoch-ms INTEGER; returned as ISO-8601
  or `null`.
- **D13** Expiry is checked at **redirect time**: `now >= expires_at` ⇒ **410 Gone**
  `{error:"expired"}`, and the hit is **not** counted (an expired link served no redirect).
  Expired links still appear in `GET /api/links` (the owner must be able to see and delete them).

### Deletion — R5, the one that matters
- **D14** Delete is a **soft delete**: `deleted_at` is set; the row and its `code` remain, so the
  code stays reserved forever (an attacker cannot re-register a retired code and hijack its
  traffic). Distinct outcomes on `GET /:code`:
  - never existed → **404** `{error:"not_found"}`
  - existed, deleted → **410** `{error:"gone", message:"This link has been deleted."}`
  - existed, expired → **410** `{error:"expired"}`
  410 Gone is exactly the HTTP semantic for "was here, deliberately removed" — that is the
  status that is *true*, per the errors rule.
- **D15** `DELETE /api/links/:code`: owner ⇒ **204**. Already-deleted own link ⇒ **204**
  (idempotent). Someone else's link ⇒ **404** (not 403 — revealing that a code exists but
  belongs to another user is an ownership leak; to a non-owner the resource is not found).
  Unknown code ⇒ **404**. Not signed in ⇒ **401**.
- **D16** Deleted links are excluded from `GET /api/links`.

### Hits
- **D17** A hit is counted only when a 302 is actually served (not on 404/410). Counted with a
  single atomic `UPDATE links SET hits = hits + 1`.

### Rate limiting — R6
- **D18** Scope: `POST /api/links` only (creation). Reads, redirects and deletes are not limited.
- **D19** Key: client IP. Behind a proxy, the **left-most** entry of `X-Forwarded-For` is used
  only when `TRUST_PROXY=1`; otherwise the raw socket address. Default: do not trust the header
  (spoofable ⇒ a trivial limit bypass).
- **D20** Algorithm: fixed 60s window, in-memory `Map<ip, {count, windowStart}>`, swept lazily.
  Simple and dependency-free; a restart resets the window (acceptable, documented).
- **D21** The 11th create in a window ⇒ **429** `{error:"rate_limited", retryAfter:<seconds>}`
  plus a `Retry-After: <seconds>` header. `retryAfter` = whole seconds until the window ends,
  minimum 1 (never advertise "retry in 0s").
- **D22** The limit counts *attempts*, incremented before validation — otherwise an attacker
  gets unlimited free tries with a bad body.

### Test-mode reset
- **D23** `POST /api/test/reset` requires `APP_ENV=test`. Otherwise **404** (not 403 — the route
  does not exist outside test mode, and its existence should not be advertised).
  Wipes `links`, `users`, `magic_tokens`, `sessions`, and clears the rate-limit map. → **204**.

### Misc / errors
- **D24** `shortUrl` = `${BASE_URL}/${code}`; `BASE_URL` defaults to `http://localhost:${PORT}`.
- **D25** Bodies must be JSON; malformed JSON ⇒ **400** `{error:"invalid_json"}`. Body > 64 KB ⇒
  **413**. Unknown route ⇒ **404**. Wrong method on a known path ⇒ **405**.
- **D26** All errors are JSON `{error: string, ...}`. `GET /:code` errors are also JSON.
- **D27** `GET /api/links` is ordered newest-first (`created_at DESC`).
- **D28** DB file `./data/snip.db`, WAL mode, created on boot; schema applied idempotently.

## 5. Data model (final)

links(id PK, code TEXT UNIQUE NOT NULL, url TEXT NOT NULL, owner_email TEXT NOT NULL,
      hits INTEGER NOT NULL DEFAULT 0, expires_at INTEGER NULL, deleted_at INTEGER NULL,
      created_at INTEGER NOT NULL)
users(id PK, email TEXT UNIQUE NOT NULL, created_at INTEGER NOT NULL)
magic_tokens(token_hash TEXT PK, email TEXT NOT NULL, expires_at INTEGER NOT NULL, used_at INTEGER NULL)
sessions(token_hash TEXT PK, email TEXT NOT NULL, expires_at INTEGER NOT NULL)
idx: links(owner_email, created_at DESC)

## 6. Status codes — the truth table

| Situation | Code |
|---|---|
| created | 201 |
| listed / deleted | 200 / 204 |
| redirect | 302 |
| bad url / alias / expiresAt / json | 400 |
| not signed in | 401 |
| unknown code, or another user's code | 404 |
| method not allowed | 405 |
| alias taken | 409 |
| deleted link, expired link | 410 |
| body too large | 413 |
| rate limited | 429 (+ Retry-After) |
| code-generation exhausted | 500 |

## 7. Definition of done
App starts with `PORT=3203 APP_ENV=test node server.mjs`; `npm test` green with no network;
README gives a one-command start.

## 8. Known limits (v1, accepted)
Rate-limit state is per-process and in-memory. No SSRF filtering on target URLs.
No pagination on `GET /api/links`.
