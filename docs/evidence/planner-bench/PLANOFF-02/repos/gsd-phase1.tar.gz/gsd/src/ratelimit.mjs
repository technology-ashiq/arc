/** D18-D22 — fixed 60s window, 10 creates per IP. In-memory, per process. */
export class RateLimiter {
  constructor({ limit = 10, windowMs = 60_000, now = Date.now } = {}) {
    this.limit = limit;
    this.windowMs = windowMs;
    this.now = now;
    this.buckets = new Map();
  }

  /** Counts the attempt, then reports. @returns {{allowed:boolean, retryAfter:number}} */
  hit(key) {
    const t = this.now();
    let b = this.buckets.get(key);
    if (!b || t - b.windowStart >= this.windowMs) {
      b = { count: 0, windowStart: t };
      this.buckets.set(key, b);
    }
    b.count += 1; // D22: attempts are counted before validation, so bad bodies cost quota too.
    if (b.count <= this.limit) return { allowed: true, retryAfter: 0 };
    const msLeft = b.windowStart + this.windowMs - t;
    // D21: never advertise "retry in 0 seconds".
    return { allowed: false, retryAfter: Math.max(1, Math.ceil(msLeft / 1000)) };
  }

  reset() {
    this.buckets.clear();
  }
}
