import { randomBytes, createHash } from 'node:crypto';

const MAGIC_TTL_MS = 15 * 60_000;
const SESSION_TTL_MS = 30 * 24 * 60 * 60_000;
export const SESSION_COOKIE = 'snip_session';

const sha256 = (s) => createHash('sha256').update(s).digest('hex');
export const normalizeEmail = (e) => String(e).trim().toLowerCase();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const isEmail = (e) => typeof e === 'string' && EMAIL_RE.test(e.trim());

function ensureUser(db, email) {
  db.prepare('INSERT OR IGNORE INTO users (email, created_at) VALUES (?, ?)').run(email, Date.now());
  return email;
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

/**
 * D2 — identify the caller, or null.
 * The X-Test-User shim is gated on env === 'test' at the top: outside test mode the header
 * is never even read, so it cannot possibly authenticate anyone.
 */
export function authenticate(req, { db, env }) {
  if (env === 'test') {
    const raw = req.headers['x-test-user'];
    if (typeof raw === 'string' && raw.trim() !== '') {
      const email = normalizeEmail(raw);
      return ensureUser(db, email);
    }
  }
  const token = parseCookies(req.headers.cookie)[SESSION_COOKIE];
  if (!token) return null;
  const row = db
    .prepare('SELECT email, expires_at FROM sessions WHERE token_hash = ?')
    .get(sha256(token));
  if (!row) return null;
  if (Date.now() >= row.expires_at) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
    return null;
  }
  return row.email;
}

/** D3 — mint a single-use magic token (stored hashed). */
export function mintMagicToken(db, emailRaw) {
  const email = normalizeEmail(emailRaw);
  ensureUser(db, email);
  const token = randomBytes(32).toString('base64url');
  db.prepare(
    'INSERT INTO magic_tokens (token_hash, email, expires_at, used_at) VALUES (?, ?, ?, NULL)',
  ).run(sha256(token), email, Date.now() + MAGIC_TTL_MS);
  return token;
}

/** D3 — consume a magic token and open a session. @returns {{sessionToken,email}|null} */
export function consumeMagicToken(db, token) {
  if (typeof token !== 'string' || token === '') return null;
  const hash = sha256(token);
  const row = db
    .prepare('SELECT email, expires_at, used_at FROM magic_tokens WHERE token_hash = ?')
    .get(hash);
  if (!row || row.used_at !== null || Date.now() >= row.expires_at) return null;
  db.prepare('UPDATE magic_tokens SET used_at = ? WHERE token_hash = ?').run(Date.now(), hash);

  const sessionToken = randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions (token_hash, email, expires_at) VALUES (?, ?, ?)').run(
    sha256(sessionToken),
    row.email,
    Date.now() + SESSION_TTL_MS,
  );
  return { sessionToken, email: row.email };
}

export function sessionCookie(token) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_TTL_MS / 1000}`;
}
