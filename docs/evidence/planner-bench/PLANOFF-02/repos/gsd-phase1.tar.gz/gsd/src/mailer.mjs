/**
 * D4 — the mailer is an interface with an offline fake and a real impl.
 * Nothing in the test path may touch the network, so tests get ConsoleMailer,
 * which only records. SmtpMailer lazily imports its transport in production only.
 */
export class ConsoleMailer {
  constructor({ quiet = false } = {}) {
    this.sent = [];
    this.quiet = quiet;
  }
  async sendMagicLink({ to, link }) {
    this.sent.push({ to, link });
    if (!this.quiet) console.log(`[mailer] magic link for ${to}: ${link}`);
    return { delivered: true, transport: 'console' };
  }
}

export class SmtpMailer {
  constructor({ url }) {
    this.url = url;
    this.sent = [];
  }
  async sendMagicLink({ to, link }) {
    // Imported lazily: never loaded, never dialled, outside production.
    const { createTransport } = await import('nodemailer');
    const t = createTransport(this.url);
    await t.sendMail({
      to,
      from: process.env.MAIL_FROM ?? 'no-reply@snip.local',
      subject: 'Your snip sign-in link',
      text: `Sign in: ${link}`,
    });
    return { delivered: true, transport: 'smtp' };
  }
}

export function makeMailer(env) {
  if (env === 'production') {
    if (!process.env.SMTP_URL) throw new Error('SMTP_URL is required when APP_ENV=production');
    return new SmtpMailer({ url: process.env.SMTP_URL });
  }
  return new ConsoleMailer({ quiet: env === 'test' });
}
