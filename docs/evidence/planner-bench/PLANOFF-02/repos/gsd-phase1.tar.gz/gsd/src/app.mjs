import http from 'node:http';
import { openDb, wipe } from './db.mjs';
import { makeMailer } from './mailer.mjs';
import { RateLimiter } from './ratelimit.mjs';
import { authenticate, mintMagicToken, consumeMagicToken, sessionCookie, isEmail } from './auth.mjs';
import { AppError, createLink, listLinks, deleteLink, resolve } from './links.mjs';

const MAX_BODY = 64 * 1024; // D25

function send(res, status, body, headers = {}) {
  const payload = body === undefined ? '' : JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    ...headers,
  });
  res.end(payload);
}

function fail(res, err) {
  if (err instanceof AppError) return send(res, err.status, { error: err.code, ...err.extra });
  console.error('[snip] unhandled', err);
  return send(res, 500, { error: 'internal_error' });
}

/** D25 - JSON only, size-capped. */
function readJson(req) {
  return new Promise((ok, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new AppError(413, 'payload_too_large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('error', reject);
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (raw.trim() === '') return ok({});
      try {
        const parsed = JSON.parse(raw);
        if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
          return reject(new AppError(400, 'invalid_json'));
        }
        ok(parsed);
      } catch {
        reject(new AppError(400, 'invalid_json'));
      }
    });
  });
}

/** D19 - the forwarded header is believed only when we are told to trust the proxy. */
function clientIp(req, trustProxy) {
  if (trustProxy) {
    const xff = req.headers['x-forwarded-for'];
    if (typeof xff === 'string' && xff.trim() !== '') return xff.split(',')[0].trim();
  }
  return req.socket.remoteAddress ?? 'unknown';
}

export function createApp(options = {}) {
  const env = options.env ?? process.env.APP_ENV ?? 'development';
  const dbFile = options.dbFile ?? process.env.SNIP_DB ?? './data/snip.db';
  const port = options.port ?? process.env.PORT ?? 3000;
  const baseUrl = (options.baseUrl ?? process.env.BASE_URL ?? `http://localhost:${port}`).replace(/\/$/, '');
  const trustProxy = options.trustProxy ?? process.env.TRUST_PROXY === '1';

  const db = openDb(dbFile);
  const mailer = options.mailer ?? makeMailer(env);
  const limiter = new RateLimiter();
  const isTest = env === 'test';

  const requireUser = (req) => {
    const email = authenticate(req, { db, env });
    if (!email) throw new AppError(401, 'unauthorized');
    return email;
  };

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, baseUrl);
      const path = url.pathname;
      const method = req.method ?? 'GET';

      if (path === '/health') return send(res, 200, { ok: true, env });

      // test-mode reset (D23): outside test mode this route does not exist at all.
      if (path === '/api/test/reset') {
        if (!isTest) return send(res, 404, { error: 'not_found' });
        if (method !== 'POST') return send(res, 405, { error: 'method_not_allowed' });
        wipe(db);
        limiter.reset();
        res.writeHead(204).end();
        return;
      }

      // magic-link sign-in (D3): the real path in dev/prod.
      if (path === '/api/auth/magic-link') {
        if (method !== 'POST') return send(res, 405, { error: 'method_not_allowed' });
        const body = await readJson(req);
        if (!isEmail(body.email)) return send(res, 400, { error: 'invalid_email' });
        const token = mintMagicToken(db, body.email);
        await mailer.sendMagicLink({ to: body.email, link: `${baseUrl}/api/auth/callback?token=${token}` });
        return send(res, 200, { sent: true });
      }

      if (path === '/api/auth/callback') {
        if (method !== 'GET') return send(res, 405, { error: 'method_not_allowed' });
        const session = consumeMagicToken(db, url.searchParams.get('token'));
        if (!session) return send(res, 400, { error: 'invalid_or_expired_token' });
        return send(res, 200, { email: session.email }, { 'set-cookie': sessionCookie(session.sessionToken) });
      }

      if (path === '/api/links') {
        if (method === 'POST') {
          const owner = requireUser(req);
          // D22: the attempt is counted before the body is validated.
          const { allowed, retryAfter } = limiter.hit(clientIp(req, trustProxy));
          if (!allowed) {
            return send(
              res,
              429,
              {
                error: 'rate_limited',
                retryAfter,
                message: `Too many links created. Retry in ${retryAfter} second${retryAfter === 1 ? '' : 's'}.`,
              },
              { 'retry-after': String(retryAfter) },
            );
          }
          const body = await readJson(req);
          const created = createLink(db, {
            owner,
            url: body.url,
            alias: body.alias,
            expiresAt: body.expiresAt,
            baseUrl,
          });
          return send(res, 201, created);
        }
        if (method === 'GET') {
          const owner = requireUser(req);
          return send(res, 200, listLinks(db, owner));
        }
        return send(res, 405, { error: 'method_not_allowed' });
      }

      const single = path.match(/^\/api\/links\/([^/]+)$/);
      if (single) {
        if (method !== 'DELETE') return send(res, 405, { error: 'method_not_allowed' });
        const owner = requireUser(req);
        deleteLink(db, owner, decodeURIComponent(single[1]));
        res.writeHead(204).end();
        return;
      }

      if (path.startsWith('/api/')) return send(res, 404, { error: 'not_found' });

      const hit = path.match(/^\/([^/]+)$/);
      if (hit && method === 'GET') {
        const target = resolve(db, decodeURIComponent(hit[1]));
        res.writeHead(302, { location: target, 'cache-control': 'no-store' });
        res.end();
        return;
      }

      return send(res, 404, { error: 'not_found' });
    } catch (err) {
      fail(res, err);
    }
  });

  return { server, db, mailer, limiter, env, baseUrl, dbFile };
}
