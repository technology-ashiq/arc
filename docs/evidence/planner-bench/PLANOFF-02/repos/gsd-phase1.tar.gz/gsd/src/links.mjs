import { randomInt } from 'node:crypto';

// D6 — no look-alike glyphs (0/O/1/l/I).
const ALPHABET = '23456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
const CODE_LEN = 7;
const MAX_CODE_TRIES = 5;

const ALIAS_RE = /^[A-Za-z0-9_-]{3,64}$/; // D8
const RESERVED = new Set(['api', 'health', 'favicon.ico', 'robots.txt', '_', 'admin']); // D9
const MAX_URL_LEN = 2048;

export class AppError extends Error {
  constructor(status, code, extra = {}) {
    super(code);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

const isUniqueViolation = (e) => /UNIQUE constraint failed/i.test(String(e?.message));

function randomCode() {
  let s = '';
  for (let i = 0; i < CODE_LEN; i++) s += ALPHABET[randomInt(ALPHABET.length)];
  return s;
}

/** D11 */
function validateUrl(url) {
  if (typeof url !== 'string' || url.trim() === '') throw new AppError(400, 'invalid_url');
  if (url.length > MAX_URL_LEN) throw new AppError(400, 'invalid_url');
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new AppError(400, 'invalid_url');
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new AppError(400, 'invalid_url');
  }
  return url;
}

/** D8, D9 */
function validateAlias(alias) {
  if (alias === undefined || alias === null || alias === '') return null;
  if (typeof alias !== 'string' || !ALIAS_RE.test(alias)) throw new AppError(400, 'invalid_alias');
  if (RESERVED.has(alias.toLowerCase())) throw new AppError(400, 'reserved_alias');
  return alias;
}

/** D12 */
function validateExpiresAt(value, now) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string') throw new AppError(400, 'invalid_expires_at');
  const ms = Date.parse(value);
  if (Number.isNaN(ms)) throw new AppError(400, 'invalid_expires_at');
  if (ms <= now) throw new AppError(400, 'expires_at_in_past');
  return ms;
}

const iso = (ms) => (ms === null || ms === undefined ? null : new Date(ms).toISOString());

/** D3/D7/D10 — an alias is just a user-chosen code; UNIQUE(code) enforces R3 in the DB. */
export function createLink(db, { owner, url, alias, expiresAt, baseUrl, now = Date.now() }) {
  const safeUrl = validateUrl(url);
  const wanted = validateAlias(alias);
  const expiresMs = validateExpiresAt(expiresAt, now);

  const insert = db.prepare(
    'INSERT INTO links (code, url, owner_email, hits, expires_at, deleted_at, created_at) VALUES (?, ?, ?, 0, ?, NULL, ?)',
  );

  if (wanted !== null) {
    try {
      insert.run(wanted, safeUrl, owner, expiresMs, now);
    } catch (e) {
      // Covers a taken alias AND a taken auto-code AND the code of a soft-deleted link (D14):
      // codes are never recycled.
      if (isUniqueViolation(e)) throw new AppError(409, 'alias_taken');
      throw e;
    }
    return { code: wanted, shortUrl: `${baseUrl}/${wanted}` };
  }

  for (let i = 0; i < MAX_CODE_TRIES; i++) {
    const code = randomCode();
    try {
      insert.run(code, safeUrl, owner, expiresMs, now);
      return { code, shortUrl: `${baseUrl}/${code}` };
    } catch (e) {
      if (isUniqueViolation(e)) continue; // D6: collide, retry
      throw e;
    }
  }
  throw new AppError(500, 'code_generation_failed');
}

/** D16, D27 — the caller's own, live links, newest first. Expired ones still show (D13). */
export function listLinks(db, owner) {
  const rows = db
    .prepare(
      'SELECT code, url, hits, expires_at FROM links WHERE owner_email = ? AND deleted_at IS NULL ORDER BY created_at DESC, id DESC',
    )
    .all(owner);
  return rows.map((r) => ({
    code: r.code,
    url: r.url,
    hits: r.hits,
    expiresAt: iso(r.expires_at),
  }));
}

/** D15 — soft delete; idempotent; another user's link is simply not found. */
export function deleteLink(db, owner, code, now = Date.now()) {
  const row = db.prepare('SELECT id, owner_email, deleted_at FROM links WHERE code = ?').get(code);
  if (!row || row.owner_email !== owner) throw new AppError(404, 'not_found');
  if (row.deleted_at === null) {
    db.prepare('UPDATE links SET deleted_at = ? WHERE id = ?').run(now, row.id);
  }
  return true;
}

/**
 * D13, D14, D17 — resolve a code for redirect.
 * Distinguishes never-existed (404) from deleted (410 gone) from expired (410 expired),
 * and only counts a hit when a redirect is actually served.
 */
export function resolve(db, code, now = Date.now()) {
  const row = db
    .prepare('SELECT id, url, expires_at, deleted_at FROM links WHERE code = ?')
    .get(code);
  if (!row) throw new AppError(404, 'not_found');
  if (row.deleted_at !== null) {
    throw new AppError(410, 'gone', { message: 'This link has been deleted.' });
  }
  if (row.expires_at !== null && now >= row.expires_at) {
    throw new AppError(410, 'expired', { message: 'This link has expired.' });
  }
  db.prepare('UPDATE links SET hits = hits + 1 WHERE id = ?').run(row.id);
  return row.url;
}
