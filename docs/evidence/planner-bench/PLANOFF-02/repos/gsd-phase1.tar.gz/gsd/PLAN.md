# PLAN — snip

Derived from the locked SPEC. Waves are committed independently.

## Files
- `server.mjs`        — entry: env, wiring, `http.createServer`, listen on `process.env.PORT`.
- `src/db.mjs`        — `node:sqlite` DatabaseSync, schema bootstrap (D28), WAL.
- `src/mailer.mjs`    — `ConsoleMailer` / `SmtpMailer` (D4). Network only in production.
- `src/auth.mjs`      — magic-link mint/consume, sessions, `authenticate(req)` (D1-D5).
- `src/ratelimit.mjs` — fixed-window limiter + `reset()` (D18-D22).
- `src/links.mjs`     — create/list/delete/resolve; code gen (D6-D17).
- `src/http.mjs`      — router, JSON body parse (D25), error envelope (D26).
- `test/*.test.mjs`   — node:test, boots the app on an ephemeral port. No network.
- `README.md`, `STATE.md`.

## Waves
1. **W1 skeleton+db** — package.json (`"test": "node --test test/"`), db.mjs, schema, health.
2. **W2 auth** — users/magic_tokens/sessions, test shim gated on `APP_ENV==='test'` (D2),
   ConsoleMailer. 401 on all `/api/links*` when anonymous.
3. **W3 links** — POST/GET/DELETE + `GET /:code`. Code gen, alias validation, reserved list,
   UNIQUE-violation → 409, expiry, soft delete, hits.
4. **W4 ratelimit** — 10/min/IP on POST only, Retry-After + retryAfter seconds.
5. **W5 tests** — one test per SPEC requirement + per status row in §6 truth table.
6. **W6 verify+docs** — README, STATE.md, run `npm test`, walk SPEC line by line.

## Test matrix (maps to SPEC)
- R1: anon 401; user A cannot see/delete user B's link (404); magic-link mint→callback→cookie works offline.
- R2: create → close DB handle / re-open → link still resolves (restart survival).
- R3: auto code unique; alias honoured; duplicate alias 409; alias colliding with an auto code 409;
  alias of a *deleted* link still 409 (code never recycled).
- R4: unexpired redirects 302; expired → 410 `expired`, hits NOT incremented; past expiresAt → 400.
- R5: delete → 204; then `GET /:code` → **410 gone**, and an unknown code → **404 not_found**
  (the two are asserted to differ — this is the heart of R5).
- R6: 10 creates ok, 11th → 429 with `retryAfter` ≥ 1 and a `Retry-After` header.
- R7: tests never import nodemailer / never open a socket to a third party (ConsoleMailer only).
- Contract: 201 shape `{code,shortUrl}`; list shape `{code,url,hits,expiresAt}`; 302 Location.
- Misc: invalid url 400, bad json 400, unknown route 404, reset 204 + wipes.

---

## PLAN-CHECK (self-review against SPEC — round 1)

Re-read the SPEC line by line against the plan above. Gaps found:

1. **D2 negative case untested.** Plan tests the shim in test mode but never asserts that
   `X-Test-User` is *ignored* when `APP_ENV!=='test'`. That is the security half of the
   requirement. → FIX: add a test that boots a **second app instance with `APP_ENV=dev`** and
   asserts `X-Test-User` yields **401**.
2. **D23 not covered.** `/api/test/reset` must 404 outside test mode. → FIX: assert in the same
   dev-mode instance.
3. **D19 (proxy trust) not covered.** → FIX: test that `X-Forwarded-For` does NOT split the
   rate-limit bucket when `TRUST_PROXY` is unset.
4. **D22 not covered.** Rate limit must count invalid attempts too. → FIX: test that 10 *bad*
   bodies still trigger 429 on the 11th.
5. **D13 "hit not counted on expiry"** was in the matrix but had no assertion of the hits value
   via `GET /api/links`. → FIX: assert `hits === 0` after hitting an expired link.
6. **D9 reserved aliases** absent from the matrix. → FIX: add `alias:"api"` → 400.
7. **D15 idempotent double-delete** absent. → FIX: delete twice → 204, 204.
8. **D25 405** absent. → FIX: assert a wrong method on `/api/links` → 405.
9. **Ephemeral-port testing conflicts with the fixed-port DoD.** The app must start with
   `PORT=3203`, but tests need isolation. → FIX: factor `createApp({env})` returning an unlistened
   server; `server.mjs` is the only thing that binds `process.env.PORT`. Tests bind port 0.
   Tests must also use a **separate DB file** (`SNIP_DB` env) so `npm test` never clobbers
   `./data/snip.db`. Add `SNIP_DB` to the env contract (amends D28 — DB path defaults to
   `./data/snip.db`, overridable by `SNIP_DB`).
10. **R2 restart test** as written re-opens a handle in-process — that is not a real restart.
    → FIX: keep the in-process re-open (proves durability to disk) AND make it use a file DB,
    not `:memory:`, asserting the file exists on disk.

All 10 gaps folded into the waves above. Plan-check round 2: re-read — every SPEC decision
D1–D28 now has either an implementation site or a test (or both). Proceeding to EXECUTE.
